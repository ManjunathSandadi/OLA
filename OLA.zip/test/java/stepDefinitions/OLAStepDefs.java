package stepDefinitions;

import java.io.IOException;
import java.text.ParseException;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;

public class OLAStepDefs extends MasterStepDefs {

	@Given("^I am in the login page of the application$")
	public void i_am_in_login_page() throws IOException {
		GeneralStepDefs.launchApplicationWebDriver();
	}

	@When("^I login using the valid username and the valid password$")
	public void i_login_using_valid_username_valid_password() throws InterruptedException, IOException {
		GeneralStepDefs.login();
	}

	@Then("^Impersonate to \"([^\"]*)\" user$")
	public void impersonate_user(String impersonateUser) throws InterruptedException, IOException {
		GeneralStepDefs.setImpersonateUser(impersonateUser);
	}
	
	@Then("^Select Proposals and Move to \"([^\"]*)\" release$")
	public void select_proposals(String releaseName) throws IOException {
		GeneralStepDefs.selectProposals(releaseName);
	}
	
	@Then("^Search \"([^\"]*)\" and downlaod proposal deck$")
	public void proposaldownload(String proposal) throws IOException{
		GeneralStepDefs.downloadProposal(proposal);
		
	}
	
	@Then("^Select Create Proposal")
	public void create_poposal() throws IOException {
		GeneralStepDefs.CreateProposal();
	}
	
	@Then("^Create Proposal using following details for R2O Lead:$")
	public void _proposal(DataTable BOMdata) throws IOException, InterruptedException {
		GeneralStepDefs.SingleProposal(BOMdata);
	}

	@Then("^Select \"([^\"]*)\" release")
	public void select_release(String release) throws IOException {
		GeneralStepDefs.selectRelease(release);
	}

	@Then("^Add BOM using following details for GTM Lead:$")
	public void add_BOM(DataTable BOMdata) throws InterruptedException, IOException {
		BOMStepDefs.addBOM(BOMdata);
	}

	@Then("^Add BOM using following details for Functional Lead:$")
	public void add_BOM_FL(DataTable BOMdata) throws InterruptedException, IOException {
		BOMStepDefs.addBOM_FL(BOMdata);
	}

	@Then("^Edit BOM in \"([^\"]*)\" using following details:$")
	public void edit_BOM(String workstream, DataTable BOMdata) throws InterruptedException, IOException {
		BOMStepDefs.editBOM(workstream, BOMdata);
	}

	@Then("^Clone BOM in \"([^\"]*)\" using following details:$")
	public void clone_BOM(String workstream, DataTable BOMdata) throws InterruptedException, IOException {
		BOMStepDefs.cloneBOM(workstream, BOMdata);
	}

	@Then("^Add Document using following details:$")
	public void add_document(DataTable data) throws InterruptedException, IOException {
		BOTStepDefs.addDocument(data);
	}

	@Then("^Remove Document using following details:$")
	public void remove_document(DataTable data) throws InterruptedException, IOException {
		BOTStepDefs.removeDocument(data);
	}

	@Then("^Verify Column name and order for the below workstreams:$")
	public void columnname_and_order_verifictaion_for_given_workstream(DataTable data) throws IOException {
		BOTStepDefs.columnNameOrderVerificationSpecificWorkstream(data);
	}

	@Then("^validate Red color for BOM \"([^\"]*)\" in \"([^\"]*)\"$")
	public void rule1(String BOM, String Workstream) throws InterruptedException, IOException, ParseException {
		BOTStepDefs.RYG_rule1(BOM, Workstream);
	}

	@Then("^validate Risk which should be in \"([^\"]*)\" for BOM \"([^\"]*)\" in \"([^\"]*)\"$")
	public void risk_to_a_bom_rules(String color,String BOM, String Workstream) 
			throws InterruptedException, IOException, ParseException {
		BOTStepDefs.RYG_risk_rules(color,BOM, Workstream);
	}

	@Then("^Verify below mentioned options for BOM \"([^\"]*)\" in Workstream \"([^\"]*)\" in Product \"([^\"]*)\"$")
	public void assigned_to_me_BOM_options(String BOM, String Workstream, String Product,DataTable data) 
			throws InterruptedException, IOException {
		BOTStepDefs.verifyAssignedToMeBomOptions(BOM,Workstream,Product,data);
	}

	@Then("^Verify Assigned To Me applicable filter options$")
	public void assigned_to_me_applicable_filter_options() throws IOException, InterruptedException {
		BOTStepDefs.verifyAssignedToMeFilterOptions();
	}

	@Then("^Verify below mentioned option in All Workstreams$")
	public void all_workstream_options(DataTable Options) throws InterruptedException, IOException {
		BOTStepDefs.verifyOptionsAllWorkstream(Options);	
	}

	@Then("^Verify below mentioned option in All Products$")
	public void all_products_options(DataTable Options) throws InterruptedException, IOException {
		BOTStepDefs.verifyOptionsAllProducts(Options);
	}

	@Then("^Validate Detailed View page BOM filter,bulkedit and search options and Risk Search option$")
	public void filter_bulkedit_search_options_validations(DataTable filteroptions) 
			throws InterruptedException, IOException {
		BOTStepDefs.verifyFilterBulkeditSearchOptions(filteroptions);
	}

	@Then("^Select Product/Workstream \"([^\"]*)\"$")
	public void select_product(String name) throws IOException {
		GeneralStepDefs.selectProductWorkstream(name);
	}

	@Then("^Add Risk to Workstream \"([^\"]*)\" using following details:$")
	public void add_risk_to_a_workstream(String workstream, DataTable Riskdata) 
			throws InterruptedException, IOException  {	
		GeneralStepDefs.addRiskToWorkstream(workstream,Riskdata);
	}

	@Then("^validate RYG data for \"([^\"]*)\" after BOM update$")
	public void validate_RYG_data_for_a_workstream_after_BOM_update(String workstream) throws IOException {
		BOMStepDefs.validate_RYG_data_for_a_workstream_after_BOM_update(workstream);
	}

	@Then("^Verify All Workstreams Column name and order$")
	public void all_workstreams_columnname_and_order() throws InterruptedException, IOException {
		BOMStepDefs.verifyAllWorkstreamColumnNameOrder();
	}

	@Then("^Verify Assigned To Me Column name and order$")
	public void verify_assigned_to_me_columnname_and_order() throws InterruptedException, IOException {
		BOMStepDefs.verifyAssignedToMeColumnNameOrder();
	}

	@Then("^validate Risk which should be in \"([^\"]*)\" for Workstream \"([^\"]*)\"$")
	public void risk_to_a_workstream_rules(String color, String Workstream) 
			throws InterruptedException, IOException, ParseException {
		GeneralStepDefs.riskToOneWorkstreamRules(color, Workstream);
	}

	@Then("^Select Page \"([^\"]*)\"$")
	public void select_page(String page) throws InterruptedException, IOException {
		GeneralStepDefs.select_page(page);
	}

	@Then("^Verify actions at Workstream \"([^\"]*)\"$")
	public void workstream_actions(String Workstream) throws IOException {
		BOMStepDefs.workstreamActions(Workstream);
	}

	@Then("^Verify actions at Product \"([^\"]*)\"$")
	public void product_actions(String product) throws IOException {
		BOMStepDefs.productActions(product);
	}

	@Then("^Verify All Products Column name and order$")
	public void all_products_columnname_and_order() throws InterruptedException, IOException {
		BOMStepDefs.verifyAllProductColumnNameOrder();
	}

	@Then("^Validate the Home Landing Page$")
	public void validateHomeLandingPage() throws InterruptedException, IOException {
		DashboardStepDefs.validateHomeWidgets();
	}

	@And("^Add Risk to BOM \"([^\"]*)\" using following details:$")
	public void add_risk_to_existing_BOM(String BOM,DataTable Riskdata) 
			throws InterruptedException, IOException  {
		BOTStepDefs.addRiskToExistingBom(BOM,Riskdata);
	}

	@And("^Edit Risk in \"([^\"]*)\" using following details:$")
	public void edit_risk_to_existing_BOM(String workstream,DataTable Riskdata) 
			throws InterruptedException, IOException  {
		BOTStepDefs.editRiskToExistingBom(workstream,Riskdata);
	}

	@And("^Add Dependency to BOM \"([^\"]*)\" using following details:$")
	public void add_dependency_to_existing_BOM(String BOM,DataTable Dependencydata) 
			throws InterruptedException, IOException  {
		BOTStepDefs.addDependencyToExistingBom(BOM,Dependencydata);
	}

	@And("^Verify options for the below workstreams:$")
	public void verify_options_for_workstreams(DataTable input) throws IOException {
		BOTStepDefs.verifyWorkstreamDocumentsOptions(input);	
	}

	@And("^Verify below mentioned options in Funtional Lead for \"([^\"]*)\"$")
	public void verify_options_in_FunctionalLead_for_workstreams(String workstream, DataTable options) 
			throws IOException {
		BOTStepDefs.verifyWorkstreamDocumentsOptionsFNL(workstream,options);	
	}

	@And("^Verify below mentioned options in Workstream \"([^\"]*)\"$")
	public void verify_options_in_workstreams(String Workstream, DataTable options) throws IOException {
		BOTStepDefs.verifyOptionsWorkstream(Workstream,options);	
	}

	@And("^Verify below mentioned options in Product \"([^\"]*)\"$")
	public void verify_options_in_product(String Product, DataTable options) 
			throws InterruptedException, IOException {
		BOTStepDefs.verifyOptionsProduct(Product,options);	
	}

	@And("^Verify only one option in BOM \"([^\"]*)\"$")
	public void verify_one_option_in_BOM_for_workstreams(String BOM, DataTable options) throws IOException {
		BOMStepDefs.verifyViewBomOptionsReadOnly(BOM,options);	
	}

	@And("^Verify only one option in Risk \"([^\"]*)\" for BOM \"([^\"]*)\"$")
	public void verify_one_option_in_Risk_for_workstreams(String Risk,String BOM, DataTable options) 
			throws IOException {
		BOTStepDefs.verifyViewEditRiskOptions(Risk,BOM,options);	
	}

	@And("^Verify below mentioned options in BOM \"([^\"]*)\"$")
	public void verify_options_in_BOM_for_workstreams(String BOM, DataTable options) 
			throws InterruptedException, IOException {
		BOMStepDefs.verifyBOMOptions(BOM,options);	
	}

	@And("^Verify below mentioned options in Risk \"([^\"]*)\" for BOM \"([^\"]*)\"$")
	public void verify_options_in_Risk_for_workstreams(String Risk,String BOM, DataTable options) 
			throws InterruptedException, IOException {
		BOTStepDefs.verifyOptionsRisk(Risk,BOM,options);	
	}

	@And("^Verify Upcoming Miletsones for user \"([^\"]*)\"$")
	public void upcoming_milstones_validation(String user) throws InterruptedException, IOException {
		GeneralStepDefs.validateUpcomingMilestones(user);
	}

	@And("^Select Product \"([^\"]*)\" and Workstream \"([^\"]*)\" in Dashboard for Functional Lead$")
	public void select_tile_in_dashboard_FL(String Product,String Workstream) 
			throws InterruptedException, IOException {
		DashboardStepDefs.selectTileInDashboardFNL(Product,Workstream);
	}

	@And("^Select Product \"([^\"]*)\" and Workstream \"([^\"]*)\" in Dashboard for GTM Lead$")
	public void select_tile_in_dashboard(String Product,String Workstream) 
			throws InterruptedException, IOException {
		DashboardStepDefs.selectTileInDashboard(Product,Workstream);
	}

	@And("^Validate Summary Status for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" with status \"([^\"]*)\" for GTM Lead$")
	public void summary_status_validation_for_given_status(String Product,String Workstream,String status) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_summary_status(Product,Workstream,status);
	}

	@And("^Validate Summary Status BOM categories for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" with Dashboard BOM categories for GTM Lead$")
	public void summary_status_BOM_cat_validation(String Product,String Workstream) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_summary_status_BOM_cat(Product,Workstream);
	}

	@And("^Validate Summary Status for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" with status \"([^\"]*)\" for Functional Lead$")
	public void summary_status_validation_for_given_status_FL(String Product,String Workstream,String status) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_summary_status_FL(Product,Workstream,status);
	}

	@And("^Add New release using following details:$")
	public static void add_newrelease(DataTable releasedata) throws InterruptedException, IOException {
		GeneralStepDefs.addNewReleaseOla(releasedata);
	}

	@And("^Validate ScoreCard Status for Product \"([^\"]*)\" with status \"([^\"]*)\"$")
	public void scorecard_validation_for_given_status(String Product,String status)
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_scorecard(Product,status);
	}

	@And("^Validate ScoreCard Status for Workstream \"([^\"]*)\" with status \"([^\"]*)\"$")
	public void scorecard_validation_for_given_status_for_workstream(String Workstream,String status) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_scorecard_for_workstream(Workstream,status);
	}

	@And("^Validate ScoreCard Status for Workstream \"([^\"]*)\" with status \"([^\"]*)\" for Read Only User$")
	public void scorecard_validation_for_workstream_readonly(String Workstream,String status) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_scorecard_for_workstream_readonly(Workstream,status);
	}

	@And("^Validate ScoreCard Status for Product \"([^\"]*)\" with status \"([^\"]*)\" for Read Only User$")
	public void scorecard_validation_for_product_readonly(String Product,String status) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_scorecard_for_product_readonly(Product,status);
	}

	@And("^Validate Summary Status for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" for GTM Lead$")
	public void summary_status_validation_for_given_status(String Product,String Workstream) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_summary_status(Product,Workstream);
	}
	@And("^Validate Product Summary Status and Risk Summary Status for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" in Summary Status for GTM Lead$")
	public void product_risk_summary_status(String Product,String Workstream) 
			throws IOException, InterruptedException {
		SummaryScorecardStepDefs.validate_product_risk_summary_status(Product,Workstream);
	}

	@And("^Validate Summary Status for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" for Read Only User$")
	public void summary_status_validation_for_read_only_product(String Product,String Workstream) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_summary_status_readonly_product(Product,Workstream);
	}

	@And("^Validate Summary Status for Workstream \"([^\"]*)\" and Product \"([^\"]*)\" for Read Only User$")
	public void summary_status_validation_for_read_only_workstream(String Workstream,String Product) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_summary_status_readonly_workstream(Workstream,Product);
	}

	@And("Validate ScoreCard Status page for Product \"([^\"]*)\"$")
	public void scroecard_status_page_vaidation(String Product) throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_scorecard_status_page(Product);
	}

	@And("^Validate Heat Map page Worklists$")
	public void validate_heatmap() throws InterruptedException, IOException {
		HeatMapStepDefs.verify_heatmap_worklist();
	}

	@And("^Validate Heat Map page risk,colors and percentage icons$")
	public void validate_heatmap_risk_colors_percentage_icon() throws InterruptedException, IOException {
		HeatMapStepDefs.validate_heatmap_risk_colors_percentage_icon();
	}

	@And("^Validate expand collapse functionality for All Products$")
	public void validate_expand_collapse_functionality() throws IOException, InterruptedException {
		SummaryScorecardStepDefs.validate_expand_collapse();
	}

	@And("^Validate Heat Map page for Workstream \"([^\"]*)\" and Product \"([^\"]*)\"$")
	public void validate_heatmap_for_workstream(String workstream,String product) 
			throws IOException, InterruptedException {
		SummaryScorecardStepDefs.validate_heatmap_for_workstream_product(workstream,product);
	}

	@And("^validate RYG data in detailed view and dashboard$")
	public void RYG_data_validation() throws InterruptedException, IOException {
		BOMStepDefs.RYG_data_validation();
	}

	@And("^Select Product \"([^\"]*)\" and Workstream \"([^\"]*)\"$")
	public void select_product_workstream(String product, String workstream) 
			throws InterruptedException, IOException {	
		GeneralStepDefs.selectProductWorkstream(product, workstream);
	}

	@And("^Select Workstream \"([^\"]*)\" and Product \"([^\"]*)\"$")
	public void select_workstream_product(String workstream, String product) 
			throws InterruptedException, IOException {	
		GeneralStepDefs.selectWorkstreamProduct(workstream, product);
	}

	@And("^Validate the Not Required filter option$")
	public void validateNotRequiredFilterOption() throws InterruptedException, IOException {
		BOMStepDefs.verifyFilterStateOption();
	}

	@And("^Validate BOM Category is in Ascending Order$")
	public void validateBomCategoryAscendingOrder() throws IOException, InterruptedException {
		GeneralStepDefs.validateFilterOptionsAscendingOrder();
	}

	/**	@And("^Validate ScoreCard Status for Product \"([^\"]*)\" with status \"([^\"]*)\"$")
	public void scorecardValidation_for_given_status_for_product(String Product,String status) 
			throws InterruptedException, IOException {
		SummaryScorecardStepDefs.validate_scorecard_for_product(Product,status);
	}
	 **/
}