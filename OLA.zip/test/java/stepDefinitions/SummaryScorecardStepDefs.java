package stepDefinitions;

import java.io.IOException;
import java.util.HashMap;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import pageObjects.HeatMapPage;
import pageObjects.LoginPage;
import pageObjects.ScoreCardPage;
import pageObjects.ScorecardStatusPage;
import pageObjects.SummaryStatusPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

public class SummaryScorecardStepDefs extends MasterStepDefs {

	protected static void valSummaryStatusFNL(String Product,String workstream,String Status) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationSummaryStatusView);

		double percent;
		String tilecolor_class_attribute_value="";

		ReusableMethods.isElementExists(SummaryStatusPage.edit, true, "Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		ReusableMethods.isElementExists(SummaryStatusPage.save, true, "Save Button");
		ReusableMethods.isElementExists(SummaryStatusPage.submit, true, "Submit Button");
		ReusableMethods.isElementExists(SummaryStatusPage.cancel, true, "Cancel");
		ReusableMethods.isElementExists(SummaryStatusPage.status, false, "Status Dropdown");
		ReusableMethods.click(SummaryStatusPage.status);

		if(Status.equals("none")) {
			ReusableMethods.click(SummaryStatusPage.none);
			tilecolor_class_attribute_value="panel-heading ng-binding panGrey";
		} else if(Status.equals("On Track")) {
			ReusableMethods.click(SummaryStatusPage.on_track);
			tilecolor_class_attribute_value="panel-heading ng-binding panGreen";
		} else if(Status.equals("Risk")) {
			ReusableMethods.click(SummaryStatusPage.risk);
			tilecolor_class_attribute_value="panel-heading ng-binding panYellow";
		} else if(Status.equals("Critical")) {
			ReusableMethods.click(SummaryStatusPage.critical);
			tilecolor_class_attribute_value="panel-heading ng-binding panRed";
		}

		ReusableMethods.click(SummaryStatusPage.submit);
		SummaryStatusPage.setWorkstream(Product);
		String product_completed_data = ReusableMethods.getText(SummaryStatusPage.worktream_completed_data);
		String[] bom_data=product_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		percent = (completed_bom*100)/total_bom;
		percent = Math.round(percent*100.0)/100.0;
		String completion_percentage = ReusableMethods.getText(SummaryStatusPage.completion_percentage);

		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			test.log(LogStatus.INFO, "Percentage validation is successful in Summary status!!!!!!!!!!!");
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, 
					test.addScreenCapture(capture(driver)));
		} else { 
			test.log(LogStatus.INFO, "Incorrect Percentage value in Summary status!!!!!!!!!!!");
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, 
					test.addScreenCapture(capture(driver)));
		}

		GeneralStepDefs.select_page("Dashboard");

		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationDashboardView);

		DashboardPage.setProduct_tile_color(Product, tilecolor_class_attribute_value);
		ReusableMethods.isElementExists(DashboardPage.product_tile_color, true, "Tile after status updated");
	}

	protected static void validate_summary_status(String Product,String workstream,String Status) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationSummaryStatusView);

		double percent;

		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.isElementExists(SummaryStatusPage.edit, true, "Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		ReusableMethods.isElementExists(SummaryStatusPage.save, true, "Save Button");
		ReusableMethods.isElementExists(SummaryStatusPage.submit, true, "Submit Button");
		ReusableMethods.isElementExists(SummaryStatusPage.cancel, true, "Cancel");
		ReusableMethods.isElementExists(SummaryStatusPage.status, false, "Status Dropdown");		
		ReusableMethods.click(SummaryStatusPage.submit);

		String workstream_completed_data = ReusableMethods.getText(SummaryStatusPage.worktream_completed_data);
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage = ReusableMethods.getText(SummaryStatusPage.completion_percentage);

		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			test.log(LogStatus.INFO, "Percentage validation is successful in Summary status!!!!!!!!!!!");
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, 
					test.addScreenCapture(capture(driver)));
		} else { 
			test.log(LogStatus.INFO, "Incorrect Percentage value in Summary status!!!!!!!!!!!");
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void validate_scorecard_for_product(String product, String Status) 
			throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		GeneralStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationScorecardView);

		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		ReusableMethods.isElementExists(ScoreCardPage.progress, true, "Scorecard Progress");
		ReusableMethods.isElementExists(ScoreCardPage.scorecardapprover, true, "Scorecard  Approver");
		ReusableMethods.isElementExists(ScoreCardPage.calendar, true, "Calendar");
		ReusableMethods.isElementExists(ScoreCardPage.download, true, "Download");
		ReusableMethods.isElementExists(ScoreCardPage.status_update, true, "Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		ReusableMethods.rawWait(1);
		driver.findElement(ScoreCardPage.date).sendKeys("12-12-2021");
		ReusableMethods.isElementExists(ScoreCardPage.clear, true, "Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.rawWait(1);
		ReusableMethods.isElementExists(ScoreCardPage.highlight_changes_since, true, "Highlight Changes Since");
		ReusableMethods.click(ScoreCardPage.status_update);
		ReusableMethods.click(ScoreCardPage.tracking_status);

		if(Status.equals("none")) {
			ReusableMethods.click(ScoreCardPage.none);
		} else if(Status.equals("On Track")) {
			ReusableMethods.click(ScoreCardPage.on_track);
		} else if(Status.equals("Risk")) {
			ReusableMethods.click(ScoreCardPage.risk);
		} else if(Status.equals("Critical")) {
			ReusableMethods.click(ScoreCardPage.critical);
		}
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Open");
		ReusableMethods.isElementEnabled(ScoreCardPage.submit, false, "Submit");

		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.pm_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.gm_approval, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.submit_to_NPI, "Completed");
		ReusableMethods.isElementExists(ScoreCardPage.submit, true, "Submit");
		ReusableMethods.isElementExists(ScoreCardPage.save, true, "Save");
		ReusableMethods.click(ScoreCardPage.submit);

		ReusableMethods.isElementExists(ScoreCardPage.approver_section, true, "Approver Section");
		String Approver_name = ReusableMethods.getText(ScoreCardPage.approver_name);
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));
		String product_name = ReusableMethods.getText(ScoreCardPage.product_name);

		if(product_name.contains(product)) {
			test.log(LogStatus.PASS, "Product name is getting displayed in Approver section!!"+product_name, test.addScreenCapture(capture(driver)));
		} else {
			test.log(LogStatus.FAIL, "Product name is NOT getting displayed in Approver section!!"+product_name, test.addScreenCapture(capture(driver)));
		}
		ReusableMethods.isElementExists(ScoreCardPage.progress_section, true, "Progress Section");
	}

	protected static void validate_scorecard_for_workstream(String workstream, String Status) 
			throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		GeneralStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationScorecardView);

		ReusableMethods.isElementExists(ScoreCardPage.progress, true, "Scorecard Progress");
		ReusableMethods.isElementExists(ScoreCardPage.scorecardapprover, true, "Scorecard  Approver");
		ReusableMethods.isElementExists(ScoreCardPage.calendar, true, "Calendar");
		ReusableMethods.isElementExists(ScoreCardPage.download, true, "Download");
		ReusableMethods.isElementExists(ScoreCardPage.status_update, true, "Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		ReusableMethods.rawWait(1);
		driver.findElement(ScoreCardPage.date).sendKeys("12-12-2021");
		ReusableMethods.isElementExists(ScoreCardPage.clear, true, "Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.rawWait(1);
		ReusableMethods.isElementExists(ScoreCardPage.highlight_changes_since, true, "Highlight Changes Since");
		ReusableMethods.click(ScoreCardPage.status_update);
		ReusableMethods.click(ScoreCardPage.tracking_status);

		if(Status.equals("none")) {
			ReusableMethods.click(ScoreCardPage.none);
		} else if(Status.equals("On Track")) {
			ReusableMethods.click(ScoreCardPage.on_track);
		} else if(Status.equals("Risk")) {
			ReusableMethods.click(ScoreCardPage.risk);
		} else if(Status.equals("Critical")) {
			ReusableMethods.click(ScoreCardPage.critical);
		}
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Open");
		ReusableMethods.isElementEnabled(ScoreCardPage.submit, false, "Submit");

		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.pm_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.gm_approval, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.submit_to_NPI, "Completed");
		ReusableMethods.isElementExists(ScoreCardPage.submit, true, "Submit");
		ReusableMethods.isElementExists(ScoreCardPage.save, true, "Save");
		ReusableMethods.click(ScoreCardPage.submit);

		ReusableMethods.isElementExists(ScoreCardPage.approver_section, true, "Approver Section");
		String Approver_name = ReusableMethods.getText(ScoreCardPage.approver_name);
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));

		ReusableMethods.isElementExists(ScoreCardPage.progress_section, true, "Progress Section");
	}

	protected static void validate_summary_status_BOM_cat(String product, String workstream) 
			throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		HashMap<String,String> summary_bom = new HashMap<String,String>();
		HashMap<String,String> dashboard_bom = new HashMap<String,String>();
		int cat_size = 0;

		GeneralStepDefs.select_page("Summary Status");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationSummaryStatusView);

		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		cat_size = ReusableMethods.getElementsSize(SummaryStatusPage.summary_bom_cat_values);

		for (int i=1;i<=cat_size;i++) {
			String val = ReusableMethods.getText(SummaryStatusPage.summary_bom_cat_values+"["+i+"]");
			summary_bom.put("BOM -"+i, val);
		}
		GeneralStepDefs.select_page("Dashboard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		if(cat_size>4) {
			for (int i=1;i<=(cat_size/4)+1;i++) {
				try {
					if(ReusableMethods.isDisplayed(DashboardPage.dashboard_arrow)){
						DashboardPage.setProduct_tile(workstream);
						int size = ReusableMethods.getElementsSize(DashboardPage.dashboard_bom_cat_values);
						for(int j=1;j<=size;j++) {
							String val1 = ReusableMethods.getText(DashboardPage.dashboard_bom_cat_values+"["+j+"]");
							dashboard_bom.put("BOM -"+j, val1);	
						}
					}
					ReusableMethods.click(DashboardPage.dashboard_arrow);	
				} catch(Exception e) {
					test.log(LogStatus.FAIL, "For more than 4 BOM categories Left/right arrow is not available in dashboard Product/Workstream tile!!", 
							test.addScreenCapture(capture(driver)));
				}
			}
		} else {
			test.log(LogStatus.INFO, "Less than or equal to 4 BOM categories!!");

			DashboardPage.setProduct_tile(product);
			int size = ReusableMethods.getElementsSize(DashboardPage.dashboard_bom_cat_values);
			for(int j=1;j<=size;j++) {
				String val1 = ReusableMethods.getText(DashboardPage.dashboard_bom_cat_values+"["+j+"]");
				dashboard_bom.put("BOM -"+j, val1);
			}
		}
		boolean result=summary_bom.equals(dashboard_bom);
		ReusableMethods.softAssertverification(result, true);
	}

	protected static void validate_summary_status(String Product,String workstream) 
			throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationSummaryStatusView);

		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, Product);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.isElementExists(SummaryStatusPage.edit, true, "Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		Thread.sleep(2000);
		ReusableMethods.enterData(SummaryStatusPage.scorecard_summary_ready_test, "Automation Testing");
		Thread.sleep(2000);
		ReusableMethods.isElementExists(SummaryStatusPage.save, true, "Save Button");
		ReusableMethods.isElementExists(SummaryStatusPage.submit, true, "Submit Button");
		ReusableMethods.isElementExists(SummaryStatusPage.cancel, true, "Cancel");
		ReusableMethods.isElementExists(SummaryStatusPage.status, false, "Status Dropdown");	
		ReusableMethods.click(SummaryStatusPage.submit);
		Thread.sleep(2000);

		String workstream_completed_data = ReusableMethods.getText(SummaryStatusPage.worktream_completed_data);
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage = ReusableMethods.getText(SummaryStatusPage.completion_percentage);

		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		} else { 
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		}
	}

	protected static void validate_summary_status_FL(String Product,String workstream,String Status) 
			throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.isElementExists(SummaryStatusPage.edit,true,"Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		ReusableMethods.isElementExists(SummaryStatusPage.save,true,"Save Button");
		ReusableMethods.isElementExists(SummaryStatusPage.submit,true,"Submit Button");
		ReusableMethods.isElementExists(SummaryStatusPage.cancel,true,"Cancel");
		ReusableMethods.isElementExists(SummaryStatusPage.status,false,"Status Dropdown");
		ReusableMethods.click(SummaryStatusPage.status);
		String tilecolor_class_attribute_value="";
		if(Status.equals("none")) {
			ReusableMethods.click(SummaryStatusPage.none);
			tilecolor_class_attribute_value="panel-heading ng-binding panGrey";
		} else if(Status.equals("On Track")) {
			ReusableMethods.click(SummaryStatusPage.on_track);
			tilecolor_class_attribute_value="panel-heading ng-binding panGreen";
		} else if(Status.equals("Risk")) {
			ReusableMethods.click(SummaryStatusPage.risk);
			tilecolor_class_attribute_value="panel-heading ng-binding panYellow";
		} else if(Status.equals("Critical")) {
			ReusableMethods.click(SummaryStatusPage.critical);
			tilecolor_class_attribute_value="panel-heading ng-binding panRed";
		}
		ReusableMethods.click(SummaryStatusPage.submit);
		SummaryStatusPage.setWorkstream(Product);
		String product_completed_data=ReusableMethods.getText(SummaryStatusPage.worktream_completed_data);
		String[] bom_data=product_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage=ReusableMethods.getText(SummaryStatusPage.completion_percentage);
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			test.log(LogStatus.PASS, "Percentage validation is successful in Summary status!!!!!!!!!!!");
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, 
					test.addScreenCapture(capture(driver)));
		} else { 
			test.log(LogStatus.FAIL, "Incorrect Percentage value in Summary status!!!!!!!!!!!");
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, 
					test.addScreenCapture(capture(driver)));
		}

		GeneralStepDefs.select_page("Dashboard");
		DashboardPage.setProduct_tile_color(Product,tilecolor_class_attribute_value);
		ReusableMethods.isElementExists(DashboardPage.product_tile_color, true, "Tile after status updated");
	}

	protected static void validate_product_risk_summary_status(String product, String workstream) throws IOException, InterruptedException {

		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationSummaryStatusView);

		ReusableMethods.isElementExists(SummaryStatusPage.summary_bom_cat_values, true, "BOM category");
		ReusableMethods.isElementExists(SummaryStatusPage.summary_bom_cat_progressbar, true, "BOM category Progress Bar");
		ReusableMethods.isElementExists(SummaryStatusPage.summary_bom_cat_percentage, true, "BOM category completion percentage");
		ReusableMethods.isElementExists(SummaryStatusPage.summary_bom_cat_comments, true, "BOM category status comments");
		ReusableMethods.isElementExists(SummaryStatusPage.scorecard_expand_collapse_button, true, "Scorecard Summary expand collapse button");
		ReusableMethods.isElementExists(SummaryStatusPage.productsummary_expand_collapse_button, true, "Product Summary expand collapse button");
		ReusableMethods.isElementExists(SummaryStatusPage.risksummary_expand_collapse_button, true, "Risk Summary expand collapse button");
		ReusableMethods.isElementExists(SummaryStatusPage.workStream_attachment, true, "Workstream attachment");
		String bom_cat_color=ReusableMethods.getAttribute(SummaryStatusPage.summary_bom_cat_color, "ng-if");
		test.log(LogStatus.PASS, "BOM category Status color = "+bom_cat_color);

		boolean flag=true;
		int size = ReusableMethods.getElementsSize(SummaryStatusPage.scorecardSummaryRiskState);
		for(int i=1;i<=size;i++) {
			String status = ReusableMethods.getText(SummaryStatusPage.scorecardSummaryRiskState + "["+i+"]");
			if(!status.equals("Open Unmitigated") && !status.equals("Open with Mitigation Plan")) {
				flag=false;
			}
		}
		ReusableMethods.softAssertverification(flag, true);	
	}

	protected static void validate_summary_status_readonly_product(String Product,String workstream) throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationSummaryStatusView);

		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, Product);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.isElementExists(SummaryStatusPage.edit, false, "Edit Button");

		String workstream_completed_data = ReusableMethods.getText(SummaryStatusPage.worktream_completed_data);
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage = ReusableMethods.getText(SummaryStatusPage.completion_percentage);

		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			test.log(LogStatus.PASS, "Percentage validation is successful in Summary status!!!!!!!!!!!"); 
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		} else { 
			test.log(LogStatus.FAIL, "Incorrect Percentage value in Summary status!!!!!!!!!!!");
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		}
	}

	protected static void validate_summary_status_readonly_workstream(String workstream,String Product) throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		double percent;

		SummaryStatusPage.setWorkstream(Product);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationSummaryStatusView);

		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, workstream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.isElementExists(SummaryStatusPage.edit, false, "Edit Button");

		String workstream_completed_data = ReusableMethods.getText(SummaryStatusPage.worktream_completed_data);
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage = ReusableMethods.getText(SummaryStatusPage.completion_percentage);
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			test.log(LogStatus.PASS, "Percentage validation is successful in Summary status!!!!!!!!!!!");
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		} else { 
			test.log(LogStatus.PASS, "Incorrect Percentage value in Summary status!!!!!!!!!!!");
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		}
	}

	protected static void validate_scorecard_for_workstream_readonly(String workstream, String Status) 
			throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		GeneralStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationScorecardView);

		ReusableMethods.isElementExists(DetailedViewPage.workstream_dropdown, false, "Product drop down");
		ReusableMethods.isElementExists(ScoreCardPage.progress, true, "Scorecard Progress");
		ReusableMethods.isElementExists(ScoreCardPage.scorecardapprover, true, "Scorecard  Approver");
		ReusableMethods.isElementExists(ScoreCardPage.calendar, true, "Calendar");
		ReusableMethods.isElementExists(ScoreCardPage.download, true, "Download");
		ReusableMethods.isElementExists(ScoreCardPage.status_update, false, "Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		ReusableMethods.rawWait(1);
		driver.findElement(ScoreCardPage.date).sendKeys("12-12-2021");
		ReusableMethods.isElementExists(ScoreCardPage.clear, true, "Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.rawWait(1);
		ReusableMethods.isElementExists(ScoreCardPage.highlight_changes_since, true, "Highlight Changes Since");

		ReusableMethods.isElementExists(ScoreCardPage.approver_section, true, "Approver Section");
		String Approver_name = ReusableMethods.getText(ScoreCardPage.approver_name);
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));

		ReusableMethods.isElementExists(ScoreCardPage.progress_section, true, "Progress Section");
	}

	protected static void validate_scorecard_for_product_readonly(String product, String Status) 
			throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		GeneralStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationScorecardView);

		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		ReusableMethods.isElementExists(ScoreCardPage.progress, true, "Scorecard Progress");
		ReusableMethods.isElementExists(ScoreCardPage.scorecardapprover, true, "Scorecard  Approver");
		ReusableMethods.isElementExists(ScoreCardPage.calendar, true, "Calendar");
		ReusableMethods.isElementExists(ScoreCardPage.download, true, "Download");
		ReusableMethods.isElementExists(ScoreCardPage.status_update, false, "Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		ReusableMethods.rawWait(1);
		driver.findElement(ScoreCardPage.date).sendKeys("12-12-2021");
		ReusableMethods.isElementExists(ScoreCardPage.clear, true, "Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.rawWait(1);
		ReusableMethods.isElementExists(ScoreCardPage.highlight_changes_since, true, "Highlight Changes Since");

		ReusableMethods.isElementExists(ScoreCardPage.approver_section, true, "Approver Section");
		String Approver_name = ReusableMethods.getText(ScoreCardPage.approver_name);
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));
		String product_name = ReusableMethods.getText(ScoreCardPage.product_name);

		if(product_name.contains(product)) {
			test.log(LogStatus.PASS, "Product name is getting displayed in Approver section!!"+product_name, test.addScreenCapture(capture(driver)));
		} else {
			test.log(LogStatus.FAIL, "Product name is NOT getting displayed in Approver section!!"+product_name, test.addScreenCapture(capture(driver)));
		}
		ReusableMethods.isElementExists(ScoreCardPage.progress_section, true, "Progress Section");
	}

	protected static void validate_scorecard_status_page(String product) throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();

		ScorecardStatusPage.set_product(product);
		ReusableMethods.click(ScorecardStatusPage.scorecard_icon);
		ReusableMethods.rawWait(1);

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationScorecardView);

		ReusableMethods.isElementExists(ScorecardStatusPage.product_dropdowns, true, "Scorecard Status Product Drop Downs");
		ReusableMethods.isElementExists(ScorecardStatusPage.scorecard_workstream_list, true, "Scorecard Status Workstream List");
		ReusableMethods.isElementExists(ScorecardStatusPage.calendar, true, "Calendar");
		ReusableMethods.isElementExists(ScorecardStatusPage.download, true, "Download");
		ReusableMethods.click(ScorecardStatusPage.calendar);
		ReusableMethods.rawWait(1);
		driver.findElement(ScorecardStatusPage.date).sendKeys("12-12-2021");
		ReusableMethods.isElementExists(ScorecardStatusPage.clear, true, "Clear");
		ReusableMethods.click(ScorecardStatusPage.apply);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.rawWait(1);
		ReusableMethods.isElementExists(ScorecardStatusPage.highlight_changes_since, true, "Highlight Changes Since");

		ReusableMethods.click(ScorecardStatusPage.download);
		Thread.sleep(1000);

		ReusableMethods.isElementExists(ScorecardStatusPage.approver_name_scorecard, true, "Approver Section");
		String Approver_name=driver.findElement(ScorecardStatusPage.approver_name_scorecard).getText().trim();
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));

		ReusableMethods.isElementExists(ScorecardStatusPage.status_scorecard, true, "Status");

		String status = ReusableMethods.getText(ScorecardStatusPage.status_scorecard);
		test.log(LogStatus.INFO, "Status: "+status, test.addScreenCapture(capture(driver)));

		String product_name = ReusableMethods.getText(ScorecardStatusPage.product_name_scorecard);
		if(product_name.contains(product)) {
			test.log(LogStatus.PASS, "Product name is getting displayed in Approver section of Scorecard Status Page!!"+product_name, test.addScreenCapture(capture(driver)));
		} else {
			test.log(LogStatus.FAIL, "Product name is NOT getting displayed in Approver section of Scorecard Status Page!!"+product_name, test.addScreenCapture(capture(driver)));
		}
	}

	public static void validate_scorecard(String product, String Status) throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();
		GeneralStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		ReusableMethods.isElementExists(ScoreCardPage.progress,true,"Scorecard Progress");
		ReusableMethods.isElementExists(ScoreCardPage.scorecardapprover,true,"Scorecard  Approver");
		ReusableMethods.isElementExists(ScoreCardPage.calendar,true,"Calendar");
		ReusableMethods.isElementExists(ScoreCardPage.download,true,"Download");
		ReusableMethods.isElementExists(ScoreCardPage.status_update,true,"Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		ReusableMethods.rawWait(1);
		driver.findElement(ScoreCardPage.date).sendKeys("12-12-2021");
		ReusableMethods.isElementExists(ScoreCardPage.clear, true, "Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.rawWait(1);
		ReusableMethods.isElementExists(ScoreCardPage.highlight_changes_since, true, "Highlight Changes Since");
		ReusableMethods.click(ScoreCardPage.status_update);
		ReusableMethods.click(ScoreCardPage.tracking_status);

		if(Status.equals("none")) {
			ReusableMethods.click(ScoreCardPage.none);
		} else if(Status.equals("On Track")) {
			ReusableMethods.click(ScoreCardPage.on_track);
		} else if(Status.equals("Risk")) {
			ReusableMethods.click(ScoreCardPage.risk);
		} else if(Status.equals("Critical")) {
			ReusableMethods.click(ScoreCardPage.critical);
		}
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Open");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.pm_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.gm_approval, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.submit_to_NPI, "Completed");
		ReusableMethods.isElementExists(ScoreCardPage.submit, true, "Submit");
		ReusableMethods.isElementExists(ScoreCardPage.save, true, "Save");
		ReusableMethods.click(ScoreCardPage.submit);
	}

	protected static void validate_expand_collapse() throws IOException, InterruptedException {

		int n = ReusableMethods.getElementsSize(HeatMapPage.product_dropdowns);

		for(int i=1;i<n;i++) {
			ReusableMethods.click(HeatMapPage.product_dropdowns+"["+i+"]");
			Thread.sleep(1000);
		}
		GeneralStepDefs.select_page("Scorecard Status");

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationScorecardStatusView);

		GeneralStepDefs.select_page("Heat Map");

		ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
		ReusableMethods.isDisplayed(LoginPage.topNavigationHeatMapView);
	}

	protected static void validate_heatmap_for_workstream_product(String workstream, String product) 
			throws InterruptedException, IOException {

		int n= ReusableMethods.getElementsSize(HeatMapPage.workstream_list);
		for(int i=1;i<n;i++) {
			String ws_name = ReusableMethods.getText(HeatMapPage.workstream_list+"["+i+"]");	
			if(ws_name.equals(workstream)) {
				ReusableMethods.click(HeatMapPage.workstream_list+"["+i+"]");
				Thread.sleep(1000);break;
			} else {
				//test.log(LogStatus.FAIL, workstream+" Workstream not available ", test.addScreenCapture(capture(driver)));
			}
		}
		HeatMapPage.set_product(product);
		ReusableMethods.isElementExists(HeatMapPage.product_tile, true, "Product tile in Heat Map Dashboard");
		ReusableMethods.click(HeatMapPage.product_tile);
		Thread.sleep(1000);
		ReusableMethods.isElementExists(HeatMapPage.scorecard_summary, true, "Scorecard Summary in Heat Map");

		/**
		 * Click back button 2 time to reach heat map page
		 */

		ReusableMethods.click(HeatMapPage.back);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.click(HeatMapPage.back);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		//Click any of the Product WS intersection(box)
		ReusableMethods.click(HeatMapPage.product_items+"[1]");
		Thread.sleep(1000);
		ReusableMethods.isElementExists(HeatMapPage.scorecard_summary, true, "Scorecard Summary in Heat Map");
	}
}