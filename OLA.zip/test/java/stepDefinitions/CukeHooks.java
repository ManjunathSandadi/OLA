package stepDefinitions;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import supportLibraries.DriverFactory;
import supportLibraries.DriverManager;
import supportLibraries.ExecutionMode;
import supportLibraries.Settings;

public class CukeHooks extends MasterStepDefs {

	private static Logger log;
	private static Properties properties = Settings.getInstance();

	static {
		log = Logger.getLogger(CukeHooks.class);
	}

	@Before
	public void setUp(Scenario scenario) {
		try {
			currentScenario = scenario;
			propertiesFileAccess = properties;
			Thread.sleep(2000);
			currentTestParameters = DriverManager.getTestParameters();
			currentTestParameters.setScenarioName(scenario.getName());
			currentTestParameters.setExecutionMode(ExecutionMode.LOCAL);
			log.info("Running the Scenario : " + scenario.getName());
			invokeForDesktopExecution(scenario);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error at Before Scenario " + e.getMessage());
		}
	}

	private void invokeForDesktopExecution(Scenario scenario) {
		switch (currentTestParameters.getExecutionMode()) {

		case LOCAL:
			log.info("Running the Scenario : " + scenario.getName() + 
					" in " + currentTestParameters.getExecutionMode());
			WebDriver driver = DriverFactory.createInstanceWebDriver(currentTestParameters);
			DriverManager.setWebDriver(driver);
			break;

		default:
			try {
				throw new Exception("Unhandled Execution Mode!");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	@After
	public void tearDown() {
		WebDriver driver = DriverManager.getWebDriver();
		if (driver != null) {
			driver.quit();
		}
	}
}