package stepDefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import pageObjects.HeatMapPage;
import supportLibraries.ReusableMethods;

public class HeatMapStepDefs  extends MasterStepDefs {

	public static void verify_heatmap_worklist() throws InterruptedException, IOException {

		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();
		
		expected.add("Product Ready");
		expected.add("Product Content Ready");
		expected.add("Ready to Operate");
		expected.add("Ready to Market");
		expected.add("Ready to Sell");
		expected.add("Ready to Solve");
		expected.add("Ready to Deliver");
		expected.add("Ready to Partner");
		expected.add("Ready to Train & Learn");
		expected.add("Ready to Support");
		expected.add("Ready to Adopt");
		//expected.add("Release Management & Operation Dates");
		
		int size = ReusableMethods.getElementsSize(HeatMapPage.workstream_list);
		
		for(int i=1;i<=size;i++) {
			String value = ReusableMethods.getText(HeatMapPage.workstream_list+"["+i+"]");
			actual.add(value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void validate_heatmap_risk_colors_percentage_icon() throws InterruptedException, IOException {

		ReusableMethods.click(HeatMapPage.completion_percentage);
		ReusableMethods.isElementExists((HeatMapPage.view_percentage),true,"View Percentage for product items");
		ReusableMethods.isElementExists(HeatMapPage.toggle_risk,true,"At Risk toggle button");
		ReusableMethods.click(HeatMapPage.toggle_risk);

		boolean flag=true;
		int size = ReusableMethods.getElementsSize(HeatMapPage.product_items);
		for(int i=1;i<=size;i++) {
			String item_color=ReusableMethods.getAttribute(HeatMapPage.product_items, "class");
			if(!item_color.contains("red") && !item_color.contains("yellow") && !item_color.contains("grey")) {
				flag=false;
			}
		}

		ReusableMethods.softAssertverification(flag, true);	

		ReusableMethods.click(HeatMapPage.toggle_risk);
	}
}