package stepDefinitions;

import java.util.Properties;

import io.cucumber.java.Scenario;
import supportLibraries.ExtentReportClass;
import supportLibraries.SeleniumTestParameters;

public abstract class MasterStepDefs extends ExtentReportClass {
	protected static Scenario currentScenario;
	protected static SeleniumTestParameters currentTestParameters;
	protected static Properties propertiesFileAccess;
}