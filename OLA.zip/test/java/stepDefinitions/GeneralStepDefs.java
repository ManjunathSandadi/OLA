package stepDefinitions;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import io.cucumber.datatable.DataTable;
import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import pageObjects.LoginPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

import supportLibraries.Settings;

public class GeneralStepDefs extends MasterStepDefs {

	private static Properties properties = Settings.getInstance();

	private static String workstreamOverallStatus;

	static HashMap<String, String> beforeAddingRisk;
	static HashMap<String,String> afterAddingRisk;

	protected static String getWorkstreamOverallStatus(String workstream) {	
		try {
			DetailedViewPage.setWorkstreamProduct(workstream);
			workstreamOverallStatus = ReusableMethods.getText(DetailedViewPage.workStreamOverallStatus);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return workstreamOverallStatus;
	}

	protected static void launchApplicationWebDriver() throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			properties = Settings.getInstance();
			String URL = properties.getProperty("ApplicationUrl");
			driver.get(URL);
			//currentScenario.embed(Util.takeScreenshot(driver),"image/png");
			assertTrue(driver.getTitle().contains("Service Portal - Offer Lifecycle Operations"));
			test = report.startTest(currentScenario.getName());
			test.log(LogStatus.PASS, "Navigated to the specified URL", 
					test.addScreenCapture(capture(driver)));

		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Unable to navigate to the specified URL " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to login into the application using valid credentials
	 * 
	 * @throws InterruptedException
	 * 
	 * @throws IOException
	 */
	protected static void login() throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			//byte[] encodedBytes = Base64.getEncoder().encode(properties.getProperty("EncodedPassword").getBytes());
			byte[] decodedBytes = Base64.getDecoder().decode(properties.getProperty("EncodedPassword").getBytes());
			//System.out.println("Encoded password ="+encodedBytes);
			//driver.switchTo().defaultContent();
			//driver.switchTo().frame("gsft_main");
			ReusableMethods.enterData(LoginPage.userName, properties.getProperty("Username"));
			ReusableMethods.enterData(LoginPage.password, new String(decodedBytes));
			ReusableMethods.click(LoginPage.login);
			test.log(LogStatus.PASS, "User able to login into the application Successfully", 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to login into the application Successfully " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	private static SearchContext shadowDom1() {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			SearchContext shadow0 = driver.findElement(By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010")).getShadowRoot();
			Thread.sleep(1000);
			SearchContext shadow1 = shadow0.findElement(By.cssSelector("sn-polaris-layout[dir='ltr']")).getShadowRoot();
			Thread.sleep(1000);
			SearchContext shadow2 = shadow1.findElement(By.cssSelector("sn-polaris-header[dir='ltr']")).getShadowRoot();
			Thread.sleep(1000);
			return shadow2;
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return shadowDom1();
	}

	public static SearchContext shadowDom2() {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			SearchContext shadow0 = driver.findElement(By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010")).getShadowRoot();
			Thread.sleep(1000);
			SearchContext shadow1 = shadow0.findElement(By.cssSelector("sn-polaris-layout[dir='ltr']")).getShadowRoot();
			Thread.sleep(1000);
			String nowID = shadow1.findElement(By.cssSelector("div[class='content-area can-animate'] > sn-impersonation")).getAttribute("now-id");
			Thread.sleep(1000);
			SearchContext shadow2 = shadow1.findElement(By.cssSelector("sn-impersonation[now-id='"+nowID+"']")).getShadowRoot();
			Thread.sleep(1000);
			return shadow2;
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return shadowDom2();
	}

	protected static void setImpersonateUser(String impersonateUser) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		try {
			ReusableMethods.waitUntilElementVisible(LoginPage.snGreetings);
			driver.get(properties.getProperty("ApplicationUrl"));

			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

			SearchContext userMenu = shadowDom1().findElement(By.cssSelector("now-avatar[dir='ltr']")).getShadowRoot();
			ReusableMethods.rawWait(1);
			userMenu.findElement(By.cssSelector(".now-avatar.-sm")).click();
			ReusableMethods.rawWait(3);

			shadowDom1().findElement(By.cssSelector("now-icon[class='user-menu-icon polaris-enabled'][icon='eye-outline']")).click();
			ReusableMethods.rawWait(3);

			SearchContext shadow3 = shadowDom2().findElement(By.cssSelector("now-typeahead[dir='ltr']")).getShadowRoot();
			ReusableMethods.rawWait(1);
			shadow3.findElement(By.cssSelector("input[placeholder='Search for a user']")).sendKeys(impersonateUser);
			ReusableMethods.rawWait(3);

			SearchContext shadow0 = driver.findElement(By.xpath("//seismic-hoist")).getShadowRoot();
			ReusableMethods.rawWait(1);
			shadow0.findElement(By.cssSelector("mark[class='has-highlight']")).click();
			ReusableMethods.rawWait(3);

			SearchContext nowModel = shadowDom2().findElement(By.cssSelector("now-modal[dir='ltr']")).getShadowRoot();
			ReusableMethods.rawWait(1);
			SearchContext nowButton = nowModel.findElement(By.cssSelector(".now-modal-footer-button:nth-child(2)")).getShadowRoot();
			ReusableMethods.rawWait(1);
			nowButton.findElement(By.cssSelector(".now-line-height-crop")).click();
			ReusableMethods.rawWait(10);

			driver.get(properties.getProperty("RedirectedApplicationUrl"));
			test.log(LogStatus.PASS, "User able to Impersonate as the User provided", 
					test.addScreenCapture(capture(driver)));

		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to Impersonate as the User provided " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void selectProposals(String releaseName) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			//String winHandleBefore = driver.getWindowHandle();
			ReusableMethods.click(DetailedViewPage.selectproposals);			
			for(String winHandle : driver.getWindowHandles()){
				driver.switchTo().window(winHandle);
			}
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			DetailedViewPage.setProposalRelease(releaseName);
			ReusableMethods.click(DetailedViewPage.proposalReleaseName);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to select the release provided "  + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));

		}
	}

	protected static void downloadProposal(String proposaldeck) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			DetailedViewPage.downloadDeckProposal(proposaldeck);
			ReusableMethods.rawWait(4);
			ReusableMethods.click(DetailedViewPage.proposaldeck);
		} catch(Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to select the release provided "  + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void CreateProposal() throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			ReusableMethods.click(DetailedViewPage.createproposals);
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to select the release provided "  + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void SingleProposal(DataTable BOMdata) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> bomData = BOMdata.asMaps(String.class, String.class);
		try {
			int size = bomData.size();
			for (int anchor = 0; anchor < size; anchor++) {
				Map<String,String> bomData1 = bomData.get(anchor);

				ReusableMethods.enterDataWthoutTabProp(DetailedViewPage.businessunit, bomData1.get("Whatisthebusinessunit"));		
				ReusableMethods.enterData(DetailedViewPage.proposalname, bomData1.get("ProposalName"));
				ReusableMethods.enterData(DetailedViewPage.proposaldescription, bomData1.get("ProposalDescription"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.whatistheproposaltype, bomData1.get("WhatistheProposalType"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.additionaldetails, bomData1.get("AdditionalDetails"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.namingapprovedbynamingcommittee, bomData1.get("NamingapprovedbyNamingCommittee"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.whatistheGTMapproach, bomData1.get("WhatistheGTMApproach"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.doyouexpectnewSKUstobecreated, bomData1.get("DoyouexpectnewSKUstobecreated"));
				ReusableMethods.enterDataWthoutTabProp(DetailedViewPage.whoistheBUproductmanager, bomData1.get("WhoistheBUProductManager"));
				ReusableMethods.click(DetailedViewPage.submitproposalbutton);
				//ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

				test.log(LogStatus.PASS, "Successfully Added the BOM details", 
						test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "NOT Added the BOM details " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}



	protected static void selectRelease(String release) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			DetailedViewPage.setRelease(release);
			ReusableMethods.click(DetailedViewPage.projectRelease);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			test.log(LogStatus.PASS, "User able to select the release provided", 
					test.addScreenCapture(capture(driver)));
			ReusableMethods.click(LoginPage.notificationBellIcon);
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to select the release provided "  + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void validateUpcomingMilestones(String user) throws InterruptedException, IOException {
		int index = 1;
		boolean flag = true;
		try {
			ReusableMethods.click(DashboardPage.upcoming_milestones);
			int milestones_size = ReusableMethods.getElementsSize(DashboardPage.GTM_milestones);
			if (milestones_size > 1) {
				for (; index<=1; index++) {
					ReusableMethods.click(DashboardPage.GTM_milestones + "[" + index + "]");
				}
			} else {
				ReusableMethods.click(DashboardPage.GTM_milestones + "[" + index + "]");
			}
			ReusableMethods.isElementExists(DashboardPage.GTM_milestone_activities, flag, "Milestone Activities");
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			int milestone_activities_size = ReusableMethods.getElementsSize(DashboardPage.GTM_milestone_activities);
			int indexA = 1;
			if(milestone_activities_size>1) {
				for (; indexA<=1; indexA++) {
					ReusableMethods.click(DashboardPage.GTM_milestone_activities + "[" + indexA + "]");
				}
			} else {
				ReusableMethods.click(DashboardPage.GTM_milestone_activities + "[" + indexA + "]");
			}
			ReusableMethods.isElementExists(DashboardPage.state_dropdown, flag, "Milestone State");
			ReusableMethods.isElementExists(DashboardPage.milestonesubmit, flag, "Milestone Submit");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected static void addNewReleaseOla(DataTable releaseData) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			List<Map<String, String>> releases = releaseData.asMaps(String.class, String.class);
			int size = releases.size();
			for (int anchor = 0; anchor < size; anchor++) {
				Map<String,String> anchorData = releases.get(anchor);
				ReusableMethods.click(DashboardPage.add_release);
				ReusableMethods.enterData(DashboardPage.release_name,anchorData.get("ReleaseName"));
				ReusableMethods.enterData(DashboardPage.description,anchorData.get("Description"));
				ReusableMethods.clickWithoutScreenshot(DashboardPage.releasetype_dropdown);
				ReusableMethods.sendKeys(DashboardPage.releaseSearchInputBox, anchorData.get("ReleaseType"));
				DashboardPage.setReleaseType(anchorData.get("ReleaseType"));
				ReusableMethods.click(DashboardPage.releasetype);
				try {
					if(driver.findElement(DashboardPage.submit).isDisplayed()) {
						test.log(LogStatus.PASS, "Submit button is getting displayed", 
								test.addScreenCapture(capture(driver)));
					}
				} catch(Exception e) {
					test.log(LogStatus.FAIL, "Submit button is NOT getting displayed ", 
							test.addScreenCapture(capture(driver)));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Submit button is NOT getting displayed " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void selectProductWorkstream(String name) throws IOException {
		DashboardPage.setProductOrWorkstream(name);
		ReusableMethods.click(DashboardPage.productWorkstream);
	}

	protected static void select_page(String page) throws InterruptedException, IOException {
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		if(page.equals("Deliverables Overview")) {
			ReusableMethods.click(DetailedViewPage.deliverables_overview);
		} else {
			DashboardPage.setPage(page);
			ReusableMethods.click(DashboardPage.page_name);
		}
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
	}

	protected static void selectWorkstreamProduct(String workstream, String product) 
			throws InterruptedException, IOException {	
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, workstream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		DetailedViewPage.setWorkstreamProduct(product);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
	}

	protected static void selectProductWorkstream(String product, String workstream) 
			throws InterruptedException, IOException {	
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		DetailedViewPage.setWorkstreamProduct(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
	}

	protected static void addRiskToWorkstream(String workstream, DataTable Riskdata) 
			throws InterruptedException, IOException  {	
		beforeAddingRisk = BOMStepDefs.workstreamBomStatusData(workstream);
		BOTStepDefs.addriskToWorkstream(workstream,Riskdata);
		afterAddingRisk = BOMStepDefs.workstreamBomStatusData(workstream);
	}

	protected static void riskToOneWorkstreamRules(String color, String Workstream) 
			throws InterruptedException, IOException, ParseException {
		HashMap<String,String> rule_applied_values=new HashMap<String,String>();
		String exp_val;
		for( String key:beforeAddingRisk.keySet()) {   
			exp_val=beforeAddingRisk.get(key);
			String[] status_color=exp_val.split("-");
			if(color.equals("Red")) {
				if(status_color[0].equals("Red") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				} else {	rule_applied_values.put(key, status_color[0]);	}	
				if(status_color[0].equals("Yellow") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				} else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Green") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				} else {  	rule_applied_values.put(key, status_color[0]);	}
			}
			if(color.equals("Yellow")) {
				if(status_color[0].equals("Red") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				} else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Yellow") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Yellow");	
				} else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Green") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Yellow");	
				} else {  	rule_applied_values.put(key, status_color[0]);	}
			}
			if(color.equals("Green")) {
				if(status_color[0].equals("Red") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				} else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Yellow") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Yellow");	
				} else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Green") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Green");	
				} else {  	rule_applied_values.put(key, status_color[0]);	}
			}
		}
		boolean result=rule_applied_values.equals(afterAddingRisk);
		ReusableMethods.softAssertverification(result, true);
	}

	protected static void validateFilterOptionsAscendingOrder() throws IOException, InterruptedException {
		WebDriver driver = DriverManager.getWebDriver();
		ArrayList<String> arrActualCategory = new ArrayList<String>();
		ArrayList<String> arrExpectedCategory = new ArrayList<String>();
		ReusableMethods.click(DetailedViewPage.filter);
		ReusableMethods.click(DetailedViewPage.filterBomCategory);
		int options = ReusableMethods.getElementsSize(DetailedViewPage.filterBomOptionsList);
		for (int i = 1; i<options+1; i++) {
			DetailedViewPage.setFilterBomCategoryOptions(i);
			arrActualCategory.add(ReusableMethods.getText(DetailedViewPage.filterBomCategoryOptionLabel));
		}
		System.out.println("arrActualCategory " + arrActualCategory);
		arrExpectedCategory = arrActualCategory;
		Collections.sort(arrExpectedCategory);
		if (arrExpectedCategory.equals(arrActualCategory)) {
			test.log(LogStatus.PASS, "BOM Category is in Sorted Ascending Order", 
					test.addScreenCapture(capture(driver)));
		} else {
			test.log(LogStatus.FAIL, "BOM Category is in Unsorted Ascending Order", 
					test.addScreenCapture(capture(driver)));
		}
	}
}