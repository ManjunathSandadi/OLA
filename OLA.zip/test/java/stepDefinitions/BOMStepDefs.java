package stepDefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import dataCollections.BOMCategoryOptions;
import io.cucumber.datatable.DataTable;
import pageObjects.AssignedToMePage;
import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

public class BOMStepDefs extends MasterStepDefs {

	private static String workstreamOverallStatus;
	private static String workstreamOverallStatusAfterupdate;
	private static String allworkstreamStatus;
	private static int notRequiredCount = 0;

	protected static void addBOM(DataTable BOMdata) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> bomData = BOMdata.asMaps(String.class, String.class);
		try {
			int size = bomData.size();
			for (int anchor = 0; anchor < size; anchor++) {
				Map<String,String> bomData1 = bomData.get(anchor);
				String workstream = bomData1.get("Workstream");
				String product = bomData1.get("Product");

				ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_list, product);
				ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

				DetailedViewPage.setWorkstreamProduct(workstream);
				ReusableMethods.click(DetailedViewPage.workStream);
				//ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
				ReusableMethods.click(DetailedViewPage.workStreamButton);
				//ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

				ReusableMethods.click(DetailedViewPage.workStreamAddBom);
				//ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
				ReusableMethods.enterData(DetailedViewPage.bomShortDescription, bomData1.get("ShortDescription"));
				ReusableMethods.enterData(DetailedViewPage.bomDescription, bomData1.get("Description"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomState, bomData1.get("State"));

				if (bomData1.get("BomCategory").equals("Yes")) {
					getBomCategoryDetails(bomData1.get("Workstream"), bomData1.get("Category"));
				}

				ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomCategory, bomData1.get("Category"));
				ReusableMethods.enterData(DetailedViewPage.bomDueDate, bomData1.get("DueDate"));
				ReusableMethods.click(DetailedViewPage.addedButton);
				ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

				test.log(LogStatus.PASS, "Successfully Added the BOM details", 
						test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "NOT Added the BOM details " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void editBOM(String workstream, DataTable BOMdata) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> bomData = BOMdata.asMaps(String.class, String.class);
		try {
			int size = bomData.size();
			for (int anchor = 0; anchor < size; anchor++) {
				Map<String,String> bomData1 = bomData.get(anchor);
				DetailedViewPage.setWorkstreamProduct(workstream);
				ReusableMethods.click(DetailedViewPage.workStream);
				workstreamOverallStatus = GeneralStepDefs.getWorkstreamOverallStatus(workstream);
				allworkstreamStatus = ReusableMethods.getText(DetailedViewPage.allWorkstream);
				String BOM = bomData1.get("BOM");
				try {
					if (ReusableMethods.isDisplayed(DetailedViewPage.paginationBomCheck)) {
						int page_count = ReusableMethods.getElementsSize(DetailedViewPage.pageBomCounts);
						for(int j=2; j<=page_count-1 ; j++) {
							DetailedViewPage.setPageBomCount(page_count);
							ReusableMethods.click(DetailedViewPage.pageBomCount);
							DetailedViewPage.setBOM(BOM);
							try{
								if (ReusableMethods.isDisplayed(DetailedViewPage.addedBomOptionsButton)) {
									ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
									ReusableMethods.click(DetailedViewPage.view_editBom);
									break;
								}
							} catch (Exception e) {
								test.log(LogStatus.PASS, "Moving to next page to find the element", 
										test.addScreenCapture(capture(driver)));
							}
						}
					}
				} catch (Exception e) {
					test.log(LogStatus.INFO, "Only one page is there!!", test.addScreenCapture(capture(driver)));
					DetailedViewPage.setBOM(BOM);
					ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
					ReusableMethods.click(DetailedViewPage.view_editBom);
				}

				ReusableMethods.enterData(DetailedViewPage.bomShortDescriptionEdit, bomData1.get("ShortDescription"));
				ReusableMethods.enterData(DetailedViewPage.bomDescriptionEdit, bomData1.get("Description"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomState, bomData1.get("State"));

				if (bomData1.get("BomCategory").equals("Yes")) {
					getBomCategoryDetails(bomData1.get("Workstream"), bomData1.get("Category"));
				}

				if (ReusableMethods.checkPreRequistes(bomData1.get("TagName"))) {
					ReusableMethods.enterData(DetailedViewPage.bomTagsInput, bomData1.get("TagName"));
					ReusableMethods.click(DetailedViewPage.bomTagsInputAddButton);
				}

				if(bomData1.get("State").equals("Not Required")) { notRequiredCount+=1; }	
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomCategory, bomData1.get("Category"));
				ReusableMethods.enterData(DetailedViewPage.bomDueDate, bomData1.get("DueDate"));

				if(ReusableMethods.checkPreRequistes(bomData1.get("AddDocumentName"))) {
					ReusableMethods.click(DetailedViewPage.addDocumnetToBom);
					ReusableMethods.enterData(DetailedViewPage.bomDocumentName, bomData1.get("AddDocumentName"));
					ReusableMethods.enterData(DetailedViewPage.bomDocumentLinks, bomData1.get("AddDocumentLinks"));
					ReusableMethods.click(DetailedViewPage.add);
				}

				if(ReusableMethods.checkPreRequistes(bomData1.get("RemoveDocumentName"))) {
					DetailedViewPage.set_BOMdocument(bomData1.get("RemoveDocumentName"));
					ReusableMethods.click(DetailedViewPage.removeBomDocumentName);
					ReusableMethods.waitUntilElementVisible(DetailedViewPage.removeDocumentConfirmation);
					ReusableMethods.softAssertverification(ReusableMethods.getText(
							DetailedViewPage.removeDocumentConfirmation),"Are you sure you want to remove the link");
					ReusableMethods.click(DetailedViewPage.yes);
				}

				ReusableMethods.clickJS(DetailedViewPage.addedButton);
				//ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
				//ReusableMethods.waitUntilElementVisible(DetailedViewPage.addedMessage);
				//ReusableMethods.softAssertverification(ReusableMethods.getText(DetailedViewPage.addedMessage),"BOM Updated!");
				//ReusableMethods.click(DetailedViewPage.closeViewEditBomMessage);
				test.log(LogStatus.PASS, "Successfully Edited the BOM details", 
						test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Errored Editing the BOM details " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}

		workstreamOverallStatusAfterupdate = GeneralStepDefs.getWorkstreamOverallStatus(workstream);
		BOTStepDefs.putWorkstreamData("Workstream Overall Status", workstreamOverallStatus);
		BOTStepDefs.putWorkstreamData("Workstream Overall Status After Update", workstreamOverallStatusAfterupdate);
		BOTStepDefs.putWorkstreamData("Workstream Not Required Update Count", String.valueOf(notRequiredCount));
		BOTStepDefs.putWorkstreamData("AllWorkstream Status", allworkstreamStatus);
		BOTStepDefs.putWorkstreamData("AllWorkstream Status After Update", ReusableMethods.getText(
				DetailedViewPage.allWorkstream));
	}

	protected static void cloneBOM(String workstream, DataTable BOMdata) throws InterruptedException, IOException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			DetailedViewPage.setWorkstreamProduct(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			String BOM=bomData1.get("BOM");
			DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);

			ReusableMethods.click(DetailedViewPage.copyCloneBom);

			/*String clone_BOM_name = ReusableMethods.getText(DetailedViewPage.clone_BOM_name);
			if(clone_BOM_name.contains("Copy of") && !clone_BOM_name.isEmpty()) {
				test.log(LogStatus.PASS, "Clone BOM name contains 'Copy of'", test.addScreenCapture(capture(driver)));
			} else {
				test.log(LogStatus.FAIL, "Clone BOM name does NOT contains 'Copy of'", 
						test.addScreenCapture(capture(driver)));
			}*/

			ReusableMethods.click(DetailedViewPage.cloneBOMNext);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			ReusableMethods.enterData(DetailedViewPage.cloneBomShortDesc, bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.cloneBomDesc, bomData1.get("Description"));
			if (bomData1.get("BomCategory").equals("Yes")) {
				getBomCategoryDetails(bomData1.get("Workstream"), bomData1.get("Category"));
			}
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomState, bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomCategory, bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.bomDueDate, bomData1.get("DueDate"));

			if(ReusableMethods.checkPreRequistes(bomData1.get("AddDocumentName"))) {
				ReusableMethods.click(DetailedViewPage.addDocumnetToBom);
				ReusableMethods.enterData(DetailedViewPage.bomDocumentName, bomData1.get("AddDocumentName"));
				ReusableMethods.enterData(DetailedViewPage.bomDocumentLinks, bomData1.get("AddDocumentLinks"));
				ReusableMethods.click(DetailedViewPage.add);
			}

			if(ReusableMethods.checkPreRequistes(bomData1.get("RemoveDocumentName"))) {
				DetailedViewPage.set_BOMdocument(bomData1.get("RemoveDocumentName"));
				ReusableMethods.click(DetailedViewPage.removeBomDocumentName);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.removeDocumentConfirmation);
				ReusableMethods.softAssertverification(ReusableMethods.getText(
						DetailedViewPage.removeDocumentConfirmation),"Are you sure you want to remove the link");
				ReusableMethods.click(DetailedViewPage.yes);
			}

			if(ReusableMethods.checkPreRequistes(bomData1.get("RemoveDependency"))) {
				DetailedViewPage.set_dependency(bomData1.get("RemoveDependency"));
				ReusableMethods.click(DetailedViewPage.removeDependencyName);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.removeDependencyConfirmation);
				ReusableMethods.softAssertverification(ReusableMethods.getText(
						DetailedViewPage.removeDependencyConfirmation),"Are you sure you want to remove the dependency?");
				ReusableMethods.click(DetailedViewPage.yes);
			}

			if (ReusableMethods.checkPreRequistes(bomData1.get("TagName"))) {
				ReusableMethods.enterData(DetailedViewPage.bomTagsInput, bomData1.get("TagName"));
				ReusableMethods.click(DetailedViewPage.bomTagsInputAddButton);
			}

			ReusableMethods.click(DetailedViewPage.addedButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			/*ReusableMethods.waitUntilElementVisible(DetailedViewPage.addedMessage);
			ReusableMethods.softAssertverification(ReusableMethods.getText(
					DetailedViewPage.addedMessage),"BOM Updated!");
			ReusableMethods.click(DetailedViewPage.closeViewEditBomMessage);*/
		}
	}

	protected static HashMap<String, String> workstreamBomStatusData(String workstream) throws IOException {

		DetailedViewPage.setWorkstreamProduct(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		HashMap<String,String> inputData = new HashMap<String,String>();
		try {
			if (ReusableMethods.isDisplayed(DetailedViewPage.paginationBomCheck)) {
				int page_count = ReusableMethods.getElementsSize(DetailedViewPage.pageBomCounts);
				for(int j=2;j<=page_count-1;j++ ) {
					DetailedViewPage.setPageBomCount(page_count);
					ReusableMethods.click(DetailedViewPage.pageBomCount);
					int n = ReusableMethods.getElementsSize(DetailedViewPage.bomDetailsDisplayed);

					for(int i=1;i<=n;i++) {
						BOTStepDefs.getDetailedViewColumnBomHeader();

						String bomName = ReusableMethods.getText(DetailedViewPage.colBomName + "["+i+"]");
						String status = ReusableMethods.getText(DetailedViewPage.colStatus + "["+i+"]");
						String state = ReusableMethods.getText(DetailedViewPage.colState + "["+i+"]");

						inputData.put(bomName, status + "-" + state);
					}
				}
			}
		} catch (Exception e) {
			BOTStepDefs.getDetailedViewColumnBomHeader();
			int n = ReusableMethods.getElementsSize(DetailedViewPage.bomDetailsDisplayed);

			for(int i=1;i<=n;i++) {
				BOTStepDefs.getDetailedViewColumnBomHeader();

				String bomName = ReusableMethods.getText(DetailedViewPage.colBomName + "["+i+"]");
				String status = ReusableMethods.getText(DetailedViewPage.colStatus + "["+i+"]");
				String state = ReusableMethods.getText(DetailedViewPage.colState + "["+i+"]");

				inputData.put(bomName, status + "-" + state);				
			}
		}
		return inputData;	
	}

	protected static void addBOM_FL(DataTable BOMdata) throws InterruptedException, IOException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			String Product = bomData1.get("Product");
			String workstream = bomData1.get("Workstream");
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_list, workstream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

			DetailedViewPage.setProduct(Product);
			ReusableMethods.click(DetailedViewPage.product);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			ReusableMethods.click(DetailedViewPage.productButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			ReusableMethods.click(DetailedViewPage.productAddBom);
			ReusableMethods.enterData(DetailedViewPage.bomShortDescription, bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.bomDescription, bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomState, bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomCategory, bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.bomDueDate, bomData1.get("DueDate"));
			ReusableMethods.click(DetailedViewPage.addedButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		}
	}

	protected static void verifyViewBomOptionsReadOnly(String bOM, DataTable Options) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			options.get(anchor);
			DetailedViewPage.setBOM(bOM);
			int option_size = ReusableMethods.getElementsSize(DetailedViewPage.totalBOMoptions);
			if(option_size==1) {
				ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
				try {
					if(ReusableMethods.isDisplayed(DetailedViewPage.viewBom)) {
						test.log(LogStatus.PASS, "View BOM option is only available which is expected"
								, test.addScreenCapture(capture(driver)));
						ReusableMethods.click(DetailedViewPage.viewBom);
					}
				} catch(Exception e) {
					test.log(LogStatus.FAIL, "View BOM option is Not available which is NOT expected",
							test.addScreenCapture(capture(driver)));
				}
			} else {
				test.log(LogStatus.FAIL, "More than 1 option is available which is NOT expected",
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	protected static void verifyBOMOptions(String bOM, DataTable Options) throws InterruptedException, IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		DetailedViewPage.setBOM(bOM);
		ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
		ReusableMethods.rawWait(2);

		for(int i=1;i<=ReusableMethods.getElementsSize(DetailedViewPage.totalBOMoptions);i++) {
			expected.add(ReusableMethods.getText(DetailedViewPage.totalBOMoptions+"["+i+"]"));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	protected static void RYG_data_validation() throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.rawWait(10);
		String red_count = ReusableMethods.getText(DetailedViewPage.red_count);
		String green_count = ReusableMethods.getText(DetailedViewPage.green_count);
		String yellow_count = ReusableMethods.getText(DetailedViewPage.yellow_count);

		int y_count=0
				,r_count=0
				,g_count=0;

		double open_count=0
				,wip_count=0
				,complete_count=0;

		int r = 0,y = 0,g = 0;
		double percent;

		int page_count=driver.findElements(DetailedViewPage.countPage).size();
		for(int j=2;j<=page_count-1;j++ ) {
			ReusableMethods.click(DetailedViewPage.bomPageCounts + "["+j+"]");
			for(int i=1;i<ReusableMethods.getElementsSize(DetailedViewPage.bomCol10);i++) {
				String status_value=ReusableMethods.getText(DetailedViewPage.bomCol10 + "["+i+"]");
				if(status_value.contains("Red")) { 
					r_count+=1;
				} else if(status_value.contains("Green")) { 
					g_count+=1;
				} else if(status_value.contains("Yellow")) { 
					y_count+=1;
				}
				String state_value=ReusableMethods.getText(DetailedViewPage.bomCol9 + "["+i+"]");
				if(state_value.contains("Open")) { 
					open_count+=1;
				} else if(state_value.contains("Work in Progress")) { 
					wip_count+=1;
				} else if(state_value.contains("Complete")) { 
					complete_count+=1;
				}
			}
		}

		ReusableMethods.click(DashboardPage.dashboard);
		ReusableMethods.rawWait(20);
		String percentage = ReusableMethods.getText(DashboardPage.percentage);
		String dashborad_red_value = ReusableMethods.getText(DashboardPage.red_dashboardcount);
		String dashborad_green_value = ReusableMethods.getText(DashboardPage.green_dashboardcount);
		String dashborad_yellow_value = ReusableMethods.getText(DashboardPage.yellow_dashboardcount);

		if(dashborad_red_value.contains(red_count)) {
			r=Integer.parseInt(red_count);
			test.log(LogStatus.PASS, "Red count matched in Detailed View and Dashboard!!!!!!!!!!!");
		} else { 
			test.log(LogStatus.FAIL, "Red count mismatched in Detailed View and Dashboard!!!!!!!!!!!");
		}
		if(dashborad_yellow_value.contains(yellow_count)) {
			y=Integer.parseInt(yellow_count);
			test.log(LogStatus.PASS, "Yellow count matched in Detailed View and Dashboard!!!!!!!!!!!");
		} else { 
			test.log(LogStatus.FAIL, "Yellow count mismatched in Detailed View and Dashboard!!!!!!!!!!!");
		}
		if(dashborad_green_value.contains(green_count)) {
			g=Integer.parseInt(green_count);
			test.log(LogStatus.PASS, "Green count matched in Detailed View and Dashboard!!!!!!!!!!!");
		} else { 
			test.log(LogStatus.FAIL, "Green count mismatched in Detailed View and Dashboard!!!!!!!!!!!");
		}

		if(r!=r_count) { 
			test.log(LogStatus.FAIL, "Red count mismatched in Detailed View and Table!!!!!!!!!!!");
		}
		if(y!=y_count) { 
			test.log(LogStatus.FAIL, "Yellow count mismatched in Detailed View and Table!!!!!!!!!!!");
		}
		if(g!=g_count) { 
			test.log(LogStatus.FAIL, "Green count mismatched in Detailed View and Table!!!!!!!!!!!");
		}

		//Complete/(Complete+Open+WIP)
		percent = ReusableMethods.round(((complete_count*100)/(complete_count+open_count+wip_count)), 2);
		test.log(LogStatus.PASS, "Percentage = "+Math.round(percent*100.0)/100.0);
		percent=Math.round(percent*100.0)/100.0;
		if(percentage.contains(String.valueOf(percent))) {
			test.log(LogStatus.PASS, "Percentage validation is successful in Dashboard!!!!!!!!!!!", 
					test.addScreenCapture(capture(driver)));
		} else { 
			test.log(LogStatus.FAIL, "Incorrect Percentage value in Dashboard!!!!!!!!!!!" + percent + ", Expected %: " + percentage, 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void validate_RYG_data_for_a_workstream_after_BOM_update(String workstream) throws IOException {
		String overall,nrq,overall_afterupdate,allworkstreams,allworkstreams_afterupdate;
		overall=BOTStepDefs.getWorkstreamData("Workstream Overall Status");
		nrq=BOTStepDefs.getWorkstreamData("Workstream Not Required Update Count");
		overall_afterupdate=BOTStepDefs.getWorkstreamData("Workstream Overall Status After Update");
		allworkstreams=BOTStepDefs.getWorkstreamData("AllWorkstream Status");
		allworkstreams_afterupdate=BOTStepDefs.getWorkstreamData("AllWorkstream Status After Update");
		int overall_val,nrq_val,overall_afterupdate_val,allworkstreams_val,allworkstreams_afterupdate_val,overall_afterupdate_val_expected,allworkstreams_val_expected;
		String[] a=overall_afterupdate.split("/");
		overall_afterupdate_val=Integer.parseInt(a[1]);
		String[] b=overall.split("/");
		overall_val=Integer.parseInt(b[1]);
		nrq_val=Integer.parseInt(nrq);
		overall_afterupdate_val_expected=overall_val-nrq_val;
		if (overall_afterupdate_val_expected==overall_afterupdate_val) {
			ReusableMethods.softAssertverification(true, true);
		} else {
			ReusableMethods.softAssertverification(false, true);
		}

		allworkstreams = allworkstreams.replace("(", "QQQQQ");
		String[] a1=allworkstreams.split("QQQQQ");
		a1[1] = a1[1].replace(")", "QQQQQ");
		allworkstreams_val=Integer.parseInt((a1[1].split("QQQQQ"))[0]);

		allworkstreams_afterupdate = allworkstreams_afterupdate.replace("(", "QQQQQ");
		String[] a2=allworkstreams_afterupdate.split("QQQQQ");
		a2[1] = a2[1].replace(")", "QQQQQ");
		allworkstreams_afterupdate_val=Integer.parseInt((a2[1].split("QQQQQ"))[0]);

		allworkstreams_val_expected=allworkstreams_val-nrq_val;
		if (allworkstreams_val_expected==allworkstreams_afterupdate_val) {
			ReusableMethods.softAssertverification(allworkstreams_val_expected, allworkstreams_afterupdate_val);
		} else {
			ReusableMethods.softAssertverification(false, true);
		}
	}

	protected static void verifyAllWorkstreamColumnNameOrder() throws InterruptedException, IOException {
		//BOM table validation
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		List<String> expected1=new ArrayList<String>();
		List<String> actual1=new ArrayList<String>();

		expected.add("Workstream");
		expected.add("BOM Category");
		expected.add("BOM Name");
		expected.add("Assigned To");
		expected.add("State");
		expected.add("Status");
		expected.add("Partner");
		expected.add("Due Date");
		expected.add("Tags");

		for(int i=5;i<=13;i++) {
			DetailedViewPage.setColumnBomHeaderDetails(i);
			actual.add(ReusableMethods.getText(DetailedViewPage.columnBomHeaders));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Risk table validation
		ReusableMethods.click(DetailedViewPage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		expected1.add("Workstream");
		expected1.add("Applicable To");
		expected1.add("Risk Name");
		expected1.add("Assigned To");
		expected1.add("Status");
		expected1.add("Impact");
		expected1.add("Initiate Date");
		expected1.add("Due Date");

		for(int i=5;i<=12;i++) {
			DetailedViewPage.setColumnRiskHeaderDetails(i);
			actual1.add(ReusableMethods.getText(DetailedViewPage.columnRiskHeaders));
		}
		boolean result1=expected1.equals(actual1);
		ReusableMethods.softAssertverification(result1, true);
	}

	protected static void verifyAllProductColumnNameOrder() throws InterruptedException, IOException {
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		List<String> expected1=new ArrayList<String>();
		List<String> actual1=new ArrayList<String>();

		//BOM table validation

		expected.add("Product");
		expected.add("BOM Category");
		expected.add("BOM Name");
		expected.add("Assigned To");
		expected.add("State");
		expected.add("Status");
		expected.add("Due Date");
		expected.add("Partner");
		expected.add("Tags");

		for(int i=5;i<=13;i++) {
			DetailedViewPage.setColumnBomHeaderDetails(i);
			actual.add(ReusableMethods.getText(DetailedViewPage.columnBomHeaders));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Risk table validation
		ReusableMethods.click(DetailedViewPage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		expected1.add("Product");
		expected1.add("Applicable To");
		expected1.add("Risk Name");
		expected1.add("Assigned To");
		expected1.add("Status");
		expected1.add("Impact");
		expected1.add("Initiate Date");
		expected1.add("Due Date");
		for(int i=5;i<=12;i++) {
			DetailedViewPage.setColumnRiskHeaderDetails(i);
			actual1.add(ReusableMethods.getText(DetailedViewPage.columnRiskHeaders));
		}
		boolean result1=expected1.equals(actual1);
		ReusableMethods.softAssertverification(result1, true);
	}

	protected static void verifyAssignedToMeColumnNameOrder() throws InterruptedException, IOException {
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		List<String> expected1=new ArrayList<String>();
		List<String> actual1=new ArrayList<String>();
		//BOM table validation
		ReusableMethods.click(AssignedToMePage.assignedtome);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

		expected.add("Workstream");
		expected.add("Product");
		expected.add("BOM Category");
		expected.add("BOM Name");
		expected.add("Assigned To");
		expected.add("State");
		expected.add("Status");
		expected.add("Due Date");
		expected.add("Partner");
		expected.add("Tags");

		for(int i=5;i<=14;i++) {
			DetailedViewPage.setATMColumnBomRiskHeaderDetails(i);
			actual1.add(ReusableMethods.getText(DetailedViewPage.atmColumnBomRiskHeaders));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Risk table validation
		ReusableMethods.click(AssignedToMePage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		expected1.add("Workstream");
		expected1.add("Product");
		expected1.add("Applicable To");
		expected1.add("Risk Name");
		expected1.add("Assigned To");
		expected1.add("Status");
		expected1.add("Impact");
		expected1.add("Initiate Date");
		expected1.add("Due Date");

		for(int i=5;i<=13;i++) {
			DetailedViewPage.setATMColumnBomRiskHeaderDetails(i);
			actual1.add(ReusableMethods.getText(DetailedViewPage.atmColumnBomRiskHeaders));
		}
		boolean result1=expected1.equals(actual1);
		ReusableMethods.softAssertverification(result1, true);
	}

	protected static void workstreamActions(String Workstream) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		DetailedViewPage.setWorkstreamProduct(Workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		try {
			if (ReusableMethods.isDisplayed(DetailedViewPage.workStreamButton)) {
				test.log(LogStatus.PASS, "Worktream Options are available which is NOT working as expected", 
						test.addScreenCapture(capture(driver)));
			}		
		} catch(Exception e) {
			test.log(LogStatus.FAIL, "Worktream Options are not available which is working as expected", 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void productActions(String product) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		DetailedViewPage.setProduct(product);
		ReusableMethods.click(DetailedViewPage.product);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		try {
			if (ReusableMethods.isDisplayed(DetailedViewPage.productButton)) {
				test.log(LogStatus.PASS, "Product Options are available which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}		
		} catch(Exception e) {
			test.log(LogStatus.FAIL, "Product Options are NOT available which is expected", 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void verifyFilterStateOption() throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.click(DetailedViewPage.filter);
		ReusableMethods.click(DetailedViewPage.filterState);
		int options = ReusableMethods.getElementsSize(DetailedViewPage.filterStateOptions);
		for (int i = 1; i<options; i++) {
			DetailedViewPage.setFilterStateOptions(i);
			if (ReusableMethods.getText(DetailedViewPage.filterStateOptionLabel).equals("Not Applicable")) {
				ReusableMethods.softAssertverification(ReusableMethods.getAttribute(
						DetailedViewPage.titleNotApplicable, "title"), "Not Applicable");
				ReusableMethods.click(DetailedViewPage.filterStateOption);
				ReusableMethods.click(DetailedViewPage.filterapply);
				int recordsFound = ReusableMethods.getElementsSize(DetailedViewPage.filterRecordsFound);
				for (int j = 1; j < recordsFound+1; j++) {
					if (ReusableMethods.getAttribute(
							DetailedViewPage.titleNotApplicable, "title").equals("Not Applicable")) {
						test.log(LogStatus.PASS, "Only Not Required BOM's are present" +
								ReusableMethods.getAttribute(
										DetailedViewPage.titleNotApplicable, "title"));
					} else {
						test.log(LogStatus.FAIL, "Others BOM's are present in the Not Required filter" +
								ReusableMethods.getAttribute(
										DetailedViewPage.titleNotApplicable, "title"), 
								test.addScreenCapture(capture(driver)));
					}
				}
				int filterNR = ReusableMethods.getElementsSize(DetailedViewPage.titleNotApplicable);
				ReusableMethods.softAssertverification(recordsFound, filterNR);
				for (int k = 1; k < filterNR+1; k++) {
					DetailedViewPage.setEllipsesBOMRisk(k);
					ReusableMethods.scrollToview(DetailedViewPage.ellipsesBomRisk);
					ReusableMethods.click(DetailedViewPage.ellipsesBomRisk);
					DetailedViewPage.setOptViewEditBom(k);
					if (ReusableMethods.isDisplayed(DetailedViewPage.optViewEditBoms)) {
						test.log(LogStatus.PASS, "View/Edit BOM option is getting displayed");
					}
				}
			}
		}
	}

	private static void getBomCategoryDetails(String workstream, String bomCategory) throws IOException {
		ArrayList<String> categoryOptions = new ArrayList<String>();
		categoryOptions = getCategoryVariable(workstream);
		boolean checkPoint = false;
		for (int i = 0; i < categoryOptions.size(); i++) {
			if (bomCategory.equals(categoryOptions.get(i))) {
				checkPoint = true;
				break;
			}
		}
		ReusableMethods.softAssertverification(checkPoint, true);
	}

	private static ArrayList<String> getCategoryVariable(String workstream) {
		DataCollections.getBOMCategoryOptions();
		ArrayList<String> variable = new ArrayList<String>();
		if (workstream.equalsIgnoreCase("Product Ready")) {
			variable = BOMCategoryOptions.getProductReady();
		} else if (workstream.equalsIgnoreCase("Product Content Ready")) {
			variable = BOMCategoryOptions.getProductContentReady();
		} else if (workstream.equalsIgnoreCase("Ready to Operate")) {
			variable = BOMCategoryOptions.getReadytoOperate();
		} else if (workstream.equalsIgnoreCase("Ready to Market")) {
			variable = BOMCategoryOptions.getReadytoMarket();
		} else if (workstream.equalsIgnoreCase("Ready to Sell")) {
			variable = BOMCategoryOptions.getReadytoSell();
		} else if (workstream.equalsIgnoreCase("Ready to Solve")) {
			variable = BOMCategoryOptions.getReadytoSolve();
		} else if (workstream.equalsIgnoreCase("Ready to Deliver")) {
			variable = BOMCategoryOptions.getReadytoDeliver();
		} else if (workstream.equalsIgnoreCase("Ready to Partner")) {
			variable = BOMCategoryOptions.getReadytoPartner();
		} else if (workstream.equalsIgnoreCase("Ready to Train & Learn")) {
			variable = BOMCategoryOptions.getReadytoTrainLearn();
		} else if (workstream.equalsIgnoreCase("Ready to Support")) {
			variable = BOMCategoryOptions.getReadytoSupport();
		} else if (workstream.equalsIgnoreCase("Ready to Adopt")) {
			variable = BOMCategoryOptions.getReadytoAdopt();
		} else if (workstream.equalsIgnoreCase("Release Management & Operation Dates")) {
			variable = BOMCategoryOptions.getReleaseManagementOperationDates();
		} else if (workstream.equalsIgnoreCase("Program Management")) {
			variable = BOMCategoryOptions.getProgramManagement();
		}
		return variable;
	}

	protected static void searchCreateTags(DataTable BOMdata) throws InterruptedException, IOException {
		List<Map<String, String>> bomData = BOMdata.asMaps(String.class, String.class);

		int size = bomData.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);

			ReusableMethods.click(DetailedViewPage.manageTags);
			ReusableMethods.click(DetailedViewPage.manageTagsButton);

			ReusableMethods.enterData(DetailedViewPage.txtSearchCreateTags, bomData1.get("TagName"));
			DetailedViewPage.setSelectExistingTags(bomData1.get("TagName"));

			if (ReusableMethods.isDisplay(DetailedViewPage.selectExistingTags)) {
				ReusableMethods.click(DetailedViewPage.selectExistingTags);
			} else {
				ReusableMethods.click(DetailedViewPage.btnAddTags);
			}
		}
	}
}