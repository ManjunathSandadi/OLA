package stepDefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import pageObjects.*;
import supportLibraries.*;

public class DashboardStepDefs extends MasterStepDefs {

	protected static void selectTileInDashboard(String product, String workstream) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
			ReusableMethods.isDisplayed(LoginPage.topNavigationDashboardView);
			String percentage=ReusableMethods.getText(DashboardPage.percentage).split("%")[0].trim();
			String redValue=ReusableMethods.getText(DashboardPage.red_dashboardcount).split("-")[1].trim();
			String greenValue=ReusableMethods.getText(DashboardPage.green_dashboardcount).split("-")[1].trim();
			String yellowValue=ReusableMethods.getText(DashboardPage.yellow_dashboardcount).split("-")[1].trim();
			double total=Integer.parseInt(redValue)+Integer.parseInt(greenValue)+Integer.parseInt(yellowValue);
			int completedBOMsCount = getCompletedBOMCounts();
			double actualPercentage=(completedBOMsCount*100)/total;

			if(ReusableMethods.two_decimal_places(actualPercentage).contains(percentage)) {
				test.log(LogStatus.PASS, "Actual Percentage = " + percentage + " Calculated Percentage = " +
						ReusableMethods.two_decimal_places(actualPercentage), 
						test.addScreenCapture(capture(driver)));
			} else {
				test.log(LogStatus.FAIL, "Actual Percentage = " + percentage + " Calculated Percentage = " +
						ReusableMethods.two_decimal_places(actualPercentage), 
						test.addScreenCapture(capture(driver)));
			}

			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
			DashboardPage.setProduct_tile(workstream);
			ReusableMethods.highlight(DashboardPage.product_tile);
			ReusableMethods.click(DashboardPage.product_tile);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Actual Percentage = ERROR Calculated Percentage = ERROR " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	private static int getCompletedBOMCounts() throws InterruptedException, IOException {

		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();
		int total = 0;
		
		ReusableMethods.click(DetailedViewPage.deliverables_overview);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		
		expected.add("Product Ready");
		expected.add("Product Content Ready");
		expected.add("Ready to Operate");
		expected.add("Ready to Market");
		expected.add("Ready to Sell");
		expected.add("Ready to Solve");
		expected.add("Ready to Deliver");
		expected.add("Ready to Partner");
		expected.add("Ready to Train & Learn");
		expected.add("Ready to Support");
		//expected.add("Ready to Adopt");
		
		for (int i = 0; i<expected.size(); i++) {
			DashboardPage.setWorkstreamWidgetCompletedStatus(expected.get(i));
			String workstream_completed_data = ReusableMethods.getText(DashboardPage.workstreamWidgetCompletedStatus);
			
			String[] bom_data=workstream_completed_data.split("/");
			//int total_bom=Integer.parseInt(bom_data[1].trim());
			String str1[]=bom_data[0].split(":");
			int completed_bom=Integer.parseInt(str1[1].trim());
			
			actual.add(String.valueOf(completed_bom));
		}
		
		for (int j = 0; j<actual.size(); j++) {
			total = total + (Integer.parseInt(actual.get(j)));
		}
		ReusableMethods.click(DashboardPage.dashboard);
		return total;
	}

	protected static void selectTileInDashboardFNL(String product, String workstream) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			ReusableMethods.isDisplayed(LoginPage.topNavigationHomeIcon);
			ReusableMethods.isDisplayed(LoginPage.topNavigationDashboardView);
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, workstream);
			DashboardPage.setProduct_tile(product);
			ReusableMethods.click(DashboardPage.product_tile);
			test.log(LogStatus.PASS, "User successfully selected the product tiles, product name is " + product, 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.ERROR, e.getLocalizedMessage(), test.addScreenCapture(capture(driver)));
		}
	}
	
	protected static void validateHomeWidgets() throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.click(LoginPage.topNavigationHomeIcon);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.isDisplayed(LoginPage.firstReleaseWidget);
		test.log(LogStatus.PASS, "User successfully navigated to the Home Page", 
				test.addScreenCapture(capture(driver)));
	}
}