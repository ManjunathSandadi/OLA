package stepDefinitions;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import dataCollections.*;
import pageObjects.DetailedViewPage;
import pageObjects.LoginPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

public class DataCollections extends MasterStepDefs  {

	private static Logger log;

	static {
		log = Logger.getLogger(DataCollections.class);
	}

	public static BOMDetailsGTM_AllWS getSourceBOMDetailsGTM_AllWS() {

		WebDriver driver = DriverManager.getWebDriver();

		BOMDetailsGTM_AllWS gtmAllWorkstream = null;

		ArrayList<String> getSourceWorkstream = new ArrayList<String>();
		ArrayList<String> getSourceBOMCategory = new ArrayList<String>();
		ArrayList<String> getSourceBOMName = new ArrayList<String>();
		ArrayList<String> getSourceAssignedto = new ArrayList<String>();
		ArrayList<String> getSourceState = new ArrayList<String>();
		ArrayList<String> getSourceStatus = new ArrayList<String>();
		ArrayList<String> getSourceDueDate = new ArrayList<String>();
		ArrayList<String> getSourcePartner = new ArrayList<String>();
		ArrayList<String> getSourceTags = new ArrayList<String>();

		try {

			ReusableMethods.click(DetailedViewPage.filterIcon);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterComplete);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterOpen);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterWorkInProgress);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterNotRequired);
			ReusableMethods.click(DetailedViewPage.filterapply);

			int pageCount = driver.findElements(LoginPage.pageCount).size();

			for (int pageNum=2; pageNum<=pageCount-1; pageNum++) {

				//LoginPage.setPageNavigate(pageNum);				
				//ReusableMethods.click(LoginPage.pageNavigate);

				//Column Header Checkpoint

				int tableSize = driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]"
						+ "/table/tbody/tr")).size();

				for (int i = 1; i<=tableSize; i++) {

					getSourceWorkstream.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[5]")));

					getSourceBOMCategory.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[6]")));

					getSourceBOMName.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[7]")));

					getSourceAssignedto.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[8]")));

					getSourceState.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[9]")));

					getSourceStatus.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[10]")));

					getSourceDueDate.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[11]")));

					getSourcePartner.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[12]")));
					
					getSourceTags.add(ReusableMethods.getText(By.xpath("(//tbody[@class='bomDetailsRows'])[1]/"
							+ "tr[" + i + "]/td[13]")));
				}
			}

		} catch (Exception e) {
			log.error(e);
		}

		gtmAllWorkstream = new BOMDetailsGTM_AllWS(getSourceWorkstream, getSourceBOMCategory, getSourceBOMName, 
				getSourceAssignedto, getSourceState, getSourceStatus, getSourceDueDate, getSourcePartner, getSourceTags);

		return gtmAllWorkstream;
	}

	/**
	public static BOMDetailsGTM_OneWS getSourceBOMDetailsGTM_OneWS() {

		WebDriver driver = DriverManager.getWebDriver();

		BOMDetailsGTM_OneWS gtmOneWorkstream = null;

		ArrayList<String> getSourceWorkstream = new ArrayList<String>();
		ArrayList<String> getSourceBOMCategory = new ArrayList<String>();
		ArrayList<String> getSourceBOMName = new ArrayList<String>();
		ArrayList<String> getSourceAssignedto = new ArrayList<String>();
		ArrayList<String> getSourceState = new ArrayList<String>();
		ArrayList<String> getSourceStatus = new ArrayList<String>();
		ArrayList<String> getSourceDueDate = new ArrayList<String>();
		ArrayList<String> getSourcePartner = new ArrayList<String>();

		try {

			ReusableMethods.click(DetailedViewPage.filterIcon);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterComplete);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterOpen);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterWorkInProgress);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterNotRequired);
			ReusableMethods.click(DetailedViewPage.filterapply);

			int pageCount = driver.findElements(LoginPage.pageCount).size();

			for (int pageNum=2; pageNum<=pageCount-1; pageNum++) {

				//LoginPage.setPageNavigate(pageNum);				
				//ReusableMethods.click(LoginPage.pageNavigate);

				//Column Header Checkpoint

				int tableSize = driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]"
						+ "/table/tbody/tr")).size();

				for (int i = 1; i<=tableSize; i++) {

					getSourceWorkstream.add(ReusableMethods.getText(By.xpath("((//th[contains(@ng-click,"
							+ "'workstream')])[1]/ancestor::thead/following-sibling::tbody"
							+ "//td[contains(@ng-if,'Allws')])[" + i + "]")));

					getSourceBOMCategory.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[7]")));

					getSourceBOMName.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[8]")));

					getSourceAssignedto.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[9]")));

					getSourceState.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[10]")));

					getSourceStatus.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[11]")));

					getSourceDueDate.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[12]")));

					getSourcePartner.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[13]")));
				}
			}

		} catch (Exception e) {
			log.error(e);
		}

		gtmOneWorkstream = new BOMDetailsGTM_OneWS(getSourceWorkstream, getSourceBOMCategory, getSourceBOMName, 
				getSourceAssignedto, getSourceState, getSourceStatus, getSourceDueDate, getSourcePartner);

		return gtmOneWorkstream;
	}

	 **/
	public static BOMCategoryOptions getBOMCategoryOptions() {

		try {
			BOMCategoryOptions getBOMCategoryOptions = null;

			/**
			 * Initialize the ArrayList
			 */
			ArrayList<String> getProductReady = new ArrayList<String>();
			ArrayList<String> getProductContentReady = new ArrayList<String>();
			ArrayList<String> getReadytoOperate = new ArrayList<String>();
			ArrayList<String> getReadytoMarket = new ArrayList<String>();
			ArrayList<String> getReadytoSell = new ArrayList<String>();
			ArrayList<String> getReadytoSolve = new ArrayList<String>();
			ArrayList<String> getReadytoDeliver = new ArrayList<String>();
			ArrayList<String> getReadytoPartner = new ArrayList<String>();
			ArrayList<String> getReadytoTrainLearn = new ArrayList<String>();
			ArrayList<String> getReadytoSupport = new ArrayList<String>();
			ArrayList<String> getReadytoAdopt = new ArrayList<String>();
			ArrayList<String> getReleaseManagementOperationDates = new ArrayList<String>();
			ArrayList<String> getProgramManagement = new ArrayList<String>();

			getProductReady.add("Compliance");
			getProductReady.add("Core Content");
			getProductReady.add("CSDM");
			getProductReady.add("Customer Outcomes");
			getProductReady.add("DemoHub");
			getProductReady.add("Enablement");
			getProductReady.add("External Content");
			getProductReady.add("General");
			getProductReady.add("Mobile");
			getProductReady.add("New Product Introduction");
			getProductReady.add("Partner Sell / Solve Enablement");
			getProductReady.add("SC Readiness");
			getProductReady.add("Solution Consulting Content");
			getProductReady.add("Support Readiness");
			getProductReady.add("Website (.com)");

			getProductContentReady.add("General");

			getReadytoOperate.add("Compliance");
			getReadytoOperate.add("Core Content");
			getReadytoOperate.add("General");
			getReadytoOperate.add("Legal");
			getReadytoOperate.add("Operations");
			getReadytoOperate.add("Partner Delivery Collateral");
			getReadytoOperate.add("Pricing");
			getReadytoOperate.add("Renewals");
			getReadytoOperate.add("Sales Tools");

			getReadytoMarket.add("Core Content");
			getReadytoMarket.add("Delivery Strategy");
			getReadytoMarket.add("Demo and Visuals");
			getReadytoMarket.add("Enablement");
			getReadytoMarket.add("External Content");
			getReadytoMarket.add("General");
			getReadytoMarket.add("GTM PR");
			getReadytoMarket.add("New Product Introduction");
			getReadytoMarket.add("NPI/GTM");
			getReadytoMarket.add("Sales Tools");
			getReadytoMarket.add("SC Readiness");
			getReadytoMarket.add("Services Sales Enablement");
			getReadytoMarket.add("Website (.com)");

			getReadytoSell.add("Enablement");
			getReadytoSell.add("General");
			getReadytoSell.add("New Product Introduction");

			getReadytoSolve.add("DemoHub");
			getReadytoSolve.add("Enablement");
			getReadytoSolve.add("General");
			getReadytoSolve.add("SC Readiness");
			getReadytoSolve.add("Empty");

			getReadytoDeliver.add("Customer Outcomes");
			getReadytoDeliver.add("Delivery & Services Sales Enablement");
			getReadytoDeliver.add("Delivery Enablement");
			getReadytoDeliver.add("Delivery Services Collateral");
			getReadytoDeliver.add("Delivery Strategy");
			getReadytoDeliver.add("Enablement");
			getReadytoDeliver.add("General");
			getReadytoDeliver.add("NowCreate Delivery Collateral");
			getReadytoDeliver.add("Services Delivery Collateral");
			getReadytoDeliver.add("Services Sales Collateral");
			getReadytoDeliver.add("Services Sales Enablement");
			getReadytoDeliver.add("Value Content");

			getReadytoPartner.add("General");
			getReadytoPartner.add("Partner Delivery Collateral");
			getReadytoPartner.add("Partner Delivery Enablement");
			getReadytoPartner.add("Partner Sell / Solve Collateral");
			getReadytoPartner.add("Partner Sell / Solve Enablement");
			getReadytoPartner.add("Sales Tools");

			getReadytoTrainLearn.add("Core Content");
			getReadytoTrainLearn.add("General");

			getReadytoSupport.add("General");
			getReadytoSupport.add("Support Readiness");

			getReadytoAdopt.add("Adoption Readiness");
			getReadytoAdopt.add("General");

			getReleaseManagementOperationDates.add("Operation Dates");
			getReleaseManagementOperationDates.add("Release Management");

			getProgramManagement.add("GTM PR");
			getProgramManagement.add("NPI/GTM");
			getProgramManagement.add("Pricing");

			getBOMCategoryOptions = new BOMCategoryOptions(getProductReady, getProductContentReady, getReadytoOperate,
					getReadytoMarket, getReadytoSell, getReadytoSolve, getReadytoDeliver, getReadytoPartner,
					getReadytoTrainLearn, getReadytoSupport, getReadytoAdopt, getReleaseManagementOperationDates,
					getProgramManagement);

			return getBOMCategoryOptions;
		
		} catch (Exception e) {
			log.error(e);
			return null;
		}
	}
}