package stepDefinitions;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import io.cucumber.datatable.DataTable;
import pageObjects.*;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

public class BOTStepDefs extends MasterStepDefs {

	protected static HashMap<String,String> workstreamData = new HashMap<String,String>();

	protected static void putWorkstreamData(String key, String value){
		workstreamData.put(key,value);
	}

	protected static String getWorkstreamData(String key){
		return workstreamData.get(key);
	}

	protected static HashMap<String,String> getWorkstreamData(){
		return workstreamData;
	}

	protected static void addRiskToExistingBom(String BOM, DataTable Riskdata) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);

		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);
			try {
				if (ReusableMethods.isDisplayed(DetailedViewPage.paginationBomCheck)){
					int page_count = ReusableMethods.getElementsSize(DetailedViewPage.pageBomCounts);
					for(int j=2;j<=page_count-1;j++ ) {
						DetailedViewPage.setPageBomCount(page_count);
						ReusableMethods.click(DetailedViewPage.pageBomCount + "[" + j + "]");
						DetailedViewPage.setBOM(BOM);
						try{
							if (ReusableMethods.isDisplayed(DetailedViewPage.addedBomOptionsButton)) {
								ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
								ReusableMethods.click(DetailedViewPage.addRiskToBOM);
								break;
							}
						} catch (Exception e) {
							if(j==page_count-1) {
								test.log(LogStatus.INFO, "BOM is not present in the UI", 
										test.addScreenCapture(capture(driver)));
							} else {
								test.log(LogStatus.INFO, "Moving to next page to find the element", 
										test.addScreenCapture(capture(driver)));
							}
						}
					}
					ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
					ReusableMethods.enterData(DetailedViewPage.riskShortDescription, riskData1.get("ShortDescription"));
					ReusableMethods.enterData(DetailedViewPage.riskDescription, riskData1.get("Description"));
					ReusableMethods.selectDataByVisibleText(DetailedViewPage.riskImpact, riskData1.get("Impact"));
					ReusableMethods.selectDataByVisibleText(DetailedViewPage.riskStatus, riskData1.get("RiskStatus"));
					ReusableMethods.enterData(DetailedViewPage.bomMitigation, riskData1.get("MitigationPlan"));
					ReusableMethods.enterData(DetailedViewPage.bomDueDate, riskData1.get("DueDate"));
					ReusableMethods.isNotDisplay(DetailedViewPage.riskBomCategory);
					ReusableMethods.click(DetailedViewPage.addedRiskButton);
					ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
					test.log(LogStatus.PASS, "Risk Added to the Existing BOM Sucessfully!!!", 
							test.addScreenCapture(capture(driver)));
				}
			} catch(Exception e1) {
				test.log(LogStatus.INFO, "Only one page is there!!", test.addScreenCapture(capture(driver)));
				try{
					DetailedViewPage.setBOM(BOM);
					if (ReusableMethods.isDisplayed(DetailedViewPage.addedBomOptionsButton)) {
						ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
						ReusableMethods.click(DetailedViewPage.addRiskToBOM);
						ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
						ReusableMethods.enterData(DetailedViewPage.riskShortDescription, riskData1.get("ShortDescription"));
						ReusableMethods.enterData(DetailedViewPage.riskDescription, riskData1.get("Description"));
						ReusableMethods.selectDataByVisibleText(DetailedViewPage.riskImpact, riskData1.get("Impact"));
						ReusableMethods.selectDataByVisibleText(DetailedViewPage.riskStatus, riskData1.get("RiskStatus"));
						ReusableMethods.enterData(DetailedViewPage.bomMitigation, riskData1.get("MitigationPlan"));
						ReusableMethods.enterData(DetailedViewPage.bomDueDate, riskData1.get("DueDate"));
						ReusableMethods.isNotDisplay(DetailedViewPage.riskBomCategory);
						ReusableMethods.click(DetailedViewPage.addedRiskButton);
						ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
						test.log(LogStatus.PASS, "Risk Added to the Existing BOM Sucessfully!!!", 
								test.addScreenCapture(capture(driver)));
					}
				} catch (Exception e) {
					test.log(LogStatus.ERROR, "BOM is not present in the UI", 
							test.addScreenCapture(capture(driver)));
				}			
			}
		}
	}

	protected static void editRiskToExistingBom(String workstream, DataTable Riskdata) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> riskData = Riskdata.asMaps(String.class, String.class);
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);
			DetailedViewPage.setWorkstreamProduct(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);

			try {
				if (ReusableMethods.isDisplayed(DetailedViewPage.paginationRiskCheck)){
					int page_count = ReusableMethods.getElementsSize(DetailedViewPage.pageRiskCounts);
					for(int j=2;j<=page_count-1;j++ ) {
						DetailedViewPage.setPageRiskCount(page_count);
						ReusableMethods.click(DetailedViewPage.pageRiskCount + "[" + j + "]");
						DetailedViewPage.setRisk(riskData1.get("BOMname"), riskData1.get("Riskname"));
						try{
							if (ReusableMethods.isDisplayed(DetailedViewPage.btnViewEditRiskOptions)) {
								ReusableMethods.click(DetailedViewPage.btnViewEditRiskOptions);
								ReusableMethods.click(DetailedViewPage.view_editRisk);
								test.log(LogStatus.PASS, "Updated the Risk Details", 
										test.addScreenCapture(capture(driver)));
								break;
							}
						} catch (Exception e) {
							test.log(LogStatus.INFO, "Moving to next page to find the element", 
									test.addScreenCapture(capture(driver)));
						}
					}
				}
			} catch(Exception e) {
				test.log(LogStatus.INFO, "Only one page is there!!", 
						test.addScreenCapture(capture(driver)));
				DetailedViewPage.setRisk(riskData1.get("BOMname"), riskData1.get("Riskname"));
				ReusableMethods.click(DetailedViewPage.btnViewEditRiskOptions);
				ReusableMethods.click(DetailedViewPage.view_editRisk);
				ReusableMethods.enterData(DetailedViewPage.editrisk_BOM_shortdescription, riskData1.get("ShortDescription"));
				ReusableMethods.enterData(DetailedViewPage.editrisk_BOM_description, riskData1.get("Description"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.editrisk_BOM_impactstatus, riskData1.get("Impact"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.riskStatus, riskData1.get("RiskStatus"));
				ReusableMethods.enterData(DetailedViewPage.bomMitigation, riskData1.get("MitigationPlan"));
				ReusableMethods.enterData(DetailedViewPage.bomDueDate, riskData1.get("DueDate"));
				ReusableMethods.isNotDisplay(DetailedViewPage.riskBomCategory);
				ReusableMethods.click(DetailedViewPage.addedButton);
				/*	ReusableMethods.waitUntilElementVisible(DetailedViewPage.addedMessage);
				ReusableMethods.softAssertverification(ReusableMethods.getText(DetailedViewPage.addedMessage)
						,"Risk Updated!");
				ReusableMethods.click(DetailedViewPage.closeViewEditBomMessage); */
				test.log(LogStatus.PASS, "Risk Updated Successfully!!!", 
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	protected static void addriskToWorkstream(String workstream, DataTable Riskdata) 
			throws InterruptedException, IOException {

		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);

			DetailedViewPage.setWorkstreamProduct(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);	
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			ReusableMethods.click(DetailedViewPage.workStreamAddRisk);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);

			ReusableMethods.enterData(DetailedViewPage.bomShortDescription, riskData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.bomDescription, riskData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.riskImpact, riskData1.get("Impact"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.riskStatus, riskData1.get("RiskStatus"));
			ReusableMethods.enterData(DetailedViewPage.bomMitigation, riskData1.get("MitigationPlan"));
			ReusableMethods.enterData(DetailedViewPage.bomDueDate, riskData1.get("DueDate"));
			ReusableMethods.isNotDisplay(DetailedViewPage.riskBomCategory);
			ReusableMethods.click(DetailedViewPage.addedButton);
			//reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			//String message=driver.findElement(DetailedViewPage.added_message).getText();
			//reusableMethods.softAssertverification(message," Risk Submitted! ");
			//reusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);
		}
	}

	protected static void addDependencyToExistingBom(String BOM, DataTable Dependencydata) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> dependencydata = Dependencydata.asMaps(String.class, String.class);
		int size = dependencydata.size();
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> dependencydata1 = dependencydata.get(anchor);
			DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(DetailedViewPage.addDependencyToBOM);
			ReusableMethods.click(DetailedViewPage.dependent_BOM_prod_family_dropdown);
			System.out.println(dependencydata1.get("DependentBOMProductFamily"));
			ReusableMethods.enterDataWthoutTab(DetailedViewPage.dependent_BOM_prod_family_input
					,dependencydata1.get("DependentBOMProductFamily"));
			DetailedViewPage.setDependent_BOM_Value(dependencydata1.get("DependentBOMProductFamily"));
			ReusableMethods.click(DetailedViewPage.dependent_BOM_value);
			ReusableMethods.click(DetailedViewPage.dependent_BOM_workstream_dropdown);
			System.out.println(dependencydata1.get("DependentBOMWorkstream"));
			ReusableMethods.enterDataWthoutTab(DetailedViewPage.dependent_BOM_workstream_input
					,dependencydata1.get("DependentBOMWorkstream"));
			DetailedViewPage.setDependent_BOM_Value(dependencydata1.get("DependentBOMWorkstream"));
			ReusableMethods.click(DetailedViewPage.dependent_BOM_value);
			ReusableMethods.click(DetailedViewPage.dependent_BOM_dropdown);
			ReusableMethods.click(DetailedViewPage.dependent_BOM_firstOption);
			ReusableMethods.click(DetailedViewPage.addedDependencyButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			test.log(LogStatus.PASS, "Added Dependency Successfully!!!", 
					test.addScreenCapture(capture(driver)));
		}		
	}

	protected static void addDocument(DataTable Documentdata) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.click(DashboardPage.dashboard);
		List<Map<String, String>> documentdata =Documentdata.asMaps(String.class, String.class);
		int size = documentdata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = documentdata.get(anchor);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			ReusableMethods.click(DetailedViewPage.add_document);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			ReusableMethods.enterData(DetailedViewPage.document_name, documentdata1.get("DocumentName"));
			ReusableMethods.enterData(DetailedViewPage.document_link, documentdata1.get("DocumentLinks"));
			ReusableMethods.click(DetailedViewPage.addedButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			/*reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			reusableMethods.waitUntilElementEnabled(DetailedViewPage.added_message);
			reusableMethods.waitForLoad();		
			String message=driver.findElement(DetailedViewPage.added_message).getText();
			reusableMethods.softAssertverification(message,"The Document Link has been added.");
			reusableMethods.click(DetailedViewPage.close_add_document_message); */
			test.log(LogStatus.PASS, "Added Document Successfully!!!", 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void removeDocument(DataTable Documentdata) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> documentdata =Documentdata.asMaps(String.class, String.class);
		int size = documentdata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = documentdata.get(anchor);
			DetailedViewPage.setDocument(documentdata1.get("DocumentName"));
			ReusableMethods.click(DetailedViewPage.removeDocumentName);
			ReusableMethods.waitUntilElementVisible(DetailedViewPage.removeDocumentConfirmation);
			ReusableMethods.softAssertverification(ReusableMethods.getText(
					DetailedViewPage.removeDocumentConfirmation),"Are you sure you want to remove the link");
			ReusableMethods.click(DetailedViewPage.yes);
			test.log(LogStatus.PASS, "Removed Document Successfully!!!", 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void columnNameOrderVerificationSpecificWorkstream(DataTable Workstreams) 
			throws IOException {
		List<Map<String, String>> workstream = Workstreams.asMaps(String.class, String.class);

		List<String> expectedBomDetailedPage = new ArrayList<String>();
		List<String> actualBomDetailedPage=new ArrayList<String>();

		List<String> expectedRiskDetailedPage = new ArrayList<String>();
		List<String> actualRiskDetailedPage=new ArrayList<String>();

		int size = workstream.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = workstream.get(anchor);
			DetailedViewPage.setWorkstreamProduct(documentdata1.get("Workstreams"));
			ReusableMethods.click(DetailedViewPage.workStream);

			//BOM table validation
			expectedBomDetailedPage.add("BOM Category");
			expectedBomDetailedPage.add("BOM Name");
			expectedBomDetailedPage.add("Assigned to");
			expectedBomDetailedPage.add("State");
			expectedBomDetailedPage.add("Status");
			expectedBomDetailedPage.add("Partner");
			expectedBomDetailedPage.add("Due Date");
			expectedBomDetailedPage.add("Tags");

			for(int i=6; i<=13; i++) {
				actualBomDetailedPage.add(ReusableMethods.getText("(//thead//th)[" + i + "]"));
			}
			boolean result = expectedBomDetailedPage.equals(actualBomDetailedPage);
			ReusableMethods.softAssertverification(result, true);

			//Risk table validation
			expectedRiskDetailedPage.add("Applicable To");
			expectedRiskDetailedPage.add("Risk Name");
			expectedRiskDetailedPage.add("Assigned to");
			expectedRiskDetailedPage.add("Status");
			expectedRiskDetailedPage.add("Impact");
			expectedRiskDetailedPage.add("Initiate Date");
			expectedRiskDetailedPage.add("Due Date");

			for(int j=27; j<=33; j++) {
				actualRiskDetailedPage.add(ReusableMethods.getText("(//thead//th)[" + j + "]"));
			}
			boolean result1 = expectedRiskDetailedPage.equals(actualRiskDetailedPage);
			ReusableMethods.softAssertverification(result1, true);
		}
		DetailedViewPage.setWorkstreamProduct("All Workstreams");
		ReusableMethods.click(DetailedViewPage.workStream);
	}

	protected static void verifyWorkstreamDocumentsOptions(DataTable Workstreams) throws IOException {

		List<Map<String, String>> workstream = Workstreams.asMaps(String.class, String.class);
		int size = workstream.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata = workstream.get(anchor);
			DetailedViewPage.setWorkstreamProduct(documentdata.get("Workstreams"));
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			String expected, actual = "";

			if (ReusableMethods.isDisplay(DetailedViewPage.add_doc)) {
				expected = ReusableMethods.getText(DetailedViewPage.add_doc);
				if(documentdata.get("Workstreams")
						.equals("Product Ready")) {
					actual="Add Scope Doc";
				} else {
					actual="Add Plan Doc";
				}
			} else if (ReusableMethods.isDisplay(DetailedViewPage.viewdoc)) {
				expected = ReusableMethods.getText(DetailedViewPage.viewdoc);
				if(documentdata.get("Workstreams")
						.equals("Product Ready")) {
					actual="View Scope Doc";
				} else {
					actual="View Plan Doc";
				}
			} else if (ReusableMethods.isDisplay(DetailedViewPage.add_delete_doc)) {
				expected = ReusableMethods.getText(DetailedViewPage.add_delete_doc);
				if(documentdata.get("Workstreams")
						.equals("Product Ready")) {
					actual="Add/Delete Scope Doc";
				} else {
					actual="Add/Delete Plan Doc";
				}
			} else {
				expected = "Option not displayed";
			}
			boolean result=expected.equals(actual);
			ReusableMethods.softAssertverification(result, true);
		}
	}

	protected static void verifyWorkstreamDocumentsOptionsFNL(String Workstream, DataTable Sections) 
			throws IOException {
		List<Map<String, String>> sections =Sections.asMaps(String.class, String.class);
		int size = sections.size();

		for (int anchor = 0; anchor < size; anchor++) {

			String expected;
			boolean result = false;
			Map<String,String> sectiondata = sections.get(anchor);
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, Workstream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
			DetailedViewPage.setWorkstreamProduct(sectiondata.get("Options"));
			//ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.click(DetailedViewPage.workStreamButton);

			for(int i=1;i<=ReusableMethods.getElementsSize(DetailedViewPage.add_delete_doc);i++) {
				expected = ReusableMethods.getText(DetailedViewPage.add_delete_doc+"["+i+"]");
				if(Workstream.equals("Product Ready")) {
					if(expected.equals("Add/Delete Scope Doc") || expected.equals("Add Scope Doc"))  {
						result=true;
					} else {
						result=false;
					}
				} else if(!Workstream.equals("Product Ready")) {
					if(expected.equals("Add/Delete Scope Doc") || expected.equals("Add Scope Doc"))  {
						result=false;
					} else {
						result=true;
					}
				}
			}
			ReusableMethods.softAssertverification(result, true);
		}
	}

	protected static void RYG_rule1(String bOM, String workstream) throws ParseException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		String due_dt
		,state;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);

		DetailedViewPage.setWorkstreamProduct(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		try {
			if (ReusableMethods.isDisplayed(DetailedViewPage.paginationBomCheck)) {
				int page_count = ReusableMethods.getElementsSize(DetailedViewPage.pageBomCounts);
				for(int j=2;j<=page_count-1;j++ ) {
					DetailedViewPage.setPageBomCount(j);
					ReusableMethods.click(DetailedViewPage.pageBomCount);
					DetailedViewPage.setBOM(bOM);
					try{
						if (ReusableMethods.isDisplayed(DetailedViewPage.addedBomOptionsButton)) {
							ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
							ReusableMethods.click(DetailedViewPage.view_editBom);
							break;
						}
					} catch (Exception e) {
						if(j==page_count-1) {
							test.log(LogStatus.WARNING, "Mentioned BOM is not present in UI", 
									test.addScreenCapture(capture(driver)));
						} else {
							test.log(LogStatus.INFO, "Moving to next page to find the element", 
									test.addScreenCapture(capture(driver)));
						}
					}
				}
			}
		} catch(Exception e) {
			test.log(LogStatus.INFO, "Only one page is there!!");
			DetailedViewPage.setBOM(bOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(DetailedViewPage.view_editBom);
		}

		due_dt=ReusableMethods.getText(DetailedViewPage.bomDueDate);
		state=ReusableMethods.getText(DetailedViewPage.bomState);

		Date firstDate = sdf.parse(due_dt);
		Date secondDate = new Date();

		long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
		long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

		ReusableMethods.softAssertverification(6, diff);

		if(!state.equals("Complete") && (diff>0)) {

		}
	}

	protected static void RYG_risk_rules(String status,String bOM, String workstream) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		DetailedViewPage.setWorkstreamProduct(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		String status_value = null;
		try {
			if (ReusableMethods.isDisplayed(DetailedViewPage.paginationBomCheck)) {
				int page_count = ReusableMethods.getElementsSize(DetailedViewPage.pageBomCounts);
				for(int j=2;j<=page_count-1;j++ ) {
					DetailedViewPage.setPageBomCount(j);
					ReusableMethods.click(DetailedViewPage.pageBomCount);
					try{
						if (ReusableMethods.isDisplayed("//span[@title='"+bOM+"']")) {
							int n = ReusableMethods.getElementsSize("//tbody//td[9]");		
							for(int i=1;i<n;i++) {
								String actual_bom = ReusableMethods.getText("//tbody//td[6]");
								if(actual_bom.equals(bOM)) {
									status_value = ReusableMethods.getText("(//tbody//td[9])["+i+"]");
									break;
								}	
							}
						}
						break;
					} catch (Exception e) {
						if(j==page_count-1) {
							test.log(LogStatus.INFO, "Mentioned BOM is not present in UI", 
									test.addScreenCapture(capture(driver)));
						} else {
							test.log(LogStatus.INFO, "Moving to next page to find the element", 
									test.addScreenCapture(capture(driver)));
						}
					}
				}
			}
		} catch(Exception e) {
			try{
				if (ReusableMethods.isDisplayed("//tbody//td[6 and @title='"+bOM+"']")) {
					int n = ReusableMethods.getElementsSize("//tbody//td[9]");		
					for(int i=1;i<n;i++) {
						String actual_bom = ReusableMethods.getText("//tbody//td[6]");
						if(actual_bom.equals(bOM)) {
							status_value = ReusableMethods.getText("(//tbody//td[9])["+i+"]");
							break;
						}	
					}
				}
			} catch (Exception e1) {
				test.log(LogStatus.INFO, "Mentioned BOM is not present in UI", 
						test.addScreenCapture(capture(driver)));
			}
		}
		ReusableMethods.softAssertverification(status, status_value);	
	}

	protected static void verifyViewEditRiskOptions(String risk,String BOM, DataTable Options) 
			throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> options = Options.asMaps(String.class, String.class);

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			options.get(anchor);
			DetailedViewPage.setRisk(BOM,risk);
			int option_size = ReusableMethods.getElementsSize(DetailedViewPage.total_risk_options);
			if(option_size==1) {
				ReusableMethods.click(DetailedViewPage.btnViewEditRiskOptions);
				try {
					if(ReusableMethods.isDisplayed(DetailedViewPage.view_risk)) {
						test.log(LogStatus.PASS, "View Risk option is only available which is expected", 
								test.addScreenCapture(capture(driver)));
						ReusableMethods.click(DetailedViewPage.view_risk);
					}
				} catch(Exception e) {
					test.log(LogStatus.FAIL, "View Risk option is Not available which is NOT expected", 
							test.addScreenCapture(capture(driver)));
				}
			} else {
				test.log(LogStatus.FAIL, "More than 1 option is available which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	protected static void verifyAssignedToMeFilterOptions() throws IOException, InterruptedException {
		ReusableMethods.isElementExists(AssignedToMePage.bom_risk_search_button, true,  "Assigned to Me Search Icon");
		ReusableMethods.isElementExists(AssignedToMePage.bulk_update_chklall, true, "Assigned to Me Search All Icon");
		ReusableMethods.isElementExists(AssignedToMePage.filter, true, "Assigned to Me Filter Icon");
		ReusableMethods.isElementExists(AssignedToMePage.bulkupdate, true, "Assigned to Me Bulk Edit Icon");
		ReusableMethods.isElementExists(AssignedToMePage.state, true, "Assigned to Me State");
		ReusableMethods.isElementExists(AssignedToMePage.change_due_dt, true, "Assigned to Me Change due date");
		ReusableMethods.isElementExists(AssignedToMePage.change_state, true, "Assigned to Me Change State");
		ReusableMethods.isElementExists(AssignedToMePage.change_assigned_to, true, "Assigned to Me Change Assigned To");
		ReusableMethods.isElementExists(AssignedToMePage.columnwise_search_button, true, "Assigned to Me Column Search Icon");
		ReusableMethods.isElementExists(AssignedToMePage.columnwise_search_inputbox, true, "Assigned to Me Column Search Input");		
	}

	protected static void verifyAssignedToMeBomOptions(String bOM, String workstream, String product, DataTable Optiondata) throws InterruptedException, IOException {
		List<Map<String, String>> optiondata = Optiondata.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		List<String> expected=new ArrayList<String>();

		int size = optiondata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(optiondata.get(anchor).get("Options"));
		}

		AssignedToMePage.setBtnWorkstreamProductBom(workstream, product, bOM);
		ReusableMethods.click(AssignedToMePage.btnWorkstreamProductBom);

		AssignedToMePage.setOptWorkstreamProductBom(workstream, product, bOM);

		for(int i=1;i<=ReusableMethods.getElementsSize(AssignedToMePage.optWorkstreamProductBom);i++) {
			expected.add(ReusableMethods.getText(AssignedToMePage.optWorkstreamProductBom + "["+i+"]"));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
		ReusableMethods.softAssertverification(expected, actual);
	}

	protected static void verifyOptionsWorkstream(String Workstream, DataTable Options) throws IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		DetailedViewPage.setWorkstreamProduct(Workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.click(DetailedViewPage.workStreamButton);

		for(int i=1;i<=ReusableMethods.getElementsSize(DetailedViewPage.total_WS_options);i++) {
			expected.add(ReusableMethods.getText(DetailedViewPage.total_WS_options+"["+i+"]"));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
		ReusableMethods.softAssertverification(expected, actual);
	}

	protected static void verifyOptionsProduct(String Product, DataTable Options) 
			throws InterruptedException, IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		DetailedViewPage.setProduct(Product);
		ReusableMethods.click(DetailedViewPage.product);
		ReusableMethods.click(DetailedViewPage.productButton);

		for(int i=1;i<=ReusableMethods.getElementsSize(DetailedViewPage.total_product_options);i++) {
			expected.add(ReusableMethods.getText(DetailedViewPage.total_product_options+"["+i+"]"));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
		ReusableMethods.softAssertverification(expected, actual);
	}

	protected static void verifyOptionsRisk(String risk,String BOM, DataTable Options) 
			throws InterruptedException, IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		DetailedViewPage.setRisk(BOM,risk);
		ReusableMethods.click(DetailedViewPage.btnViewEditRiskOptions);

		for(int i=1;i<=ReusableMethods.getElementsSize(DetailedViewPage.total_risk_options);i++) {
			expected.add(ReusableMethods.getText(DetailedViewPage.total_risk_options+"["+i+"]"));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
		ReusableMethods.softAssertverification(expected, actual);
	}

	protected static void verifyOptionsAllWorkstream(DataTable optionsdata) 
			throws InterruptedException, IOException {
		List<Map<String, String>> options =optionsdata.asMaps(String.class, String.class);
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		DetailedViewPage.setWorkstreamProduct("All Worstreams");
		ReusableMethods.click(DetailedViewPage.allProducts);
		ReusableMethods.click(DetailedViewPage.allworkStreamButton);

		for(int i=1;i<=ReusableMethods.getElementsSize(DetailedViewPage.allworkStreamoptions);i++) {
			expected.add(ReusableMethods.getText(DetailedViewPage.allworkStreamoptions+"["+i+"]"));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
		ReusableMethods.softAssertverification(expected, actual);
	}

	protected static void verifyOptionsAllProducts(DataTable optionsdata) throws InterruptedException, IOException {
		List<Map<String, String>> options =optionsdata.asMaps(String.class, String.class);
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		DetailedViewPage.setWorkstreamProduct("All Products");
		ReusableMethods.click(DetailedViewPage.allProducts);
		ReusableMethods.click(DetailedViewPage.allworkStreamButton);

		for(int i=1;i<=ReusableMethods.getElementsSize(DetailedViewPage.allworkStreamoptions);i++) {
			expected.add(ReusableMethods.getText(DetailedViewPage.allworkStreamoptions+"["+i+"]"));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
		ReusableMethods.softAssertverification(expected, actual);
	}

	protected static void verifyFilterBulkeditSearchOptions(DataTable filteroptions) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> options =filteroptions.asMaps(String.class, String.class);
		List<String> expected=new ArrayList<String>();
		List<String> actual=new ArrayList<String>();

		DetailedViewPage.setWorkstreamProduct("All");
		ReusableMethods.click(DetailedViewPage.allworkStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.isElementExists(DetailedViewPage.filterIcon, true, "Filter Icon");
		ReusableMethods.isElementExists(DetailedViewPage.selectall, true, "Select All check box");
		ReusableMethods.isElementExists(DetailedViewPage.search, true, "Search Icon");
		ReusableMethods.isElementExists(DetailedViewPage.bulk_edit, true, "Buld edit icon");

		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("FilterOptions"));
		}

		ReusableMethods.click(DetailedViewPage.filterIcon);

		int option_size = ReusableMethods.getElementsSize(DetailedViewPage.filer_options);
		for(int i=1;i<=option_size;i++) {
			expected.add(ReusableMethods.getText(DetailedViewPage.filer_options+"["+i+"]"));
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Apply 1st option in filter
		for (int j = 1; j < ReusableMethods.getElementsSize(DetailedViewPage.filer_options); j++) {
			ReusableMethods.click(DetailedViewPage.filer_options + "[" + j + "]");
		}
		ReusableMethods.click(DetailedViewPage.filterapply);

		//Check Breadcrumb
		try {
			if(ReusableMethods.isDisplayed(DetailedViewPage.breadcrumb+"[1]")) {
				test.log(LogStatus.PASS, "Breadcrumb is getting displayed", 
						test.addScreenCapture(capture(driver)));
			}			
		} catch(Exception e) {
			test.log(LogStatus.FAIL, "Breadcrumb is NOT getting displayed", 
					test.addScreenCapture(capture(driver)));
		}
		ReusableMethods.click(DetailedViewPage.breadcrumb+"[1]");

		ReusableMethods.click(DetailedViewPage.search);
		if(ReusableMethods.getElementsSize(DetailedViewPage.search_input)>1) {
			test.log(LogStatus.PASS, "Search Input is getting displayed", 
					test.addScreenCapture(capture(driver)));
		} else {
			test.log(LogStatus.FAIL, "Search Input is NOT getting displayed", 
					test.addScreenCapture(capture(driver)));
		}

		//Risk Search Option
		ReusableMethods.click(DetailedViewPage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loadingDots);
		ReusableMethods.isElementExists(DetailedViewPage.risk_selectall,true,"Select All check box");
		ReusableMethods.isElementExists(DetailedViewPage.risk_search,true,"Search Icon");
		ReusableMethods.click(DetailedViewPage.risk_search);
		if(ReusableMethods.getElementsSize(DetailedViewPage.search_input)>1) {
			test.log(LogStatus.PASS, "Search Input is getting displayed", 
					test.addScreenCapture(capture(driver)));
		} else {
			test.log(LogStatus.FAIL, "Search Input is NOT getting displayed", 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static HashMap<String,String> getDetailedViewColumnBomHeader() {
		WebDriver driver = DriverManager.getWebDriver();
		HashMap<String, String> columnData = new HashMap<String, String>();

		int headerColumnCount = driver.findElements((DetailedViewPage.columnBomHeaderDetailedView)).size();

		String getAriaHidden[] = new String[headerColumnCount];
		String getText[] = new String[headerColumnCount];

		for (int index = 0; index < (headerColumnCount); index++) {
			DetailedViewPage.setColumnBomHeaderDetails(index);
			getText[index] = ReusableMethods.getAttribute(DetailedViewPage.columnBomHeaders, "textContent");
			getAriaHidden[index] = ReusableMethods.getAttribute(DetailedViewPage.columnBomHeaders, "aria-hidden");
			columnData.put(getText[index], getAriaHidden[index]);
		}
		initializeColBomHeader(columnData);
		return columnData;
	}

	private static void initializeColBomHeader(HashMap<String, String> columnData) {
		if (columnData.get("BOM Name").equalsIgnoreCase("false") && columnData.get("Assigned To").equalsIgnoreCase("false")
				&& columnData.get("State").equalsIgnoreCase("false") && columnData.get("Partner").equalsIgnoreCase("false")
				&& columnData.get("BOM Category").equalsIgnoreCase("false") && columnData.get("Due Date").equalsIgnoreCase("false")
				&& columnData.get("Status").equalsIgnoreCase("false") && columnData.get("Tags").equalsIgnoreCase("false")) {

			if (columnData.get("Workstream").equalsIgnoreCase("false")) {
				DetailedViewPage.setWorkstreamProduct(5);
				DetailedViewPage.setBomCategory(6);
				DetailedViewPage.setBomName(7);
				DetailedViewPage.setAssignedTo(8);
				DetailedViewPage.setState(9);
				DetailedViewPage.setStatus(10);
				DetailedViewPage.setPartner(11);
				DetailedViewPage.setDueDate(12);
				DetailedViewPage.setTags(13);
			} else {
				DetailedViewPage.setBomCategory(5);
				DetailedViewPage.setBomName(6);
				DetailedViewPage.setAssignedTo(7);
				DetailedViewPage.setState(8);
				DetailedViewPage.setStatus(9);
				DetailedViewPage.setPartner(10);
				DetailedViewPage.setDueDate(11);
				DetailedViewPage.setTags(12);
			} 
		} else {
			test.log(LogStatus.INFO, "Bom Column is Missing, please verify the application");
		}
	}

	protected static HashMap<String,String> getDetailedViewColumnRiskHeader() {
		WebDriver driver = DriverManager.getWebDriver();
		HashMap<String, String> columnData = new HashMap<String, String>();

		int headerColumnCount = driver.findElements((DetailedViewPage.columnRiskHeaderDetailedView)).size();

		String getAriaHidden[] = new String[headerColumnCount];
		String getText[] = new String[headerColumnCount];

		for (int index = 0; index < (headerColumnCount); index++) {
			DetailedViewPage.setColumnBomHeaderDetails(index);
			getText[index] = ReusableMethods.getAttribute(DetailedViewPage.columnRiskHeaders, "textContent");
			getAriaHidden[index] = ReusableMethods.getAttribute(DetailedViewPage.columnRiskHeaders, "aria-hidden");
			columnData.put(getText[index], getAriaHidden[index]);
		}
		initializeColRiskHeader(columnData);
		return columnData;
	}

	private static void initializeColRiskHeader(HashMap<String, String> columnData) {
		if (columnData.get("Workstream").equalsIgnoreCase("false") && columnData.get("Applicable To").equalsIgnoreCase("false")
				&& columnData.get("Risk Name").equalsIgnoreCase("false") && columnData.get("Assigned To").equalsIgnoreCase("false")
				&& columnData.get("Status").equalsIgnoreCase("false") && columnData.get("Impact").equalsIgnoreCase("false")
				&& columnData.get("Initiate Date").equalsIgnoreCase("false") && columnData.get("Due Date").equalsIgnoreCase("false")) {

			if (columnData.get("Workstream").equalsIgnoreCase("false")) {
				DetailedViewPage.setRiskWorkstream(5);
				DetailedViewPage.setRiskApplicableTo(6);
				DetailedViewPage.setRiskRiskName(7);
				DetailedViewPage.setRiskAssignedTo(8);
				DetailedViewPage.setRiskStatus(9);
				DetailedViewPage.setRiskImpact(10);
				DetailedViewPage.setRiskInitiateDate(11);
				DetailedViewPage.setRiskDueDate(12);
			} else {
				DetailedViewPage.setRiskApplicableTo(6);
				DetailedViewPage.setRiskRiskName(7);
				DetailedViewPage.setRiskAssignedTo(8);
				DetailedViewPage.setRiskStatus(9);
				DetailedViewPage.setRiskImpact(10);
				DetailedViewPage.setRiskInitiateDate(11);
				DetailedViewPage.setRiskDueDate(12);
			}
		} else {
			test.log(LogStatus.INFO, "Risk Column is Missing, please verify the application");
		}
	}

	protected static void validateExistingBomHighlight(String workstream, DataTable bOMdata) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		ArrayList<String> getBomId = new ArrayList<String>();
		ArrayList<String> getRecentlyUpdatedBom = new ArrayList<String>();

		ArrayList<String> getWorkstreamProduct = new ArrayList<String>();
		ArrayList<String> getBomCategory = new ArrayList<String>();
		ArrayList<String> getBomName = new ArrayList<String>();
		ArrayList<String> getAssignedTo = new ArrayList<String>();
		ArrayList<String> getState = new ArrayList<String>();
		ArrayList<String> getStatus = new ArrayList<String>();
		ArrayList<String> getPartner = new ArrayList<String>();
		ArrayList<String> getDueDate = new ArrayList<String>();
		ArrayList<String> getTags = new ArrayList<String>();

		ArrayList<String> actWorkstreamProduct = new ArrayList<String>();
		ArrayList<String> actBomCategory = new ArrayList<String>();
		ArrayList<String> actBomName = new ArrayList<String>();
		ArrayList<String> actAssignedTo = new ArrayList<String>();
		ArrayList<String> actState = new ArrayList<String>();
		ArrayList<String> actStatus = new ArrayList<String>();
		ArrayList<String> actPartner = new ArrayList<String>();
		ArrayList<String> actDueDate = new ArrayList<String>();
		ArrayList<String> actTags = new ArrayList<String>();

		int tableSize = driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]"
				+ "/table/tbody/tr")).size();
		System.out.println(tableSize);
		for (int i = 1; i<=tableSize; i++) {
			DetailedViewPage.setBomData(i);
			getBomId.add(ReusableMethods.getAttribute(DetailedViewPage.getBomId, "id"));
			getWorkstreamProduct.add(ReusableMethods.getAttribute(DetailedViewPage.getWorkstreamProduct, "title"));
			getBomCategory.add(ReusableMethods.getAttribute(DetailedViewPage.getBomCategory, "title"));
			getBomName.add(ReusableMethods.getAttribute(DetailedViewPage.getBomName, "title"));
			getAssignedTo.add(ReusableMethods.getAttribute(DetailedViewPage.getAssignedTo, "title"));
			getState.add(ReusableMethods.getAttribute(DetailedViewPage.getState, "title"));
			getStatus.add(ReusableMethods.getAttribute(DetailedViewPage.getStatus, "title"));
			getPartner.add(ReusableMethods.getAttribute(DetailedViewPage.getPartner, "title"));
			getDueDate.add(ReusableMethods.getAttribute(DetailedViewPage.getDueDate, "title"));
			getTags.add(ReusableMethods.getAttribute(DetailedViewPage.getTags, "title"));
		}

		BOMStepDefs.editBOM(workstream, bOMdata);

		int size = driver.findElements(By.xpath(DetailedViewPage.bomRecentlyUpdated)).size();
		if (size!=0) {
			for (int index = 1; index<=size; index++) {
				getRecentlyUpdatedBom.add(ReusableMethods.getAttribute(
						DetailedViewPage.bomRecentlyUpdated + "[" + index + "]", "id"));
			}
		}

		for (int i = 0; i<getRecentlyUpdatedBom.size(); i++) {
			DetailedViewPage.actBomData(getRecentlyUpdatedBom.get(i));
			actWorkstreamProduct.add(ReusableMethods.getAttribute(DetailedViewPage.actWorkstreamProduct, "title"));
			actBomCategory.add(ReusableMethods.getAttribute(DetailedViewPage.actBomCategory, "title"));
			actBomName.add(ReusableMethods.getAttribute(DetailedViewPage.actBomName, "title"));
			actAssignedTo.add(ReusableMethods.getAttribute(DetailedViewPage.actAssignedTo, "title"));
			actState.add(ReusableMethods.getAttribute(DetailedViewPage.actState, "title"));
			actStatus.add(ReusableMethods.getAttribute(DetailedViewPage.actStatus, "title"));
			actPartner.add(ReusableMethods.getAttribute(DetailedViewPage.actPartner, "title"));
			actDueDate.add(ReusableMethods.getAttribute(DetailedViewPage.actDueDate, "title"));
			actTags.add(ReusableMethods.getAttribute(DetailedViewPage.actTags, "title"));
		}

		for (int checkPoint = 0; checkPoint < getRecentlyUpdatedBom.size(); checkPoint++) {
			for (int chk = 0; chk < getBomId.size(); chk++) {
				if (getRecentlyUpdatedBom.get(checkPoint).equals(getBomId.get(chk))) {
					ReusableMethods.softAssertverify(actWorkstreamProduct.get(checkPoint), getWorkstreamProduct.get(chk));
					ReusableMethods.softAssertverify(actBomCategory.get(checkPoint), getBomCategory.get(chk));
					ReusableMethods.softAssertverify(actBomName.get(checkPoint), getBomName.get(chk));
					ReusableMethods.softAssertverify(actAssignedTo.get(checkPoint), getAssignedTo.get(chk));
					ReusableMethods.softAssertverify(actState.get(checkPoint), getState.get(chk));
					ReusableMethods.softAssertverify(actStatus.get(checkPoint), getStatus.get(chk));
					ReusableMethods.softAssertverify(actPartner.get(checkPoint), getPartner.get(chk));
					ReusableMethods.softAssertverify(actDueDate.get(checkPoint), getDueDate.get(chk));
					ReusableMethods.softAssertverify(actTags.get(checkPoint), getTags.get(chk));
				}
			}
		}
	}
}