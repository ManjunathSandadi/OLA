package supportLibraries;

import org.openqa.selenium.WebDriver;
import org.apache.log4j.Logger;

/**
 * DriverFactory which will create respective driver Object
 * 
 * @author Venkatesh Jayam
 */
public class DriverFactory {

	static Logger log = Logger.getLogger(DriverFactory.class);

	public static WebDriver createInstanceWebDriver(SeleniumTestParameters testParameters) {
		WebDriver driver = null;
		try {
			switch (testParameters.getExecutionMode()) {

			case LOCAL:
				driver = WebDriverFactory.getWebDriver(testParameters.getBrowser());
				break;

			default:
				throw new Exception("Unhandled Execution Mode!");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			log.error(ex.getMessage());
		}
		return driver;
	}
}