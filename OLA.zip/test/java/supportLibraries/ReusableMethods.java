package supportLibraries;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

public class ReusableMethods extends ExtentReportClass {

	private static long explicitTimeOutInSeconds = 60;
	private static long implicitTimeOutInSeconds = 5;
	private static SoftAssert softassert = new SoftAssert();

	/**
	 * Function to check the input is valid
	 * 
	 * @param value
	 * 
	 * @return boolean
	 */
	public static boolean checkPreRequistes(String value) {
		boolean chk = false;
		if (value != null) {
			if (!value.isEmpty()) {
				if (!value.isBlank()) {
					if (!value.equals("")) {
						chk = true;
					}
				}
			}
		}
		return chk;
	}
	/**
	 * Function to wait until the specified element is visible
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param explicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void waitUntilElementVisible(By element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			(new WebDriverWait(driver, Duration.ofSeconds(explicitTimeOutInSeconds))).until(ExpectedConditions
					.visibilityOfElementLocated(element));
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);

			test.log(LogStatus.PASS, "Waiting Until the Element is Visible " + getText(element));
		} catch(Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Waiting Until the Element is NOT Visible " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to wait until the specified element is visible
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param explicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void waitUntilElementVisible(String element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			(new WebDriverWait(driver, Duration.ofSeconds(explicitTimeOutInSeconds))).until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath(element)));
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);

			test.log(LogStatus.PASS, "Waiting Until the Element is Visible " + getText(element));
		} catch(Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Waiting Until the Element is NOT Visible " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to wait until the specified element is enabled
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param explicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void waitUntilElementEnabled(By element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			(new WebDriverWait(driver, Duration.ofSeconds(explicitTimeOutInSeconds))).until(ExpectedConditions
					.elementToBeClickable(element));
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);

			test.log(LogStatus.PASS, "Waiting Until the Element is Enabled " + getText(element));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Waiting Until the Element is NOT Enabled " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to wait until the specified element is enabled
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param explicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void waitUntilElementEnabled(String element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			(new WebDriverWait(driver, Duration.ofSeconds(explicitTimeOutInSeconds))).until(ExpectedConditions
					.elementToBeClickable(By.xpath(element)));
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);

			test.log(LogStatus.PASS, "Waiting Until the Element is Enabled " + getText(element));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Waiting Until the Element is NOT Enabled " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to wait until the specified element is disabled
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param explicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	public static void waitUntilElementDisabled(By element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			(new WebDriverWait(driver, Duration.ofSeconds(explicitTimeOutInSeconds))).until(ExpectedConditions
					.not(ExpectedConditions.elementToBeClickable(element)));

			test.log(LogStatus.PASS, "Waited Until the Element is Disabled " + element.toString(), 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.WARNING, "Waited Until the Element is NOT Disabled " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to wait until the specified element is disabled
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param explicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	public static void waitUntilElementDisabled(String element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			(new WebDriverWait(driver, Duration.ofSeconds(explicitTimeOutInSeconds))).until(ExpectedConditions
					.not(ExpectedConditions.elementToBeClickable(By.xpath(element))));

			test.log(LogStatus.PASS, "Waited Until the Element is Disabled " + element.toString(), 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.WARNING, "Waited Until the Element is NOT Disabled " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to enter data to the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void enterData(By element, String value) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			if (checkPreRequistes(value)) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.findElement(element).clear();
				driver.findElement(element).click();
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				driver.findElement(element).sendKeys(value);
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				driver.findElement(element).sendKeys(Keys.TAB);	

				test.log(LogStatus.PASS, "Entered the data in the WebElement " + getText(element) + 
						" with the value: " + value, test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.WARNING, "NOT Entered the data in the WebElement " + e.getMessage() + 
					" with the value: " + value, test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to enter data to the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void enterData(String element, String value) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			if (checkPreRequistes(value)) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.findElement(By.xpath(element)).clear();
				driver.findElement(By.xpath(element)).click();
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				driver.findElement(By.xpath(element)).sendKeys(value);
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				driver.findElement(By.xpath(element)).sendKeys(Keys.TAB);	

				test.log(LogStatus.PASS, "Entered the data in the WebElement " + getText(element) + 
						" with the value: " + value, test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.WARNING, "NOT Entered the data in the WebElement " + e.getMessage() + 
					" with the value: " + value, test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to enter data to the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void enterDataWthoutTab(By element, String value) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			if (checkPreRequistes(value)) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.findElement(element).clear();
				driver.findElement(element).click();
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				driver.findElement(element).sendKeys(value);

				test.log(LogStatus.PASS, "Entered the data in the WebElement " + getText(element), 
						test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			//test.log(LogStatus.WARNING, "NOT Entered the data in the WebElement " + e.getMessage(), 
			//		test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to enter data to the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void enterDataWthoutTab(String element, String value) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			if (checkPreRequistes(value)) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.findElement(By.xpath(element)).clear();
				driver.findElement(By.xpath(element)).click();
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				driver.findElement(By.xpath(element)).sendKeys(value);

				test.log(LogStatus.PASS, "Entered the data in the WebElement " + getText(element), 
						test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			//test.log(LogStatus.WARNING, "NOT Entered the data in the WebElement " + e.getMessage(), 
			//		test.addScreenCapture(capture(driver)));
		}
	}
	
	/**
	 * Function to enter data to the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void enterDataWthoutTabProp(By element, String value) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			if (checkPreRequistes(value)) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.findElement(element).clear();
				driver.findElement(element).click();
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				driver.findElement(element).sendKeys(value);
				Thread.sleep(5000);
				driver.findElement(element).sendKeys(Keys.TAB);					
				
				test.log(LogStatus.PASS, "Entered the data in the WebElement " + getText(element), 
						test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			//test.log(LogStatus.WARNING, "NOT Entered the data in the WebElement " + e.getMessage(), 
			//		test.addScreenCapture(capture(driver)));
		}
	}


	/**
	 * Function to Highlight the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void highlight(By element) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement Wb = driver.findElement(element);
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", Wb, " outline: #f00 solid 2px;");

			test.log(LogStatus.INFO, "Highlighted the WebElement " + getText(element), 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "NOT Highlighted the WebElement " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to Highlight the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void highlight(String element) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement Wb = driver.findElement(By.xpath(element));
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", Wb, " outline: #f00 solid 2px;");

			test.log(LogStatus.INFO, "Highlighted the WebElement " + getText(element), 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "NOT Highlighted the WebElement " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to Click the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void click(By element) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
			scrollToview(element);
			highlight(element);
			test.log(LogStatus.PASS, "Clicked the WebElement " + getText(element), 
					test.addScreenCapture(capture(driver)));
			driver.findElement(element).click();
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "NOT Clicked the WebElement " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to Click the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void click(String element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			if (driver.findElement(By.xpath(element)).isDisplayed()) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				scrollToview(element);
				highlight(element);
				test.log(LogStatus.PASS, "Clicked the WebElement " + getText(element), 
						test.addScreenCapture(capture(driver)));
				driver.findElement(By.xpath(element)).click();
			}
		} catch(Exception e) {
			test.log(LogStatus.INFO, "NOT Clicked the WebElement " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to Click the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void clickWithoutScreenshot(By element) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
			scrollToview(element);
			highlight(element);
			test.log(LogStatus.PASS, "Clicked the WebElement " + getText(element));
			driver.findElement(element).click();
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "NOT Clicked the WebElement " + e.getMessage());
		}
	}

	/**
	 * Function to Click the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void clickWithoutScreenshot(String element) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
			scrollToview(element);
			highlight(element);
			test.log(LogStatus.PASS, "Clicked the WebElement " + getText(element));
			driver.findElement(By.xpath(element)).click();
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "NOT Clicked the WebElement " + e.getMessage());
		}
	}

	/**
	 * Function to Click the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void clickJS(By element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			waitUntilElementVisible(element);
			waitUntilElementEnabled(element);
			driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
			JavascriptExecutor js=(JavascriptExecutor) driver;
			//js.executeScript("arguments[0].scrollIntoView(true);", element);
			test.log(LogStatus.PASS, "Clicked the WebElement " + getText(element), 
					test.addScreenCapture(capture(driver)));
			js.executeScript("arguments[0].click();", driver.findElement(element));
		} catch(Exception e) {
			test.log(LogStatus.WARNING, "NOT Clicked the WebElement " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}		
	}

	/**
	 * Function to Click the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static void clickJS(String element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			if (driver.findElement(By.xpath(element)).isDisplayed()) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				JavascriptExecutor js=(JavascriptExecutor) driver;
				//js.executeScript("arguments[0].scrollIntoView(true);", element);
				test.log(LogStatus.PASS, "Clicked the WebElement " + getText(element), 
						test.addScreenCapture(capture(driver)));
				js.executeScript("arguments[0].click();", driver.findElement(By.xpath(element)));
			}
		} catch(Exception e) {
			test.log(LogStatus.WARNING, "NOT Clicked the WebElement " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}		
	}

	/**
	 * Function to Select the Value in the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param value
	 *            The {@link WebDriver} value to select in the drop down list
	 * @throws IOException
	 */
	public static void selectDataByVisibleText(By element, String value) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		if (checkPreRequistes(value)) {
			try {
				if (driver.findElement(element).isDisplayed()) {
					waitUntilElementVisible(element);
					waitUntilElementEnabled(element);
					Select select=new Select(driver.findElement(element));
					select.selectByVisibleText(value);
					test.log(LogStatus.PASS, "Selected the drop down value in the selected the WebElement " + select.getFirstSelectedOption(), 
							test.addScreenCapture(capture(driver)));
				}
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "NOT Selected the drop down value in the selected the WebElement " + e.getMessage(), 
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	/**
	 * Function to Select the Value in the specified element
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param value
	 *            The {@link WebDriver} value to select in the drop down list
	 * @throws IOException
	 */
	public static void selectDataByVisibleText(String element, String value) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		if (checkPreRequistes(value)) {
			try {
				if (driver.findElement(By.xpath(element)).isDisplayed()) {
					waitUntilElementVisible(element);
					waitUntilElementEnabled(element);
					Select select=new Select(driver.findElement(By.xpath(element)));
					select.selectByVisibleText(value);
					test.log(LogStatus.PASS, "Selected the drop down value in the selected the WebElement " + select.getFirstSelectedOption());
				}
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "NOT Selected the drop down value in the selected the WebElement " + e.getMessage(), 
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	/**
	 * Function to Wait for the DOM objects using JS Executor
	 */
	private static void waitForLoad() {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			new WebDriverWait(driver,Duration.ofSeconds(explicitTimeOutInSeconds)).until(webDriver -> ((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState").equals("complete"));
			test.log(LogStatus.INFO, "DOM Objects loaded Successfully");
		} catch (Throwable e) {
			test.log(LogStatus.WARNING, "DOM Objects NOT loaded Successfully: " + e);
		}
	}

	/**
	 * Function to Soft Assert the messages
	 * 
	 * @param actual_message
	 *            The actual message needs to be verified; Retrieved from the Application
	 * @param expected_message
	 *            The expected message that needs to be verified; Provided by the User
	 * @throws IOException 
	 */
	public static void softAssertverification(String actual_message, String expected_message) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			softassert.assertEquals(actual_message, expected_message,"Message validation completed succesfully");
			test.log(LogStatus.PASS, "Message validation is Successful, Actual Message: " + actual_message +
					" ;Expected Message: " + expected_message, test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Message validation is NOT Successful, Actual Message: " + actual_message +
					" ;Expected Message: " + expected_message, test.addScreenCapture(capture(driver)));
		}
	}
	
	/**
	 * Function to Soft Assert the messages
	 * 
	 * @param actual_message
	 *            The actual message needs to be verified; Retrieved from the Application
	 * @param expected_message
	 *            The expected message that needs to be verified; Provided by the User
	 * @throws IOException 
	 */
	public static void softAssertverify(String actual_message, String expected_message) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			softassert.assertEquals(actual_message, expected_message, "Validation Completed Succesfully");
			test.log(LogStatus.PASS, "Message validation is Successful, Actual Message: " + actual_message +
					" ;Expected Message: " + expected_message, test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Message Validation is NOT Successful, Actual Message: " + actual_message +
					" ;Expected Message: " + expected_message, test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to Soft Assert the messages
	 * 
	 * @param actual_message
	 *            The actual message needs to be verified; Retrieved from the Application
	 * @param expected_message
	 *            The expected message that needs to be verified; Provided by the User
	 * @throws IOException 
	 */
	public static void softAssertverification(List<String> actual_message, List<String> expected_message) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			softassert.assertEquals(actual_message, expected_message,"Message validation completed succesfully");
			test.log(LogStatus.PASS, "Message validation is Successful, Actual Message: " + actual_message +
					" ;Expected Message: " + expected_message, test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Message validation is NOT Successful, Actual Message: " + actual_message +
					" ;Expected Message: " + expected_message, test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to Soft Assert the messages
	 * 
	 * @param actual_message
	 *            The actual message needs to be verified; Retrieved from the Application
	 * @param expected_message
	 *            The expected message that needs to be verified; Provided by the User
	 * @throws IOException 
	 */
	public static void softAssertverification(String[] actual_message, String[] expected_message) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			softassert.assertEquals(actual_message, expected_message,"Message validation completed succesfully");
			test.log(LogStatus.PASS, "Message validation is Successful, Actual Message: " + actual_message +
					" ;Expected Message: " + expected_message, test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Message validation is NOT Successful, Actual Message: " + actual_message +
					" ;Expected Message: " + expected_message, test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to Soft Assert the messages
	 * 
	 * @param actual_message
	 *            The actual message needs to be verified; Retrieved from the Application
	 * @param expected_message
	 *            The expected message that needs to be verified; Provided by the User
	 * @throws IOException 
	 */
	public static void softAssertverification(boolean actual_status, boolean expected_status) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			softassert.assertEquals(actual_status, expected_status,"Message validation completed succesfully");
			test.log(LogStatus.PASS, "Message validation is Successful, Actual Message: " + actual_status +
					" ;Expected Message: " + expected_status, test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Message validation is NOT Successful, Actual Message: " + actual_status +
					" ;Expected Message: " + expected_status, test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to Soft Assert the messages
	 * 
	 * @param actual_message
	 *            The actual message needs to be verified; Retrieved from the Application
	 * @param expected_message
	 *            The expected message that needs to be verified; Provided by the User
	 * @throws IOException 
	 */
	public static void softAssertverification(long actual, long expected) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			softassert.assertEquals(actual, expected,"Message validation completed succesfully");
			test.log(LogStatus.PASS, "Message validation is Successful, Actual Message: " + actual +
					" ;Expected Message: " + expected, test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Message validation is NOT Successful, Actual Message: " + actual +
					" ;Expected Message: " + expected, test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to scroll to the Web Element using Action Class
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @throws IOException 
	 */
	public static void scrollToview(By element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(element));
			test.log(LogStatus.INFO, "Scroll into WebElement view: " + getText(element), 
					test.addScreenCapture(capture(driver)));
			actions.perform();
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "NOT Scroll into WebElement view: " + element.toString(), 
					test.addScreenCapture(capture(driver)));
			e.printStackTrace();
		}
	}

	/**
	 * Function to scroll to the Web Element using Action Class
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @throws IOException 
	 */
	public static void scrollToview(String element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(By.xpath(element)));
			test.log(LogStatus.INFO, "Scroll into WebElement view: " + getText(element), 
					test.addScreenCapture(capture(driver)));
			actions.perform();
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "NOT Scroll into WebElement view: " + element.toString(), 
					test.addScreenCapture(capture(driver)));
			e.printStackTrace();
		}
	}

	/**
	 * Function to Click the specified element (Checkbox)
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param implicitTimeOutInSeconds
	 *            The wait timeout in seconds
	 * @throws IOException
	 */

	@SuppressWarnings("deprecation")
	public static void selectCheckbox(By element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			if (!driver.findElement(element).isSelected()) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.manage().timeouts().implicitlyWait(implicitTimeOutInSeconds,TimeUnit.SECONDS);
				driver.findElement(element).click();
				test.log(LogStatus.PASS, "Clicked the WebElement " + getText(element), 
						test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "NOT Clicked the WebElement " + getText(element), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to retrieve the text of the WebElement
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @return
	 *            The {@link WebDriver} locator text value used to retrieve in the element
	 * @throws IOException 
	 */
	public static String getText(By element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		test.log(LogStatus.PASS, "Text value of the WebElement: " + element.toString(), 
				test.addScreenCapture(capture(driver)));
		return driver.findElement(element).getText().trim();
	}

	/**
	 * Function to retrieve the text of the WebElement
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @return
	 *            The {@link WebDriver} locator text value used to retrieve in the element
	 * @throws IOException 
	 */
	public static String getText(String element) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		test.log(LogStatus.PASS, "Text value of the WebElement: " + element.toString(), 
				test.addScreenCapture(capture(driver)));
		return driver.findElement(By.xpath(element)).getText().trim();
	}

	/**
	 * Function to verify existence of the WebElement
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param value
	 * 			  The boolean value
	 * @param field
	 * 			  The locator needs to be verified whether present in the application
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public static void isElementExists(By element, boolean value, String field) 
			throws IOException, InterruptedException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		if(value==true) {
			try {
				if(driver.findElement(element).isDisplayed()) {
					test.log(LogStatus.PASS, "Element = " + field + " exists in UI which is expected", 
							test.addScreenCapture(capture(driver)));
				}	
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "Element = " + field + " NOT exists in UI which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		} else {
			try {
				if(!driver.findElement(element).isDisplayed()) {
					test.log(LogStatus.PASS, "Element = " + field + " exists in UI which is expected", 
							test.addScreenCapture(capture(driver)));
				}	
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "Element = " + field + " NOT exists in UI which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	/**
	 * Function to verify existence of the WebElement
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param value
	 * 			  The boolean value
	 * @param field
	 * 			  The locator needs to be verified whether present in the application
	 * @throws IOException 
	 */
	public static void isElementExists(String element, boolean value, String field) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		if(value==true) {
			try {
				if(driver.findElement(By.xpath(element)).isDisplayed()) {
					test.log(LogStatus.PASS, "Element = " + field + " exists in UI which is expected", 
							test.addScreenCapture(capture(driver)));
				}	
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "Element = " + field + " NOT exists in UI which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		} else {
			try {
				if(!driver.findElement(By.xpath(element)).isDisplayed()) {
					test.log(LogStatus.PASS, "Element = " + field + " exists in UI which is expected", 
							test.addScreenCapture(capture(driver)));
				}	
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "Element = " + field + " NOT exists in UI which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	/**
	 * Function to verify existence of the WebElement
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param value
	 * 			  The boolean value
	 * @param field
	 * 			  The locator needs to be verified whether present in the application
	 * @throws IOException 
	 */
	public static void isElementEnabled(By element, boolean value, String field) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		if(value==true) {
			try {
				if(driver.findElement(element).isEnabled()) {
					test.log(LogStatus.PASS, "Element = " + field + " exists in UI which is expected", 
							test.addScreenCapture(capture(driver)));
				}	
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "Element = " + field + " NOT exists in UI which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		} else {
			try {
				if(!driver.findElement(element).isEnabled()) {
					test.log(LogStatus.PASS, "Element = " + field + " exists in UI which is expected", 
							test.addScreenCapture(capture(driver)));
				}	
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "Element = " + field + " NOT exists in UI which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	/**
	 * Function to verify existence of the WebElement
	 * 
	 * @param element
	 *            The {@link WebDriver} locator used to identify the element
	 * @param value
	 * 			  The boolean value
	 * @param field
	 * 			  The locator needs to be verified whether present in the application
	 * @throws IOException 
	 */
	public static void isElementEnabled(String element, boolean value, String field) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		if(value==true) {
			try {
				if(driver.findElement(By.xpath(element)).isEnabled()) {
					test.log(LogStatus.PASS, "Element = " + field + " exists in UI which is expected", 
							test.addScreenCapture(capture(driver)));
				}	
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "Element = " + field + " NOT exists in UI which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		} else {
			try {
				if(!driver.findElement(By.xpath(element)).isEnabled()) {
					test.log(LogStatus.PASS, "Element = " + field + " exists in UI which is expected", 
							test.addScreenCapture(capture(driver)));
				}	
			} catch (Exception e) {
				test.log(LogStatus.WARNING, "Element = " + field + " NOT exists in UI which is NOT expected", 
						test.addScreenCapture(capture(driver)));
			}
		}
	}

	/**
	 * Function to retrieve the String value of the double with 2 decimal values
	 * 
	 * @param value
	 * 			  The double value needs to returned with 2 decimal values
	 * @throws IOException 
	 */
	public static String two_decimal_places(double value) throws IOException {
		DecimalFormat df = new DecimalFormat("0.00");
		test.log(LogStatus.INFO, "Decimal value of the WebElement: " + df.format(value));
		return df.format(value);
	}

	/**
	 * Function to sendKeys the value in the WebElement
	 * 
	 * @param element
	 * 			  The {@link WebDriver} locator used to identify the element
	 * @param value
	 * 			  The value need to be entered in the WebElement
	 * @throws IOException 
	 */
	public static void sendKeys(By element, String value) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			if (checkPreRequistes(value)) {
				waitUntilElementVisible(element);
				waitUntilElementEnabled(element);
				driver.findElement(element).sendKeys(value);
				test.log(LogStatus.PASS, "Entered the data in the WebElement " + getText(element) + 
						" with the value: " + value, test.addScreenCapture(capture(driver)));
			}
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "NOT Entered the data in the WebElement " + e.getMessage() + 
					" with the value: " + value, test.addScreenCapture(capture(driver)));
		}
	}

	public static int getElementsSize(String element) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.INFO, "WebElement Size: " + driver.findElements(By.xpath(element)).size());
		} catch (Exception e) {
			test.log(LogStatus.ERROR, "WebElement Size: " + driver.findElements(By.xpath(element)).size());
		}
		return driver.findElements(By.xpath(element)).size();
	}

	public static int getElementsSize(By element) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.INFO, "WebElement Size: " + driver.findElements((element)).size());
		} catch (Exception e) {
			test.log(LogStatus.ERROR, "WebElement Size: " + driver.findElements((element)).size());
		}
		return driver.findElements((element)).size();
	}

	public static boolean isDisplayed(By element) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.INFO, "WebElement is Displayed: " + driver.findElement(element).isDisplayed());
		} catch (Exception e) {
			test.log(LogStatus.ERROR, "WebElement is NOT Displayed: " + driver.findElement(element).isDisplayed());
		}
		return driver.findElement(element).isDisplayed();
	}

	public static boolean isDisplayed(String element) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.INFO, "WebElement is Displayed: " + driver.findElement(By.xpath(element)).isDisplayed());
		} catch (Exception e) {
			test.log(LogStatus.ERROR, "WebElement is NOT Displayed: " + driver.findElement(By.xpath(element)).isDisplayed());
		}
		return driver.findElement(By.xpath(element)).isDisplayed();
	}

	public static boolean isDisplay(By element) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.PASS, "WebElement is Displayed: " + (driver.findElements(element).size()!=0));
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "WebElement is NOT Displayed: " + (driver.findElements(element).size()!=0));
		}
		return driver.findElements(element).size()!=0;
	}

	public static boolean isDisplay(String element) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.PASS, "WebElement is Displayed: " + (driver.findElements(By.xpath(element)).size()!=0));
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "WebElement is NOT Displayed: " + (driver.findElements(By.xpath(element)).size()!=0));
		}
		return driver.findElements(By.xpath(element)).size()!=0;
	}

	public static boolean isNotDisplay(By element) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.PASS, "WebElement is Displayed: " + (driver.findElements(element).size()==0));
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "WebElement is NOT Displayed: " + (driver.findElements(element).size()==0));
		}
		return driver.findElements(element).size()==0;
	}

	public static boolean isNotDisplay(String element) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.PASS, "WebElement is Displayed: " + (driver.findElements(By.xpath(element)).size()==0));
		} catch (Exception e) {
			test.log(LogStatus.WARNING, "WebElement is NOT Displayed: " + (driver.findElements(By.xpath(element)).size()==0));
		}
		return driver.findElements(By.xpath(element)).size()==0;
	}

	public static String getAttribute(By element, String attribute) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.INFO, "WebElement is Attribute Value is: " + (driver.findElement((element)).getAttribute(attribute).trim()));
		} catch (Exception e) {
			test.log(LogStatus.ERROR, "WebElement is NOT Displayed: " + (driver.findElement((element)).getAttribute(attribute).trim()));
		}
		return driver.findElement((element)).getAttribute(attribute).trim();
	}

	public static String getAttribute(String element, String attribute) {
		WebDriver driver = DriverManager.getWebDriver();
		waitForLoad();
		try {
			test.log(LogStatus.INFO, "WebElement is Attribute Value is: " + (driver.findElement(By.xpath(element)).getAttribute(attribute).trim()));
		} catch (Exception e) {
			test.log(LogStatus.ERROR, "WebElement is NOT Displayed: " + (driver.findElement(By.xpath(element)).getAttribute(attribute).trim()));
		}
		return driver.findElement(By.xpath(element)).getAttribute(attribute).trim();
	}

	public static double round(double value, int places) {
		if (places < 0) throw new IllegalArgumentException();

		long factor = (long) Math.pow(10, places);
		value = value * factor;
		long tmp = Math.round(value);
		test.log(LogStatus.INFO, "Round Value is: " + (double) tmp / factor);
		return (double) tmp / factor;
	}

	public static void rawWait(int value) throws InterruptedException {
		Thread.sleep(value*1000);
		test.log(LogStatus.INFO, "Execution is waited for " + value + " seconds");
	}
}