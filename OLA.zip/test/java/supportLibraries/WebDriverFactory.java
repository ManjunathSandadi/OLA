package supportLibraries;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Factory class for creating the {@link WebDriver} object as required
 * 
 * @author Venkatesh Jayam
 */
public class WebDriverFactory {

	private static Properties properties;
	static Logger log = Logger.getLogger(WebDriverFactory.class);

	private WebDriverFactory() {

	}

	/**
	 * Function to return the appropriate {@link WebDriver} object based on the
	 * parameters passed
	 * 
	 * @param browser
	 *            The {@link Browser} to be used for the test execution
	 * @return The corresponding {@link WebDriver} object
	 */
	public static WebDriver getWebDriver(Browser browser) {
		WebDriver driver = null;
		properties = Settings.getInstance();
		try {
			switch (browser) {
			case CHROME:
				// Takes the system proxy settings automatically
				//WebDriverManager.chromedriver().setup();

				System.setProperty("webdriver.chrome.driver", properties.getProperty("ChromeDriverPath"));
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--remote-allow-origins=*");

				driver = new ChromeDriver(options);
				driver.manage().window().maximize();
				break;

			case FIREFOX:
				driver = new FirefoxDriver();
				break;

			default:
				throw new Exception("Unhandled browser!");
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
			ex.printStackTrace();
		}

		return driver;
	}
}