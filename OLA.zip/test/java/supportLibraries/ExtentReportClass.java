package supportLibraries;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.testng.annotations.*;

import com.relevantcodes.extentreports.*;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class ExtentReportClass {
	
	public static ExtentTest test;
	public static ExtentReports report;
	//private static Properties properties = Settings.getInstance();

	private static String reportPathFolder = System.getProperty("user.dir") + System.getProperty("file.separator") + 
			"Extent Report Results" + System.getProperty("file.separator") + getTodayDateTime();

	private static String reportPathFile = "OLA_ExtentReportResults_" + "Run_" + getTodayDateTime();

	@BeforeClass
	public void startTest() {
		mkdirectory(reportPathFolder);
		report = new ExtentReports(reportPathFolder + System.getProperty("file.separator") + 
				reportPathFile + ".html");
	}

	@AfterClass
	public void endTest() {
		atEndTest();
	}

	private void atEndTest() {
		report.endTest(test);
		report.flush();
	}

	public static String capture(WebDriver driver) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File(reportPathFolder + System.getProperty("file.separator") + "Screenshots/" + 
				System.currentTimeMillis() + ".jpg");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		
		Screenshot screenshot = new AShot().shootingStrategy(
				ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
		ImageIO.write(screenshot.getImage(), "jpg", new File("c:\\Driver\\ElementScreenshot.jpg"));
		
		return errflpath;
	}

	public static String getTodayDateTime() {
		DateFormat df = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss");
		Calendar calobj = Calendar.getInstance();

		return df.format(calobj.getTime());
	}

	public void mkdirectory(String reportPathFolder) {
		File theDir = new File(reportPathFolder);
		if (!theDir.exists()){
			theDir.mkdirs();
		}
	}
}