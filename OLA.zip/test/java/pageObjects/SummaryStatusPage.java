package pageObjects;

import org.openqa.selenium.By;

public class SummaryStatusPage {
	public static String worktream_completed_data
	,workStream
	,workStream_attachment;

	public static final By completion_percentage = By.xpath("//div[@class='media-object']/h1");
	public static final By edit = By.xpath("//div[@class='btnContainerFooter']//button[@id='edit_btn']");
	public static final By save = By.xpath("//div[@class='btnContainerFooter']//button[@id='save_btn']");
	public static final By submit = By.xpath("//div[@class='btnContainerFooter']//button[@id='submit_btn']");
	public static final By cancel = By.xpath("//div[@class='btnContainerFooter']//button[@id='cancel_btn']");
	public static final By status = By.xpath("//button[@class='form-control dropdown-toggle ng-binding']");
	public static final By Summary_Status_Table=By.xpath("//div[@class='col-lg-12 table-row ng-scope']");
	public static final By Risk_Status_Table=By.xpath("//*[@id='jsSummaryStatusView']/div[1]/div[3]/div[2]/div/div/div/div/div[3]/table/tbody");
	public static final By none=By.xpath("//button[@class='form-control dropdown-toggle ng-binding']/..//li[contains(text(),'none')]");
	public static final By on_track=By.xpath("//button[@class='form-control dropdown-toggle ng-binding']/..//li[contains(text(),'On Track')]");
	public static final By risk=By.xpath("//button[@class='form-control dropdown-toggle ng-binding']/..//li[contains(text(),'Risk')]");
	public static final By critical=By.xpath("//button[@class='form-control dropdown-toggle ng-binding']/..//li[contains(text(),'Critical')]");
	public static final By scorecard_expand_collapse_button=By.xpath("//button[@ng-click=\"c.onChangeSectionView('scorecard-summary')\"]");	
	public static final By productsummary_expand_collapse_button=By.xpath("//button[@ng-click=\"c.onChangeSectionView('summary-status')\"]");
	public static final By risksummary_expand_collapse_button=By.xpath("//button[@ng-click=\"c.onChangeSectionView('risk-summary')\"]");
	public static final By scorecard_summary_content_box=By.xpath("(//div[@class='whiteBox ng-scope']//textarea)[1]");
	public static final By scorecard_summary_ready_test=By.xpath("(//div[@class='whiteBox ng-scope']//textarea)[4]");

	public static void setWorkstream(String workstream) {
		worktream_completed_data="(//*[@id='"+workstream+"']/..//p)[2]";
		workStream="(//h5[text()='"+workstream+"']/../..)[2]";
		workStream_attachment="(//h5[text()='"+workstream+"']/../..)[2]//a";	
	}

	public static String summary_bom_cat_values=("(//*[@id='jsSummaryStatusView']//div[@class='col-lg-12 table-row ng-scope']//div[@class='col-lg-4 table-row-content-default ng-binding'])");
	public static String summary_bom_cat_progressbar=("(//*[@id='jsSummaryStatusView']//div[@class='col-lg-12 table-row ng-scope']//div[@class='col-lg-4 table-row-content-default ng-binding']/..//div[@class='progress customProgress'])");
	public static String summary_bom_cat_percentage="(//*[@id='jsSummaryStatusView']//div[@class='col-lg-12 table-row ng-scope']//div[@class='col-lg-4 table-row-content-default ng-binding']/..//div[@class='ng-binding'])";
	public static String summary_bom_cat_color="(//*[@id='jsSummaryStatusView']//div[@class='col-lg-12 table-row ng-scope']//div[@class='col-lg-4 table-row-content-default ng-binding']/..//div[@class='dotClass']/div[2])";
	public static String summary_bom_cat_comments="(//*[@id='jsSummaryStatusView']//div[@class='col-lg-12 table-row ng-scope']//textarea)";
	public static String scorecardSummaryRiskState = "(//*[@id='jsSummaryStatusView']/div[1]/div[3]/div[2]//table/tbody//td[6])";
}