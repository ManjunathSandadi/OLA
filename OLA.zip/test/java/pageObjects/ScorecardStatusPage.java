package pageObjects;

import org.openqa.selenium.By;

public class ScorecardStatusPage {
	
	public static String scorecard_icon;
	
	public static final By calendar = By.xpath("//button[@title='Calendar']");
	public static final By download = By.xpath("//button[@title='Download']");
	public static final By date = By.xpath("//input[@id='dateSelect']");
	public static final By clear = By.xpath("//button[@class='btn btn-outline clrRed']");
	public static final By apply=By.xpath("//*[@id='dateFilterScoreCardModal']//button[contains(text(),'Apply')]");
	public static final By highlight_changes_since=By.xpath("//b[contains(text(),'Highlight Changes Since')]");
	public static final By product_name_scorecard=By.xpath("(//div[@class='row scodecard-header-container ng-scope']//span)[1]");
	public static final By approver_name_scorecard=By.xpath("(//div[@class='row scodecard-header-container ng-scope']//span)[2]");
	public static final By status_scorecard=By.xpath("(//div[@class='row scodecard-header-container ng-scope']//span)[3]");
	public static final By scorecard_workstream_list=By.xpath("//*[@id='ScorecardTabContent']//div[@class='scroreStateTitle ng-binding']");
	
	public static void set_product(String product) {
		scorecard_icon="//*[@id='ScorecardStatusTabContent']//div[@class='workflow-item']//following-sibling::div[@title='"+product+"']"
				+ "//following-sibling::div[@class='scorecard-icon-div']";
	}
	
	public static String product_dropdowns=("(//*[@id='ScorecardStatusTabContent']//div[@class='workflow-header-container']//div[@class='icon-div'])");
}