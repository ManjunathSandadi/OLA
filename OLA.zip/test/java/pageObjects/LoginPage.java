package pageObjects;

import org.openqa.selenium.By;

public class LoginPage {
	
	public static String impersonateUser
	,releaseSelection;

	public static By impersonateNowID;
	
	public static final By userName = By.id("username");
	public static final By password = By.id("password");
	public static final By login = By.xpath("//button[@name='login']");
	public static final By userDropdown = By.xpath("//button[@id='user_info_dropdown']");
	public static final By btnImpersonateUser = By.xpath("//html//body//*[@id='glide_ui_impersonator']");
	public static final By searchForUser = By.xpath("//span[text()='Search for user']/..");
	public static final By userSearchInputBox = By.xpath("//input[@id='s2id_autogen2_search']");
	public static final By dialogBoxImpersonateUser = By.xpath("//h4[contains(text(),'Impersonate User')]");
	public static final By snGreetings = By.xpath("//h5[contains(text(),'Good')]");
	public static final By pageCount = By.xpath("//h5[contains(text(),'Good')]");
	
	public static final By notificationBellIcon = By.xpath("//div[@aria-hidden='false']/preceding-sibling::a[@title='Notifications']");
	public static final By firstReleaseWidget = By.xpath("(//div[@class='card customDashCard'])[1]");
	public static final By topNavigationHomeIcon = By.xpath("//span[@class='crumb-item' and contains(text(),'Home')]");
	public static final By topNavigationDashboardView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Dashboard View')]");
	public static final By topNavigationProductDetailView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Product Details View')]");
	public static final By topNavigationWorkstreamDetailView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Workstream Details View')]");
	public static final By topNavigationSummaryStatusView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Summary Status View')]");
	public static final By topNavigationScorecardView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Scorecard View')]");
	public static final By topNavigationAssignedToView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Assigned To Me View')]");
	public static final By topNavigationHeatMapView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Heat Map')]");
	public static final By topNavigationScorecardStatusView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Scorecard Status')]");
	public static final By topNavigationProductSummaryView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Product Summary')]");
	public static final By topNavigationWorkstreamSummaryView = By.xpath("//span[@class='crumb-item ng-binding active' and contains(text(),'Workstream Summary')]");
	
	public static final By topNavigationViewAll = By.xpath("//span[contains(text(),'View All')]/ancestor::a[@role='menuitem' and @aria-expanded='false']");
	public static final By agreeButton = By.xpath("//*[contains(text(),'Agree')]");
	
	public static final By shadowBase = By.xpath("//macroponent-f51912f4c700201072b211d4d8c26010");
	public static final By shadowFirst = By.cssSelector("sn-polaris-layout[dir='ltr']");
	public static final By shadowNowID = By.cssSelector("div[class='content-area can-animate'] > sn-impersonation");
	
	public static void setReleaseSelection(String value) {
		releaseSelection = "//span[contains(text(),'View All')]/ancestor::a[@aria-expanded='true']/following-sibling::ul/li/a[contains(text(),'" + value + "')]";
	}
	
	public static void setImpersonateUser(String user) {
		impersonateUser = "//div[text()='"+user+"']/..";
	}
	
	public static void setImpersonateNowID(String nowID) {
		impersonateNowID = By.cssSelector("sn-impersonation[now-id='" + nowID + "']"); 
	}
}