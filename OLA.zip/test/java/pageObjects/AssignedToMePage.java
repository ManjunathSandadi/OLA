package pageObjects;

import org.openqa.selenium.By;

public class AssignedToMePage {
	
	public static String btnWorkstreamProductBom,
	optWorkstreamProductBom;
	
	public static final By assignedtome=By.xpath("//a[text()='Assigned To Me']");
	public static final By bom_risk_toggle_button=By.xpath("//input[contains(@ng-model,'c.isSecTable')]/following-sibling::span");
	public static final By bom_risk_search_button=By.xpath("//input[@placeholder='Search']");
	public static final By filter=By.xpath("//*[@id='jsListView']/div[2]/div/div[1]/div[2]/button[1]");
	public static final By bulkupdate=By.xpath("//*[@id='jsListView']/div[2]/div/div[1]/div[2]/button[2]");
	public static final By state=By.xpath("//label[text()='State']/..");
	public static final By change_due_dt=By.xpath("//a[text()='Change Due Date']");
    public static final By change_state=By.xpath("//a[text()='Change State']");
	public static final By change_assigned_to=By.xpath("//a[text()='Change Assigned To']");
	public static final By bulk_update_chklall=By.xpath("//input[@ng-change='c.selectAllCheckbox()']");
	public static final By columnwise_search_button=By.xpath("//th/i[@class='fa fa-search']");
	public static final By columnwise_search_inputbox=By.xpath("//td/input[@placeholder='Search']");
	
	public static void setBtnWorkstreamProductBom(String workStream, String product, String Bom) {
		btnWorkstreamProductBom = "//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
				+ "//td[text()='"+workStream+"']/..//td[text()='"+product+"']/..//td[text()='"+Bom+"']/..//button";
	}
	
	public static void setOptWorkstreamProductBom(String workStream, String product, String Bom) {
		optWorkstreamProductBom = "//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
				+ "//td[text()='"+workStream+"']/..//td[text()='"+product+"']/..//td[text()='"+Bom+"']/..//button/..//a";
	}
}