package pageObjects;

import org.openqa.selenium.By;

public class HeatMapPage {

	public static String scorecard_icon
	,product_tile;

	public static void set_product(String product) {
		scorecard_icon="//*[@id='ScorecardStatusTabContent']//div[@class='workflow-item']//following-sibling::div[@title='"+product+"']"
				+ "//following-sibling::div[@class='scorecard-icon-div']";
		product_tile="//*[@id='heatmap-container']/div[2]//div[contains(text(),'"+product+"')]";
	}

	public static String workstream_list=("(//*[@id='divStickyRight']//div[@class=' workstream-header workstream-column-width']/span)");
	public static String view_percentage=("//div[@class='percentage-div ng-binding ng-scope']");
	public static String product_items="(//*[@id='heatmap-container']/div[2]/div[2]/div/div[2]//div[@ng-repeat='item in product.heatmapscore'])";
	public static String product_dropdowns=("(//*[@id='heatmap-container']//div[@class='workflow-header-container']//div[@class='icon-div'])");

	public static final By completion_percentage=By.xpath("//img[@title='Completion Percentage']");
	public static final By toggle_risk=By.xpath("//img[@title='Toggle Risk']");

	public static final By scorecard_summary=By.xpath("//*[@id='heatmap-container']//span[contains(text(),'Scorecard Summary')]");
	public static final By back=By.xpath("//img[@title='Back']/..");
	/*item tile colors
	        class="workflow-item-status-container workstream-column-width workflow-item-with-content ng-scope ola_grey_bg"
			class="workflow-item-status-container workstream-column-width workflow-item-with-content ng-scope risky red ola_red_bg"
			class='workflow-item-status-container workstream-column-width workflow-item-with-content ng-scope risky ola_yellow_bg'
	 */
}
