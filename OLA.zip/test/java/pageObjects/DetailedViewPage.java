package pageObjects;

import org.openqa.selenium.By;

public class DetailedViewPage {

	public static String projectRelease
	,addedBomOptionsButton
	,addRiskToBOM
	,addDependencyToBOM
	,totalBOMoptions
	,viewBom
	,addTags
	,workStream
	,workStreamAddRisk
	,workStreamButton
	,workStreamAddBom
	,viewdoc
	,add_doc
	,add_delete_doc
	,workstreamGreen
	,workstreamYellow
	,workstreamRed
	,total_WS_options
	,allworkStreamoptions
	,allworkStream
	,allworkStreamButton
	,product
	,productAddRisk
	,productButton
	,productAddBom
	,total_product_options
	,view_editBom
	,copyCloneBom
	,workStreamOverallStatus
	,workStreamProduct
	,dependent_BOM_value
	,colBomCategory
	,colBomName
	,colAssignedTo
	,colState
	,colStatus
	,colPartner
	,colDueDate
	,colTags
	,colRiskWorkstream
	,colRiskApplicableTo
	,colRiskRiskName
	,colRiskAssignedTo
	,colRiskStatus
	,colRiskImpact
	,colRiskInitiateDate
	,colRiskDueDate
	,pageBomCount
	,pageRiskCount
	,columnBomHeaders
	,columnRiskHeaders
	,atmColumnBomRiskHeaders
	,removeDocumentName
	,removeBomDocumentName
	,removeDependencyName
	,btnViewEditRiskOptions
	,view_editRisk
	,total_risk_options
	,view_risk
	,workStream_overall_status
	,pageCount
	,remove_dependency_name
	,remove_document_name
	,remove_BOM_document_name
	,filterStateOption
	,filterStateOptionLabel
	,ellipsesBomRisk
	,optViewEditBoms
	,filterBomCategoryOption
	,filterBomCategoryOptionLabel
	,riskBomCategoryValue
	,getBomId
	,getRiskIcon
	,getDependencyIcon
	,getWorkstreamProduct
	,getBomCategory
	,getBomName
	,getAssignedTo
	,getState
	,getStatus
	,getPartner
	,getDueDate
	,getTags
	,actBomId
	,actRiskIcon
	,actDependencyIcon
	,actWorkstreamProduct
	,actBomCategory
	,actBomName
	,actAssignedTo
	,actState
	,actStatus
	,actPartner
	,actDueDate
	,actTags
	,selectExistingTags
	,proposalReleaseName
	,bomStateOpenNew
	,bomStateWipNew
	,bomStateCompleteNew
	,bomStateNotApplicableNew
	,findpropsoal
	,proposaldeck;
	
	public static void setProposalRelease(String releaseName) {
		proposalReleaseName = "//h3[contains(text(),'"+releaseName+"')]/parent::div";
	}
	
	public static void searchProposal(String proposal) {
	    findpropsoal = "//span[contains(text(),'"+proposal+"')]/ancestor::div[@class='proposal-card ng-scope']";
	}
	
	public static void downloadDeckProposal(String proposals) {
		proposaldeck ="//span[contains(text(),'"+proposals+"')]/ancestor::div[@class='proposal-card ng-scope']//div[@ng-if='proposal.u_proposal_deck']";
	}
	
	public static final By businessunit = By.xpath("//input[@id='s2id_autogen2']");
	public static final By proposalname = By.xpath("//input[@id='name']");
	public static final By proposaldescription = By.xpath("//textarea[@id='description']");
	public static final By whatistheproposaltype = By.xpath("//select[@id='type']");
	public static final By additionaldetails = By.xpath("//select[@id='additionalLogic']");
	public static final By namingapprovedbynamingcommittee = By.xpath("//select[@id='namingCommitee']");
	public static final By whatistheGTMapproach = By.xpath("//select[@id='gtmApproach']");
	public static final By doyouexpectnewSKUstobecreated = By.xpath("//select[@id='newSkuExpected']");
	public static final By whoistheBUproductmanager = By.xpath("//input[@id='s2id_autogen10']");
	public static final By submitproposalbutton = By.xpath("//button[@ng-click='c.submitProposal()']");
	public static final By createproposals = By.xpath("//span[contains(text(),'Create Proposal')]/ancestor::li");
    public static final By selectproposals = By.xpath("//span[contains(text(),'Proposals')]/parent::a");
	//public static final By removeDocumentConfirmation=By.xpath("//h4[text()='Are you sure you want to remove the document link?']");
	public static final By removeDocumentConfirmation=By.xpath("//h4[text()='Are you sure you want to remove the link']");
	public static final By yes=By.xpath("//button[@class='btn btn-success']");
	
	//------ my findings --------
	//public static final By findproposal = By.xpath("//span[contains(text(),'')]/ancestor::div[@class='proposal-card ng-scope']");
	//public static final By proposaldeck = By.xpath("//span[contains(text(),'')]/ancestor::div[@class='proposal-card ng-scope']//div[@ng-if='proposal.u_proposal_deck']");

	public static final By pageBomCounts = By.xpath("(//tbody[@class='bomDetailsRows'])[1]/tr");
	public static final By pageRiskCounts = By.xpath("(//tbody[@class='bomDetailsRows'])[2]/tr");
	public static final By columnBomHeaderDetailedView = By.xpath("//*[@id='jsListView']/div[2]/div/div/div[7]/table/thead/tr/th");
	public static final By columnRiskHeaderDetailedView = By.xpath("//*[@id='jsListView']/div[3]/div/div/div[2]/table/thead/tr/th");

	public static final By paginationBomCheck = By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[8]/ul/li/a)[1]");
	public static final By paginationRiskCheck = By.xpath("(//*[@id='jsListView']/div[3]/div/div/div[3]/ul/li/a)[1]");
	public static final By bomDetailsDisplayed = By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])");
	public static final By btnGoToMarket =By.xpath("//button[text()='GTM']");
	public static final By deliverables_overview = By.xpath("//*[contains(text(),'Deliverables Overview')]");
	public static final By workstream_list=By.xpath("//select[@id='moduleSelect']");

	public static final By bomShortDescriptionEdit=By.xpath("//input[@ng-model='c.newshdesc_value']");
	public static final By bomShortDescription=By.xpath("//input[@ng-model='c.currentBom.shortDescription']");
	public static final By riskShortDescription=By.xpath("//textarea[@id='BomShortDescription']");
	public static final By bomDescriptionEdit=By.xpath("//textarea[@ng-model='c.newdesc_value']");
	public static final By bomDescription=By.xpath("//textarea[@ng-model='c.currentBom.description']");
	public static final By riskDescription=By.xpath("(//textarea[@id='BomDescription'])[1]");
	public static final By bomCategory=By.xpath("//select[@ng-model='c.currentBom.category']");
	public static final By BOM_partner=By.xpath("//select[@ng-model='c.newpartner_value']");
	public static final By BOM_type=By.xpath("//select[@ng-model='c.newbomtype_value']");
	public static final By bomState=By.xpath("//select[@ng-model='c.currentBom.state']");
	public static final By bomDueDate=By.xpath("(//input[@id='sp_formfield_' and @ng-model='formattedDate'])[1]");

	public static final By cloneBomShortDesc=By.xpath("//label[@for='BomDescription']/../input");
	public static final By clone_BOM_name=By.xpath("//textarea[@id='BomShortDescription']");
	public static final By cloneBomDesc=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.newdesc_value']");	
	public static final By addDocumnetToBom=By.xpath("//button[@ng-click='c.addLinkBOM()']");	
	public static final By bomDocumentName=By.xpath("//input[@ng-model='c.data.u_name']");
	public static final By bomDocumentLinks=By.xpath("//input[@ng-model='c.data.u_link']");
	public static final By add=By.xpath("//button[@id='add_link']");

	public static final By cloneBOMNext=By.xpath("//button[@ng-click='cloneBOM()']");

	public static final By removeDependencyConfirmation=By.xpath("//h4[text()='Are you sure you want to remove the dependency?']");
	public static final By ok_button=By.xpath("//button[text()='OK']");
	public static final By addedButton=By.xpath("//button[@type='submit']");
	public static final By addedRiskButton=By.xpath("(//button[@id='insert_btn'])[1]");
	public static final By addedDependencyButton=By.xpath("(//button[@id='insert_btn'])[1]");
	public static final By loadingDots=By.xpath("//div[@class='header-loader']");
	public static final By addedMessage=By.xpath("//div[@id='modalrecord']"); 
	public static final By close_add_document_message=By.xpath("//h1[contains(text(),'Add Document')]/..//button");
	public static final By closeViewEditBomMessage=By.xpath("//div[contains(text(),'View/Edit BOM')]/..//img");//div[contains(text(),'View/Edit BOM')]/../button
	public static final By riskImpact=By.xpath("//select[@ng-model='c.impact']");
	public static final By riskStatus=By.xpath("//select[@ng-model='c.risk_status']");
	public static final By bomMitigation=By.xpath("//label[contains(text(),'Mitigation Plan')]/parent::div/textarea");
	public static final By add_document=By.xpath("//button[@ng-click='c.addlink()']");
	public static final By document_name=By.xpath("//input[@id='LinkName']");
	public static final By document_link=By.xpath("//input[@id='LinkURL']");

	public static final By editrisk_BOM_shortdescription=By.xpath("//input[@ng-model='c.newshdesc_value']");
	public static final By editrisk_BOM_description=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.newdesc_value']");
	public static final By editrisk_BOM_impactstatus=By.xpath("//select[@ng-model='c.newimpact_value']");

	public static final By allWorkstream=By.xpath("//h5[contains(text(),'All Workstreams')]");
	public static final By allProducts=By.xpath("//h5[contains(text(),'All Products')]");
	public static final By detailed_view=By.xpath("//a[@id='ITSMDetailedViewTab']");
	public static final By green_count=By.xpath("(//span[@class='countText' and text()='Green']/../p)[1]");
	public static final By yellow_count=By.xpath("(//span[@class='countText' and text()='Yellow']/../p)[1]");
	public static final By red_count=By.xpath("(//span[@class='countText' and text()='Red']/../p)[1]");
	public static final By filter=By.xpath("(//button[contains(@data-target,'#tableFilter') and @title='Filters'])[1]");
	public static final By filterState=By.xpath("(//label[contains(text(),'State')]/parent::a)[1]");
	public static final By filterBomCategory=By.xpath("(//label[contains(text(),'BOM Category')]/parent::a)[1]");
	public static final By filterRecordsFound=By.xpath("//span[contains(@ng-if,'bom_filters') and contains(text(),'records found')]");

	public static final By dependent_BOM_prod_family_dropdown=By.xpath("(//span[text()='Dependent BOM Product Family']/../../following-sibling::div//a)[1]");
	public static final By dependent_BOM_prod_family_input=By.xpath("(//div[contains(@class,'active')]//input[contains(@id,'s2id_autogen') and @class='select2-input'])");
	public static final By dependent_BOM_workstream_dropdown=By.xpath("(//span[text()='Dependent BOM Workstream']/../../following-sibling::div//a)[1]");
	public static final By dependent_BOM_workstream_input=By.xpath("//div[contains(@class,'active') and @id='select2-drop']//input[contains(@id,'s2id_autogen') and @class='select2-input']");
	public static final By dependent_BOM_dropdown=By.xpath("(//span[text()='Dependent BOM']/../../following-sibling::div//a)[1]");
	public static final By dependent_BOM_input=By.xpath("//div[contains(@class,'active') and @id='select2-drop']//input[contains(@id,'s2id_autogen') and @class='select2-input']");
	public static final By dependent_BOM_firstOption = By.xpath("(//div[contains(@class,'active')]//div[@role='option'])[1]");

	public static final By bom_risk_toggle_button=By.xpath("//input[@ng-change='c.updateView()']/following-sibling::span");
	public static final By workstream_dropdown=By.xpath("//select[@id='moduleSelect']");
	public static final By countPage=By.xpath("//*[@id='jsListView']/div[2]//dir-pagination-controls/ul/li/a");

	/**
	 * Xpath updated due to Sprint 8 stories
	public static final By filterIcon=By.xpath("//button[@class='btn-link' and @data-target='#tableFilter']");
	public static final By filterComplete = By.xpath("(//*[@id='StateTab']/label)[1]/input");
	public static final By filterOpen = By.xpath("(//*[@id='StateTab']/label)[2]/input");
	public static final By filterWorkInProgress = By.xpath("(//*[@id='StateTab']/label)[3]/input");
	public static final By filterNotRequired=By.xpath("(//*[@id='StateTab']/label)[4]/input");
	 */

	public static final By filterIcon=By.xpath("(//button[contains(@class,'btn-link') and @data-target='#tableFilter'])[1]");
	public static final By filterComplete = By.xpath("(//div[@id='StateTab']//following-sibling::input)[3]");
	public static final By filterOpen = By.xpath("(//div[@id='StateTab']//following-sibling::input)[1]");
	public static final By filterWorkInProgress = By.xpath("(//div[@id='StateTab']//following-sibling::input)[2]");
	public static final By filterNotRequired=By.xpath("(//div[@id='StateTab']//following-sibling::input)[4]");
	public static final By filterStateOptions=By.xpath("//div[@id='StateTab']//following-sibling::input");

	public static final By ellipsesBOMRisk=By.xpath("//div[@class='cusElipsisDrop dropdown']/button[@ng-click='c.onMenuClicked($event)']");
	public static final By titleNotApplicable=By.xpath("//td/div[@title='Not Applicable']");
	public static final By optViewEditBom=By.xpath("//a[@ng-click='c.BOM_Edit(rowData.record)' and contains(text(),'View/Edit BOM')]");
	public static final By selectall=By.xpath("(//input[@ng-change='c.changeTableCheckBox()'])[1]");
	public static final By risk_selectall=By.xpath("(//input[@ng-change='c.changeTableCheckBox()'])[2]");
	public static final By search=By.xpath("(//th/i[@class='fa fa-search ng-scope'])[1]");
	public static final By risk_search=By.xpath("(//th/i[@class='fa fa-search ng-scope'])[2]");
	public static final By bulk_edit=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[1]/div[3]/button)[2]");
	public static final By filterapply=By.xpath("(//button[contains(text(),'Apply')])[1]");

	public static final By Risk_impact=By.xpath("//select[@ng-model='c.impact']");
	public static final By Risk_status=By.xpath("//select[@ng-model='c.risk_status']");

	public static final By columnHeaderDetailedView = By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]/table/thead/tr/th");

	public static final By all_workstream=By.xpath("//h5[contains(text(),'All Workstreams')]");
	public static final By all_products=By.xpath("//h5[contains(text(),'All Products')]");

	public static final By BOM_short_desc=By.xpath("//textarea[@id='BomShortDescription']");
	public static final By BOM_desc=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.Desc']");
	public static final By BOM_category=By.xpath("//select[@ng-model='c.newbomcat_value']");
	public static final By BOM_state=By.xpath("//select[@ng-model='c.newstate_value']");
	public static final By BOM_due_date=By.xpath("//input[@id='sp_formfield_' and @ng-model='formattedDate']");

	public static final By add_document_to_BOM=By.xpath("//button[@ng-click='c.addLinkBOM()']");	
	public static final By document_name_BOM=By.xpath("//input[@ng-model='c.data.u_name']");
	public static final By document_link_BOM=By.xpath("//input[@ng-model='c.data.u_link']");

	public static final By cloneBOM_next=By.xpath("//button[@ng-click='cloneBOM()']");

	public static final By remove_doc_confirmation=By.xpath("//h4[text()='Are you sure you want to remove the document link?']");

	public static final By riskBomCategory=By.xpath("//span[contains(text(),'BOM Category')]/parent::label/following-sibling::div/a");
	public static final By riskBomCategoryInput=By.xpath("//div[@id='select2-drop']/div/input");
	
	public static final By itemsPerPageBom = By.xpath("(//select[@ng-model='c.defaultPageNumIncident'])[1]");
	public static final By itemsPerPageRisk = By.xpath("(//select[@ng-model='c.defaultPageNumIncident'])[2]");
	
	public static final By manageTags = By.xpath("(//div[@id='bomListView']//div[@aria-hidden='false']//div[@class='gear-icon']/img)[1]");
	public static final By manageTagsButton = By.xpath("(//div[@class='options-container' and @aria-hidden='false']//span[contains(text(),'Manage Tags')]/parent::a)[1]");
	public static final By txtSearchCreateTags = By.xpath("//label[contains(text(),'Manage Tags')]/parent::div/following-sibling::div/input[contains(@class,'text-field')]");
	public static final By btnAddTags = By.xpath("//label[contains(text(),'Manage Tags')]/parent::div/following-sibling::div/div[@class='add-tag-button disabled']");
	public static final By bomTagsInput = By.xpath("//input[@placeholder='Search or Create tag' and @ng-model='c.tagInput']");
	public static final By bomTagsInputAddButton = By.xpath("//input[@placeholder='Search or Create tag' and @ng-model='c.tagInput']/following-sibling::div");
	public static final By bomRemoveTagsInput = By.xpath("//span[contains(text(),'Admin 2')]/following-sibling::div[@class='tag-deselect']");

	public static final By excelDownloadIcon = By.xpath("//div[@sn-atf-area='listviewppm_paginated']//following-sibling::button[@title='Export to Excel']");
	public static final By excelDownloadProgressBar = By.xpath("//div[@class='modal fade in']//following-sibling::h3[text()='Generating Excel...']");

	public static final By topRedBOMCount = By.xpath("//div[@id='ITSMDetailedViewTabContent']//following-sibling::div/span[contains(text(),'Red')]/preceding-sibling::p");
	public static final By topYellowBOMCount = By.xpath("//div[@id='ITSMDetailedViewTabContent']//following-sibling::div/span[contains(text(),'Yellow')]/preceding-sibling::p");
	public static final By topGreenBOMCount = By.xpath("//div[@id='ITSMDetailedViewTabContent']//following-sibling::div/span[contains(text(),'Green')]/preceding-sibling::p");
	
	public static void setSelectExistingTags(String value) {
		selectExistingTags = "//input[@title='" + value +"']/parent::div";
	}
	
	public static void setRiskBomCategoryValue(String value) {
		riskBomCategoryValue = "//div[@role='option' and contains(text(),'" + value +"')]";
	}
	
	public static void setOptViewEditBom(int index) {
		optViewEditBoms = "(//a[@ng-click='c.BOM_Edit(rowData.record)' and contains(text(),'View/Edit BOM')])[" + index + "]";
	}
	
	public static void setEllipsesBOMRisk(int index) {
		ellipsesBomRisk = "(//div[@class='cusElipsisDrop dropdown']/button[@ng-click='c.onMenuClicked($event)'])[" + index + "]";
	}
	
	public static void setFilterStateOptions(int index) {
		filterStateOption = "(//div[@id='StateTab']//following-sibling::input)[" + index + "]";
		filterStateOptionLabel = "(//div[@id='StateTab']//following-sibling::label)[" + index + "]";
	}
	
	public static void setFilterBomCategoryOptions(int index) {
		filterBomCategoryOption = "(//div[@id='StateTab']/div/div/label/input)[" + index + "]";
		filterBomCategoryOptionLabel = "(//div[@id='StateTab']/div/div/label)[" + index + "]";
	}

	public static void setWorkstreamProduct(int index) {
		workStreamProduct = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}

	public static void setBomCategory(int index) {
		colBomCategory = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}

	public static void setBomName(int index) {
		colBomName = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}

	public static void setAssignedTo(int index) {
		colAssignedTo = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}

	public static void setState(int index) {
		colState = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}

	public static void setStatus(int index) {
		colStatus = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}

	public static void setPartner(int index) {
		colPartner = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}

	public static void setDueDate(int index) {
		colDueDate = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}
	
	public static void setTags(int index) {
		colTags = "(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[" + index + "])";
	}

	public static void setPageBomCount(int pageNumber) {
		pageBomCount = "(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[" + pageNumber + "]";
	}

	public static void setPageRiskCount(int pageNumber) {
		pageRiskCount = "(//*[@id='jsListView']/div[3]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[" + pageNumber + "]";
	}

	public static void setColumnBomHeaderDetails(int index) {
		columnBomHeaders = "//*[@id='jsListView']/div[2]/div/div/div[7]/table/thead/tr/th[" + index + "]";
	}

	public static void setColumnRiskHeaderDetails(int index) {
		columnRiskHeaders = "//*[@id='jsListView']/div[3]/div/div/div[2]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setRiskWorkstream(int index) {
		colRiskWorkstream = "//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setRiskApplicableTo(int index) {
		colRiskApplicableTo = "//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setRiskRiskName(int index) {
		colRiskRiskName = "//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setRiskAssignedTo(int index) {
		colRiskAssignedTo = "//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setRiskStatus(int index) {
		colRiskStatus = "//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setRiskImpact(int index) {
		colRiskImpact = "//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setRiskInitiateDate(int index) {
		colRiskInitiateDate = "//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setRiskDueDate(int index) {
		colRiskDueDate = "//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead/tr/th[" + index + "]";
	}
	
	public static void setATMColumnBomRiskHeaderDetails(int index) {
		atmColumnBomRiskHeaders = "//*[@id='jsListView']/div[2]/div/div[4]/table/thead//th[" + index + "]";
	}

	public static void set_BOMdocument(String name){
		removeBomDocumentName="//a[text()='"+name+"']/following-sibling::button";
	}

	public static void setDocument(String name){

	}

	public static void set_dependency(String name){
		removeDependencyName="//td[text()='"+name+"']/preceding::span[@role='button']";
	}

	public static void setRelease(String release) {
		projectRelease="//*[text()='"+release+"']";
	}

	public static void setBOM(String value){
		//addedBomOptionsButton="//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+value+"']/..//button";
		addedBomOptionsButton="(//span[@title='"+value+"']//parent::td/preceding-sibling::td/div/button)[1]";
		addRiskToBOM="(//span[@title='"+value+"']//parent::td/preceding-sibling::td/div/button/..//a[text()='Add Risk'])[1]";
		addDependencyToBOM="(//span[@title='"+value+"']//parent::td/preceding-sibling::td/div/button/..//a[text()='Add a Dependency'])[1]";
		view_editBom="(//span[@title='"+value+"']//parent::td/preceding-sibling::td/div/button/..//a[text()='View/Edit BOM'])[1]";
		copyCloneBom="(//span[@title='"+value+"']//parent::td/preceding-sibling::td/div/button/..//a[text()='Copy/Clone BOM'])[1]";
		totalBOMoptions="(//span[@title='"+value+"']//parent::td/preceding-sibling::td/div/button/..//a)[1]";
		viewBom="(//span[@title='"+value+"']//parent::td/preceding-sibling::td/div/button/..//a[text()='View BOM'])[1]";
		addTags="(//span[@title='"+value+"']//parent::td/preceding-sibling::td/div/button/..//a[text()='Add Tags'])[1]";
	}

	public static void setRisk(String BOM, String Risk) {
		//view_editRiskOptionsButton="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button";
		btnViewEditRiskOptions="//div[contains(text(),'BOM : "+BOM+"')]/parent::td/following-sibling::td/div[contains(text(),'"+Risk+"')]/parent::td/preceding-sibling::td/div[@class='cusElipsisDrop dropdown']/button";
		//view_editRisk="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a[text()='View/Edit Risk']";
		view_editRisk="//div[contains(text(),'BOM : "+BOM+"')]/parent::td/following-sibling::td/div[contains(text(),'"+Risk+"')]/parent::td/preceding-sibling::td/div[contains(@class,'cusElipsisDrop dropdown')]//a";
		total_risk_options="(//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a)";
		view_risk="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a[text()='View Risk']";
	}

	public static void setWorkstream(String workstream_value) {
		allworkStream="//h5[contains(text(),'"+workstream_value+"')]/..";
		allworkStreamButton="//h5[contains(text(),'"+workstream_value+"')]/..//button";
		allworkStreamoptions="(//h5[contains(text(),'"+workstream_value+"')]/..//button/..//a)";
		workStream="(//h5[contains(text(),'"+workstream_value+"')]/../..)[1]";
		workStreamButton="(//h5[contains(text(),'"+workstream_value+"')]/../..//button)[1]";
		workStreamAddBom="//h5[contains(text(),'"+workstream_value+"')]/../..//button/..//a[text()='Add BOM']";
		workStreamAddRisk="//h5[contains(text(),'"+workstream_value+"')]/../..//button/..//a[text()='Add Risk']";
		workStreamOverallStatus="(//h5[contains(text(),'"+workstream_value+"')]/..//p)[1]";
		viewdoc="//h5[text()='"+workstream_value+"']/../..//button/..//a[contains(text(),'View')]";
		add_delete_doc="(//h5[text()='"+workstream_value+"']/../..//button/..//a[contains(text(),'Add/Delete')])";
		add_doc="//h5[text()='"+workstream_value+"']/../..//button/..//a[contains(text(),'Add')]";
		workstreamGreen="(//h5[text()='"+workstream_value+"']/../..)[1]//div[@class='progress-bar bg-green']";
		workstreamYellow="(//h5[text()='"+workstream_value+"']/../..)[1]//div[@class='progress-bar bg-yellow']";
		workstreamRed="(//h5[text()='"+workstream_value+"']/../..)[1]//div[@class='progress-bar bg-red']";
		total_WS_options="(//h5[text()='"+workstream_value+"']/../..//ul/li/a)";
	}
	
	public static void setWorkstreamProduct(String workstream_value) {
		allworkStream = "(//div[@title='"+workstream_value+"']//ancestor::div[contains(@class,'ola-intersection-card-container')])[1]";
		allworkStreamButton = "//div[@title='"+workstream_value+"']/following-sibling::div[@class='intersection-icon menu ng-scope']";
		allworkStreamoptions = "//div[@title='"+workstream_value+"']//following-sibling::ul[@class='dropdown-menu ng-scope']//a";
		workStream = "(//div[@title='"+workstream_value+"']//ancestor::div[contains(@class,'ola-intersection-card-container')])[1]";
		workStreamButton = "//div[@title='"+workstream_value+"']/following-sibling::div[@class='intersection-icon menu ng-scope']";
		workStreamAddRisk = "//div[@title='"+workstream_value+"']//following-sibling::ul[@class='dropdown-menu ng-scope']//a[text()='Add Risk']";
		workStreamAddBom = "//div[@title='"+workstream_value+"']//following-sibling::ul[@class='dropdown-menu ng-scope']//a[text()='Add BOM']";
		viewdoc = "//div[@title='"+workstream_value+"']//following-sibling::ul[@class='dropdown-menu ng-scope']//a[contains(text(),'View')]";
		add_delete_doc = "//div[@title='"+workstream_value+"']//following-sibling::ul[@class='dropdown-menu ng-scope']//a[contains(text(),'Add/Delete')])";
		add_doc = "//div[@title='"+workstream_value+"']//following-sibling::ul[@class='dropdown-menu ng-scope']//a[contains(text(),'Add')]";
		workstreamGreen = "(//span[text()='BOM Details']//parent::div//div[@class='counter green ng-binding']/text())[1]";
		workstreamYellow = "(//span[text()='BOM Details']//parent::div//div[@class='counter yellow ng-binding']/text())[1]";
		workstreamRed = "(//span[text()='BOM Details']//parent::div//div[@class='counter red ng-binding']/text())[1]";
		total_WS_options = "//div[@title='"+workstream_value+"']//following-sibling::ul[@class='dropdown-menu ng-scope']//a";
		workStreamOverallStatus = "//div[@title='"+workstream_value+"']//ancestor::div[contains(@class,'ola-intersection-card-container')]"
				+ "//following-sibling::div[contains(@class,'intersection-percentage')]";
	}

	public static void setProduct(String Product) {
		product="(//h5[text()='"+Product+"']/../..)[1]";
		productButton="(//h5[text()='"+Product+"']/../..//button)[1]";
		productAddBom="//h5[text()='"+Product+"']/../..//button/..//a[text()='Add BOM']";
		productAddRisk="//h5[text()='"+Product+"']/../..//button/..//a[text()='Add Risk']";
		total_product_options="(//h5[text()='"+Product+"']/../..//ul/li/a)";
	}

	public static void setDependent_BOM_Value(String value) {
		dependent_BOM_value="//div[text()='"+value+"']";	
	}

	public static void setPageCount(int pageNumber) {
		pageCount = "(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[" + pageNumber + "]";
	}

	public static void set_document(String name){
		remove_document_name="//h4[text()='"+name+"']/../../button";
	}

	public static void setBOM_Risk(String BOM, String Risk) {
		btnViewEditRiskOptions="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button";
		view_editRisk="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a[text()='View/Edit Risk']";
		total_risk_options="(//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a)";
		view_risk="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a[text()='View Risk']";
	}
	
	public static void setBomData(int index) {
		getBomId = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]";
		getRiskIcon = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[3]";
		getDependencyIcon = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[4]";
		getWorkstreamProduct = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[5]";
		getBomCategory = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[6]";
		getBomName = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[7]";
		getAssignedTo = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[8]";
		getState = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[9]";
		getStatus = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[10]";
		getPartner = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[11]";
		getDueDate = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[12]";
		getTags = "(//tbody[@class='bomDetailsRows'])[1]/tr[" + index + "]/td[13]";
	}
	
	public static void actBomData(String value) {
		actRiskIcon = "//tr[@id='" + value + "']/td[3]";
		actDependencyIcon = "//tr[@id='" + value + "']/td[4]";
		actWorkstreamProduct = "//tr[@id='" + value + "']/td[5]";
		actBomCategory = "//tr[@id='" + value + "']/td[6]";
		actBomName = "//tr[@id='" + value + "']/td[7]";
		actAssignedTo = "//tr[@id='" + value + "']/td[8]";
		actState = "//tr[@id='" + value + "']/td[9]";
		actStatus = "//tr[@id='" + value + "']/td[10]";
		actPartner = "//tr[@id='" + value + "']/td[11]";
		actDueDate = "//tr[@id='" + value + "']/td[12]";
		actTags = "//tr[@id='" + value + "']/td[13]";
	}

	public static String search_input="//td/input[@placeholder='Search']";
	public static String filer_options="(//li[@ng-if='fltHeader.isFilter']//span/following-sibling::label)";
	public static String breadcrumb="(//button[contains(text(),'x')]/..)";
	public static String filterBomOptionsList="//*[@id='StateTab']/div/div/label";
	public static String bomPageCounts="(//*[@id='jsListView']/div[2]//dir-pagination-controls/ul/li/a)";
	public static String bomCol8="//tbody[@class='bomDetailsRows']//td[8]";
	public static String bomCol9="//tbody[@class='bomDetailsRows']//td[9]";
	public static String bomCol10="//tbody[@class='bomDetailsRows']//td[10]";
	public static String bomRecentlyUpdated = "(//tr[@class='ng-scope recentlyUpdated'])";
	
	public static void getBomStateValues(String bomName) {
		bomStateOpenNew = "//span[contains(text(),'"+bomName+"')]/ancestor::td//preceding-sibling::td/div[@title='Open']";
		bomStateWipNew = "//span[contains(text(),'"+bomName+"')]/ancestor::td//preceding-sibling::td/div[@title='Work in Progress']";
		bomStateCompleteNew = "//span[contains(text(),'"+bomName+"')]/ancestor::td//preceding-sibling::td/div[@title='Complete']";
		bomStateNotApplicableNew = "//span[contains(text(),'"+bomName+"')]/ancestor::td//preceding-sibling::td/div[@title='Not Applicable']";
	}
}