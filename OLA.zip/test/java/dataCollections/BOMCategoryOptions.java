package dataCollections;

import java.util.ArrayList;

public class BOMCategoryOptions {

	private static ArrayList<String> getProductReady;
	private static ArrayList<String> getProductContentReady;
	private static ArrayList<String> getReadytoOperate;
	private static ArrayList<String> getReadytoMarket;
	private static ArrayList<String> getReadytoSell;
	private static ArrayList<String> getReadytoSolve;
	private static ArrayList<String> getReadytoDeliver;
	private static ArrayList<String> getReadytoPartner;
	private static ArrayList<String> getReadytoTrainLearn;
	private static ArrayList<String> getReadytoSupport;
	private static ArrayList<String> getReadytoAdopt;
	private static ArrayList<String> getReleaseManagementOperationDates;
	private static ArrayList<String> getProgramManagement;

	public static ArrayList<String> getProductReady() {return getProductReady;}
	public static ArrayList<String> getProductContentReady() {return getProductContentReady;}
	public static ArrayList<String> getReadytoOperate() {return getReadytoOperate;}
	public static ArrayList<String> getReadytoMarket() {return getReadytoMarket;}
	public static ArrayList<String> getReadytoSell() {return getReadytoSell;}
	public static ArrayList<String> getReadytoSolve() {return getReadytoSolve;}
	public static ArrayList<String> getReadytoDeliver() {return getReadytoDeliver;}
	public static ArrayList<String> getReadytoPartner() {return getReadytoPartner; }
	public static ArrayList<String> getReadytoTrainLearn() {return getReadytoTrainLearn; }
	public static ArrayList<String> getReadytoSupport() {return getReadytoSupport; }
	public static ArrayList<String> getReadytoAdopt() {return getReadytoAdopt; }
	public static ArrayList<String> getReleaseManagementOperationDates() {return getReleaseManagementOperationDates; }
	public static ArrayList<String> getProgramManagement() {return getProgramManagement; }

	public BOMCategoryOptions(ArrayList<String> ProductReady, ArrayList<String> ProductContentReady, 
			ArrayList<String> ReadytoOperate, ArrayList<String> ReadytoMarket, ArrayList<String> ReadytoSell,
			ArrayList<String> ReadytoSolve, ArrayList<String> ReadytoDeliver, ArrayList<String> ReadytoPartner,
			ArrayList<String> ReadytoTrainLearn, ArrayList<String> ReadytoSupport, ArrayList<String> ReadytoAdopt,
			ArrayList<String> ReleaseManagementOperationDates, ArrayList<String> ProgramManagement) {

		BOMCategoryOptions.getProductReady = ProductReady;
		BOMCategoryOptions.getProductContentReady = ProductContentReady;
		BOMCategoryOptions.getReadytoOperate = ReadytoOperate;
		BOMCategoryOptions.getReadytoMarket = ReadytoMarket;
		BOMCategoryOptions.getReadytoSell = ReadytoSell;
		BOMCategoryOptions.getReadytoSolve = ReadytoSolve;
		BOMCategoryOptions.getReadytoDeliver = ReadytoDeliver;
		BOMCategoryOptions.getReadytoPartner = ReadytoPartner;
		BOMCategoryOptions.getReadytoTrainLearn = ReadytoTrainLearn;
		BOMCategoryOptions.getReadytoSupport = ReadytoSupport;
		BOMCategoryOptions.getReadytoAdopt = ReadytoAdopt;
		BOMCategoryOptions.getReleaseManagementOperationDates = ReleaseManagementOperationDates;
		BOMCategoryOptions.getProgramManagement = ProgramManagement;
	}
}